





lambda_1 = lambda_s(1) ;

time_min = 1.75;
time_count = 6;

space_fwd = exp(lambda_1*linspace(0,time_min,time_count));
space = [ -space_fwd,0,fliplr(space_fwd)];
space = mid(space *delta);
% return 


divisions = length(space);

% % manifold = zeros( N+1,divisions);


% % % 
% % % for i = 1:divisions
% % %     theta = space(i);
% % %     sum1 =zeros(N+1,1);
% % %     for m=fliplr(1:M)
% % %         sum1 = sum1 + Ps(:,m+1).*(theta^m);
% % %     end
% % %     
% % %     manifold(:,i)=Q\sum1;
% % % end


ambient_manifold = zeros(divisions,N+1);

ambient_manifold_L =zeros(N+1,1);
ambient_manifold_R =zeros(N+1,1);
ambient_manifold_C =Ps(:,1);

for i = 1:divisions
    theta = space(i);
    for m=fliplr(0:M)
            ambient_manifold(i,:) = ambient_manifold(i,:) + Ps(:,m+1)'.*(theta^m);
    end
end


numPoints = 1000;
theThetas = linspace(0, pi, numPoints);
a1_function = zeros(numPoints, 1); % left
a2_function = zeros(numPoints, 1); % right
a0_function = zeros(numPoints, 1); % center

slow_homotopy_function = zeros(divisions,numPoints); 

for i = 1:divisions 
    for j = 1:numPoints
       theta = theThetas(j);
       sum0 = ambient_manifold(i,1);
       for k = 1:N
          sum0 = sum0 + 2*mid(ambient_manifold(i,k+1))*cos(k*theta);
       end
       slow_homotopy_function(i,j) = sum0; 
    end
end

% % % figure
% % % hold on
% % % 
% % % plot(theThetas, slow_homotopy_function(1,:), 'g','LineWidth',1.5)
% % % plot(theThetas, slow_homotopy_function(end,:), 'c','LineWidth',1.5)
% % % plot(theThetas, slow_homotopy_function(ceil(divisions/2),:), 'b','LineWidth',1.5)
% % % set(gca,'XLim',[0 pi])
% % % legend({'Left','Right','Equilibrium'},'Location','northeast')

% Set color vector
c = winter(divisions);

middle_index = (divisions-1)/2+1;
c_2 = winter(middle_index);

% close all
figure
hold on 
for i = 1 : divisions 
    plot(theThetas, slow_homotopy_function(i,:), 'Color',c(i,:),'LineWidth',0.75)
end
plot(theThetas, slow_homotopy_function(middle_index,:),'k','LineWidth',.75)
set(gca,'XLim',[0 pi])
X_Ticks_1st_fig = linspace(0,pi,9);
xticks(X_Ticks_1st_fig )
xticklabels({'0',' ','\pi/4',' ','\pi/2',' ','3\pi/4',' ','\pi'})



figure
hold on 
for i = 1 : divisions 
    plot(theThetas, slow_homotopy_function(i,:), 'Color',c(i,:),'LineWidth',0.75)
end
plot(theThetas, slow_homotopy_function(middle_index,:),'k','LineWidth',2)
X_Ticks_2nd_fig = linspace(0,3*pi/4,7);
xticks(X_Ticks_2nd_fig )
xticklabels({'0',' ','\pi/4',' ','\pi/2',' ','3\pi/4'})
xlim([0,3*pi/4])
ylim([.9,1.175])


    


% % % %  This will plot two images with 
% % 
% % figure
% % hold on 
% % for i = middle_index : divisions 
% %     plot(theThetas, slow_homotopy_function(i,:), 'Color',c_2(divisions-i+1,:),'LineWidth',0.5)
% % end
% % plot(theThetas, slow_homotopy_function(middle_index,:),'k','LineWidth',1.)
% % set(gca,'XLim',[0 pi])
% % 
% % figure
% % hold on 
% % for i = 1 : middle_index 
% %     plot(theThetas, slow_homotopy_function(i,:), 'Color',c_2(i,:),'LineWidth',0.5)
% % end
% % plot(theThetas, slow_homotopy_function(middle_index,:),'k','LineWidth',1.)
% % set(gca,'XLim',[0 pi])


    
    