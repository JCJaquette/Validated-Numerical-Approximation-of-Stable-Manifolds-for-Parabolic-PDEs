% Plot_Manifold.m  
% 
% This file plots objects computed in the file << a_bundles_a1_proof.m >>
% used to produce Figure 1 in the paper. 
% 
% In black is plotted the equilibrium. 
% In color is plotted several points along the slow-stable manifold. 
% 
% Last Modified:  Mar 30, 2020

close all
figure_height   = 300;
figure_width    = figure_height*  (1.4);


font_size       = 11;

line_width_Eq            = 1;
line_width_Eq_Zoom       = 2;
line_width_Slow_manifold = .75; 
line_width_Slow_manifold_Zoom = 1;

lines_on_either_side = 3; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%     Constructs Points on manifold    %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

total_lines = 2*lines_on_either_side +1;
space = linspace(-mid(delta),mid(delta),total_lines );

divisions = length(space); 
ambient_manifold = zeros(divisions,N+1);

for i = 1:divisions
    theta = space(i);
    for m=fliplr(0:M)
            ambient_manifold(i,:) = ambient_manifold(i,:) + Ps(:,m+1)'.*(theta^m);
    end
end


numPoints = 1000;
theThetas = linspace(0, pi, numPoints); 

slow_homotopy_function = zeros(divisions,numPoints); 

for i = 1:divisions 
    for j = 1:numPoints
       theta = theThetas(j);
       sum0 = ambient_manifold(i,1);
       for k = 1:N
          sum0 = sum0 + 2*mid(ambient_manifold(i,k+1))*cos(k*theta);
       end
       slow_homotopy_function(i,j) = sum0; 
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%           Plots Images               %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Sets color vector
c = winter(divisions);
middle_index = (divisions-1)/2+1;


figure(1)
hold on 
for i = 1 : divisions 
    plot(theThetas, slow_homotopy_function(i,:), 'Color',c(i,:),'LineWidth',line_width_Slow_manifold)
end
plot(theThetas, slow_homotopy_function(middle_index,:),'k','LineWidth',line_width_Eq)
set(gca,'XLim',[0 pi])
X_Ticks_1st_fig = linspace(0,pi,9);
xticks(X_Ticks_1st_fig )
xticklabels({'0',' ','\pi/4',' ','\pi/2',' ','3\pi/4',' ','\pi'})
set(gca,'FontSize', font_size)
set(gcf,'position', [400, 300, figure_width, figure_height])



% Plots the Zoomed-in version
figure(2)
hold on 
for i = 1 : divisions 
    plot(theThetas, slow_homotopy_function(i,:), 'Color',c(i,:),'LineWidth',line_width_Slow_manifold_Zoom)
end
plot(theThetas, slow_homotopy_function(middle_index,:),'k','LineWidth',line_width_Eq_Zoom)
X_Ticks_2nd_fig = linspace(0,3*pi/4,7);
xticks(X_Ticks_2nd_fig )
xticklabels({'0',' ','\pi/4',' ','\pi/2',' ','3\pi/4'})
xlim([0,3*pi/4])
ylim([.9,1.175])
set(gca,'FontSize', font_size)
set(gcf,'position', [900, 300, figure_width, figure_height])
    
    