%!!!!!!!!! Make sure to comment out radii in the main program. 
clear



delta_min = 1e-8 / 6.4477;
delta_max = 3.18 / 6.4477;

Max_steps = 30;
delta_r = (log(delta_max) - log(delta_min) ) / Max_steps;

delta_list = (0:Max_steps).*delta_r +log(delta_min);
delta_list = exp(delta_list)


initial_rho_f       = 1e-15;
initial_rho_infty   = 1e-17;

radii_list_theta = [];
radii_list_fast  = [];
radii_list_infty = [];

error_list=[];
cone_list=[];
cone_list_finite=[];
cone_list_fast=[];
cone_list_tail=[];
contraction_list=[];

P_u_ss =[];
P_u_s_infty =[];
P_u_infty_infty =[];

% a_bundles_a1_proof

tic
for it_radii = 1:Max_steps +1
%     radii = [radii_list(it_radii);   radii_list(it_radii)/2];    

    
    delta = intval(delta_list(it_radii));
    a_bundles_a1_proof
%     a_bundles_a1_JustTheBounds
    r_theta = delta*ellOneNorm_intval(scale_ss1*xi_slow1, nu, N)
    if it_radii ==1 
        radii = [r_theta; initial_rho_f; initial_rho_infty] ;
    else
        radii = [r_theta; radii_list_fast(it_radii-1); radii_list_infty(it_radii-1)];
    end
    main_NL;
%     pause
    
    if total_success
%         if sup(P_u_s_s(1,1,1)) >10
%             radii_list = radii_list(1:it_radii-1);
%             break;
%         end
        
        disp('We are verified!!!!')    
        cone_list(it_radii) = max(sup(P_u_s));
        cone_list_finite(it_radii) = sup(P_u_s(1));
        cone_list_fast(it_radii) = sup(P_u_s(2));
        cone_list_tail(it_radii) = sup(P_u_s(3));
        
        error_list(it_radii) = sup(abs_error);
        contraction_list(it_radii) = sup(Jnorm);
        radii_list_theta(it_radii) = inf(r_theta)
        radii_list_fast(it_radii)  = sup(radii(2));
        radii_list_infty(it_radii) = sup(radii(end));
        

        
        P_u_ss(it_radii)            = sup(P_u_s_s(1,1,1));
        P_u_s_infty(it_radii)       = sup(P_u_s_s(1,1,2));
        P_u_s_infty(it_radii)       = sup(P_u_s_s(1,1,2));
        P_u_infty_infty(it_radii)   = sup(P_u_s_s(1,2,2));
        
    else 
        delta_list = delta_list(1:it_radii-1);
        break;
    end
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%             Plots the data 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Parameters .....

line_width = 1.6;
figure_height   = 700;
figure_width    = 350;
font_size       = 11;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plotting
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure('position', [700, 150, figure_width, figure_height]) 
set(gca,'FontSize', font_size)
hold on


C2_error = P_u_ss+P_u_s_infty+P_u_infty_infty;
C2_error_norm =  P_u_ss;
for i = 1:length(P_u_ss)
    P2_local = [P_u_ss(i),P_u_s_infty(i);P_u_s_infty(i),P_u_infty_infty(i)];
    C2_error_norm(i) = norm(P2_local );
end


The_Color_Order = get(gca,'colororder');

color_contract  = The_Color_Order(1,:);
color_C0_bound  = The_Color_Order(2,:);
color_slow      = The_Color_Order(3,:);
color_fast      = The_Color_Order(4,:);
color_infty     = The_Color_Order(5,:);


plot(radii_list_theta,contraction_list, '--','Color',color_contract  ,'LineWidth',line_width )
plot(radii_list_theta,error_list,       '-.','Color',color_C0_bound  ,'LineWidth',line_width )
plot(radii_list_theta,cone_list_finite, '-','Color',color_slow      ,'LineWidth',line_width)
plot(radii_list_theta,cone_list_fast,   '-','Color',color_fast      ,'LineWidth',line_width )
plot(radii_list_theta,cone_list_tail,   '-','Color',color_infty     ,'LineWidth',line_width )
plot(radii_list_theta,radii_list_fast,  ':','Color',color_fast      ,'LineWidth',line_width )
plot(radii_list_theta,radii_list_infty, ':','Color',color_infty     ,'LineWidth',line_width )
% plot(radii_list,C2_error )
% plot(radii_list,C2_error_norm)
hold off


xlabel('\rho_{\theta} ')

set(gca,'xscale','log')
set(gca,'yscale','log')


legend({'Contraction Constant','C^0 bound','C^1 bound (slow)','C^1 bound (fast)','C^1 bound (tail)','\rho_{f}','\rho_{\infty}'},'Location','northwest')

set(gca,'XLim',[1e-10,.1])
set(gca,'YLim',[10^-18,1])

set(gcf,'position', [900, 150, figure_width*1.5, figure_height])
pause(0.1)
xticks('manual')
set(gcf,'position', [900, 50, figure_width, figure_height])

toc




