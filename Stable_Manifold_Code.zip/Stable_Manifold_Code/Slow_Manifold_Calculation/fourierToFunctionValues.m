function a_function = fourierToFunctionValues(a, theThetas, numPoints, N)

a_function = zeros(numPoints, 1);


for j = 1:numPoints
    
   theta = theThetas(j);
   sum = a(1);
   
   for k = 1:N
      sum = sum + 2*mid(a(k+1))*cos(k*theta);
   end
   a_function(j) = sum; 
end



return