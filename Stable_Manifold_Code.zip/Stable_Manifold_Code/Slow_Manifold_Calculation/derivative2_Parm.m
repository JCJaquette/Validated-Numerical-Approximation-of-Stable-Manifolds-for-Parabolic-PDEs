function P_theta2 = derivative2_Parm(P, M, N)

P_theta2 = zeros(N+1, M+1);

for m = 0:M-2
   P_theta2(:, m+1) = (m+2)*(m+1)*P(:, m+3); 
end

end

