function norm = parmNorm_D1_inf_intval(P, nu, M, N, delta, norm_of_1_theta)

Mbig = size(P, 2)-1;
norm = intval(0);
for m = 0:Mbig-1
    norm = norm + (m+1)*ellOneNorm_inf_intval(P(:, m+2), nu, N)*(delta^m);
end

norm = norm /norm_of_1_theta;

end