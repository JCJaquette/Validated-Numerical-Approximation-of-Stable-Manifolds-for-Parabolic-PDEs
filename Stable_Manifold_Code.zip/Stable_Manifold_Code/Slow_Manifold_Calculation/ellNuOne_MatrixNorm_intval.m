function A_norm = ellNuOne_MatrixNorm_intval(A, nu, N)

% boundVector = intval(zeros(1, N+1));
% normVector = intval(ones(1, N+1))/nu;
% exponentVect = linspace(0, N, N+1);
% normVector = normVector.^exponentVect;
% normVector = normVector/2;
% normVector(1) = 1;
% 
% for n = 0:N
%    %thisRow = intval(zeros(1, N+1));
%    %thisRow(1) = abs(A(n+1, 1));
%    %for k = 1:N
%    %   thisRow(k+1) = abs(A(n+1, k+1))/(2*nu^k);
%    %end
%    thisRow = abs(A(n+1, :)).*normVector;
%    [rowMax, maxIndex] = max(sup(thisRow));
%    boundVector(n+1) = thisRow(maxIndex);
% end
% 
% A_norm = ellOneNorm_intval(boundVector', nu, N);

nu_power = intval(2)*nu.^(0:N);
nu_power(1)=intval(1);
A_norm = max(sup(sum(abs(A).*repmat(nu_power,N+1,1)')./nu_power)); 

end





