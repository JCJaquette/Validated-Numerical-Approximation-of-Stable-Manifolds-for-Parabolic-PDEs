function q=taylorconvolution(varargin)
% aout=cosinetaylorconvolution(a1,a2,a3,...)
% Uses fft to compute the convolution of a1, a2, a3, ...
% which each represents a cosine-Taylor expansion
% with the cosine coefficients in the first dimension.
%
% It is assumed all inputs have the same size.
% The number of inputs and Taylor dimensions is arbitrary.
%
% The input can be (tensors of) floats or intvals
% The output is the full extended convolution (all nonzero terms)
% 
% Possible improvements are to use Banach algebra estimates
% and/or reduce sizes by using nested convolutions
% (working with inputs of different sizes).
% An obvious generalization is to multiple cosine (or Fourier) dimensions

a=varargin;
K=length(a);
N=size(a{1})-1;
M=length(N); % M is the number of Taylor dimensions

% define some indices
%-- killed in Taylor version inda{1}=1:2*N(1)+1;
for i=1:M
    inda{i}=1:(N(i)+1);
end
% killed in Tarylor version indq{1}=(K*N(1)+1):(2*K*N(1)+1);
for i=1:M
    indq{i}=1:(K*N(i)+1);
end

% cosine Taylor version: zeroindices=[2*K*N(1)+1,K*N(2:end)+1];
zeroindices= K*N(1:end)+1;
if exist('intval','file') && isintval(a{1}(1))
    zeroindices = 2.^nextpow2(zeroindices);
    extendedzeros=intval(zeros(zeroindices));
else
    extendedzeros=zeros(zeroindices);
end


for j=1:K
    % flipping in the cosine direction
    % -- TaylorFourier Case :
    %aext=cat(1,a{j}(N(1)+1:-1:2,inda{2:M}),a{j});
    %aext=cat(1,a{j}(N(1)+1:-1:2,inda{2:M}),a{j});
    % padding 
    aextended=extendedzeros;
    %aextended(inda{1:M})=aext;
    aextended(inda{1:M})=a;
    % fft
    Fa{j}=altfftn(aextended);
end

% product
Fq=Fa{1};
for j=2:K
    Fq=Fq.*Fa{j};
end

%ifft
q=altifftn(Fq);
%take the cosines coefficients and remove extraneous zeros
%q=q(indq{1:M});

end

function y = altfftn(x)
% computes the FFT of a tensor of any dimensions
% for variables of double or intval type
%
% for intval type the size of the input (in all dimensions) 
% have to be powers of 2

if exist('intval','file') && isintval(x(1))
  n = size(x);
  m = length(n);
  y = x;   
  for dimension = 1:m
      if n(dimension)>1   % no fft if first dimension is singleton! 
          y = reshape(verifyfft(y,1),size(y));
      end
      y = permute(y,[2:m 1]);
  end
else
  y=fftn(x); 
end

end


function y = altifftn(x)
% computes the IFFT of a tensor of any dimensions
% for variables of double or intval type
%
% for intval type the size of the input (in all dimensions) 
% have to be powers of 2

if exist('intval','file') && isintval(x(1))
  n = size(x);
  m = length(n);
  y = x;   
  for dimension = 1:m
      if n(dimension)>1   % no ifft if first dimension is singleton! 
          y = reshape(verifyfft(y,-1),size(y));
      end
      y = permute(y,[2:m 1]);
  end
else
  y=ifftn(x); 
end

end

