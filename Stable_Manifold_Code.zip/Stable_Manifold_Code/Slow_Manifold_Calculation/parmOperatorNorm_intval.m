function norm = parmOperatorNorm_intval(Q, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)

norm = intval(0);
for m = 0:M
    norm = norm + operatorBound_l1_X_intval(Q(:, :, m+1), Q0, nu, N)*(delta^m);
end

end