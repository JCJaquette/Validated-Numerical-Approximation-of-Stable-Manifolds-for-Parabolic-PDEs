function norm = parmNorm_D1_intval(P, Q0, nu, M, N, delta, norm_of_1_theta)

norm = intval(0);
for m = 0:M-1
    norm = norm + (m+1)*ellOneNorm_intval(P(:, m+2), nu, N)*(delta^m);
end

norm = norm/norm_of_1_theta;

end