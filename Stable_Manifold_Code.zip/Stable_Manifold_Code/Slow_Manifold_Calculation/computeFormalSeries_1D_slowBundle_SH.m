function Q_bundle = computeFormalSeries_1D_slowBundle_SH(...
                   a, gamma, beta, lambda_slow1, ...
                   Ps, Sigma1, Q1, ...
                   nu, M, N)
                   

DFa1 = mid(swiftHohenbergDifferential_cos_intval(...
                a, gamma, beta));

Q_bundle = zeros(N+1, N+1, M+1);

Id = eye(N+1);

for n = 0:N
    disp([' (n/N) = ' num2str(n) ' / ' num2str(N)])
%     n 
%     N
    
    lambda_n = Sigma1(n+1, n+1);
    thisBundle = zeros(N+1, M+1);
    thisNorm = ellOneNorm_intval(Q1(:, n+1), nu, N);

    thisBundle(:, 1) = Q1(:, n+1); %/thisNorm; 
                         %/thisNorm; %abs(5000*lambda_n); %nu^(N-n); %;
    
    for m = 1:M
    
        A_hom = DFa1 - (lambda_n + m*lambda_slow1)*Id;
        
        Rm = zeros(N+1, 1);
        deltaHat = ones(m+1, m+1);
        deltaHat(m+1, m+1) = 0;
        
        for j = 0:m
            for i = 0:j
                thisTerm = ...
                    cubic_FFT(...
                             Ps(:, m-j+1), ...
                             Ps(:, j-i+1), ...
                             thisBundle(:, i+1));
                        
                Rm = Rm + ...
                deltaHat(j+1, i+1)*3*thisTerm;
            end
        end

        thisBundle(:, m+1) = A_hom\Rm;
    end
    
    Q_bundle(:, n+1, :) = thisBundle;
end


return
