function P_theta = derivative_Parm(P, M, N)

P_theta = zeros(N+1, M+1);

for m = 0:M-1
   P_theta(:, m+1) = (m+1)*P(:, m+2); 
end

end

