function Q_bundle_inverse = ...
    computeFormalSeries_1D_slowBundleInverse_SH(...
                   Q0_inv, Q_bundle, M, N)
                    
Q_bundle_inverse = intval(zeros(N+1, N+1, M+1));
Q_bundle_inverse(:, :, 1) = Q0_inv;

Id = eye(N+1);

for m = 1:M
   disp([' (m/M) = ' num2str(m) ' / ' num2str(M)])
%    m
%    M
   Bm = intval(zeros(N+1, N+1));
   for k = 0:m-1
      Bm = Bm + Q_bundle(:, :, m-k+1)*Q_bundle_inverse(:, :, k+1);
   end
    
   Q_bundle_inverse(:, :, m+1) = -Q0_inv*Bm;
    
end

return
            