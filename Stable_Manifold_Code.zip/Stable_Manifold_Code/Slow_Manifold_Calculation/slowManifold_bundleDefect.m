function [E_Bundle_bounds, E_Bundles] = ...
    slowManifold_bundleDefect(...
        Ps, lambda_slow1, Sigma1, Q_bundle, gamma, beta, M, N)

E_Bundle_bounds = intval(zeros(3, 3*N+1));
E_Bundles = intval(zeros(3*N+1, 3*N+1, 3*M+1));

for n = 0:N
    n
    lambda_n = Sigma1(n+1, n+1);
    Qn = reshape(Q_bundle(:, n+1, :), [N+1, M+1]);
    En = intval(zeros(3*N+1, 3*M+1));

    k=(0:N)';
    k2 = k.^2;
    k4 = k.^4;
    L_operator = -gamma*k4 - beta*k2 + 1;

    Sm = cosinetaylorconvolution(Ps, Ps, Qn);
    thisDefect = intval(zeros(3*N+1, 3*M+1));
    
    for m = 0:M
        thisDefect(1:N+1, m+1) = ...
            (lambda_n + m*lambda_slow1)*Qn(:, m+1) ...
        - L_operator.*Qn(:, m+1);
    end
    
    thisDefect = thisDefect + 3*Sm;
    E_Bundles(:, n+1, :) = reshape(thisDefect, [3*N+1, 1, 3*M+1]);
    
end

end






















