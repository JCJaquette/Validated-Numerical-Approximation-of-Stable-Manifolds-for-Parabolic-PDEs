function norm = parmNorm_D2_N_intval(P, nu, M, N, delta, norm_of_1_theta)

Mbig = size(P, 2)-1;
norm = intval(0);
for m = 0:Mbig-2
    norm = norm + (m+2)*(m+1)*ellOneNorm_N_intval(P(:, m+3), nu, N)*(delta^m);
end

norm = norm /norm_of_1_theta^2;

end