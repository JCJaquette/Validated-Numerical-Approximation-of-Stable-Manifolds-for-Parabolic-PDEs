function thisMatrixNorm = operatorBound_X_X_intval(B, Q, nu, N)

    % We compute the weights which give us the X-norm
    New_Norms = intval(zeros(1,N+1));
    for i = 1:N+1
        New_Norms(i)=ellOneNorm_intval(Q(:,i),nu,N);
    end

    thisMatrixNorm = intval(0);
    for n = 0:N
        this_Bn_norm = norm_X( B(1:N+1, n+1) , New_Norms);
        thisMatrixNorm = ...
            hull(thisMatrixNorm, this_Bn_norm/New_Norms(n+1));
    end
    
    thisMatrixNorm = intval(sup(thisMatrixNorm));
    
end




