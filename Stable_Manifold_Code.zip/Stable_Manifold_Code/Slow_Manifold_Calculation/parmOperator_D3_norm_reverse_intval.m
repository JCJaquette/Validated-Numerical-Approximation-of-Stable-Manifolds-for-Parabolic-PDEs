function norm = parmOperator_D3_norm_reverse_intval(Q, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)

norm = intval(0);
for m = 0:M-3
    norm = norm + (m+3)*(m+2)*(m+1)*...
        norm_X_to_ell(Q(:, :, m+4), nu, New_Norms)*(delta^m);
%         operatorBound_X_l1_intval(Q(:, :, m+4),Q0, nu, N)*(delta^m);

end

norm = norm /norm_of_1_theta^3;

end