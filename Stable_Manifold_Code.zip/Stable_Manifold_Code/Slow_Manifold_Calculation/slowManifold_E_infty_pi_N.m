function [E_infty_pi_N,  E_infty_pi_inf]= slowManifold_E_infty_pi_N(Ps, nu, M, N, delta, norm_of_1_theta)

Ps_squared = cosinetaylorconvolution(Ps, Ps);
% Bounds the norm of the vector P(theta)*P(theta) for all theta. 
Ps_squared_norm = parmNorm_intval(Ps_squared, eye(2*N+1), nu, 2*M, 2*N,delta, norm_of_1_theta);
E_infty_pi_inf = 3*Ps_squared_norm ;

E_infty_pi_N = intval('0');
for m = 0:2*M
    
    this_AlphaBeta = dualBounds_quadratic(Ps_squared(:, m+1), nu, N);
    E_infty_pi_N = E_infty_pi_N + ...
                  ellOneNorm_intval(this_AlphaBeta, nu, N)*(delta^m);
    
end

E_infty_pi_N = 3*E_infty_pi_N;

end