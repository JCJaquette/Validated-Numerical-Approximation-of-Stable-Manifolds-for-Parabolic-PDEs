function AlphaBeta = dualBounds_quadratic(a, nu, N)


Alpha = intval(zeros(N+1, 1));
Beta = intval(zeros(N+1, 1));  % This variable conflicts with equation param


for n = 0:N
    
    thisMax = intval(0);
    for k = N+1:2*N-n
        thisCoef = abs(a(n+k+1))/(2*nu^k);
        if sup(thisCoef) > sup(thisMax)
            thisMax = thisCoef;
        end
    end
    Alpha(n+1) =  thisMax;
    
    thisMax = intval(0);
    for k = N+1:2*N+n
       thisCoef = abs(a(k-n+1))/(2*nu^k);
       if sup(thisCoef) > sup(thisMax)
            thisMax = thisCoef;
        end
    end
    Beta(n+1) = thisMax;
end

AlphaBeta = Alpha + Beta;

