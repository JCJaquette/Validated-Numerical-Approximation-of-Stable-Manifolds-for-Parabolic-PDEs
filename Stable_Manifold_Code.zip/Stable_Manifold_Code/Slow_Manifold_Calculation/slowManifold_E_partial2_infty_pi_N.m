function [E_partial2_infty_pi_N , E_partial2_infty_pi_inf]= ...
    slowManifold_E_partial2_infty_pi_N(Ps, nu, M, N, delta, norm_of_1_theta)


d2Ps = derivative2_Parm(Ps, M, N);
d1Ps = derivative_Parm(Ps, M, N);

d2P_P = cosinetaylorconvolution(d2Ps, Ps);
d1P_d1P = cosinetaylorconvolution(d1Ps, d1Ps);

d2E_inf = 6*(d2P_P + d1P_d1P);

d2E_inf_norm = parmNorm_intval(d2E_inf, eye(2*N+1), nu, 2*M, 2*N, delta, norm_of_1_theta);

E_partial2_infty_pi_inf = d2E_inf_norm ;
E_partial2_infty_pi_N = intval('0');

for m = 0:2*M
    
    this_AlphaBeta = dualBounds_quadratic(d2E_inf(:, m+1), nu, N);
    E_partial2_infty_pi_N = E_partial2_infty_pi_N + ...
                  ellOneNorm_intval(this_AlphaBeta, nu, N)*(delta^m);
    
end

E_partial2_infty_pi_N   = E_partial2_infty_pi_N     /norm_of_1_theta^2;
E_partial2_infty_pi_inf = E_partial2_infty_pi_inf   /norm_of_1_theta^2;

end
