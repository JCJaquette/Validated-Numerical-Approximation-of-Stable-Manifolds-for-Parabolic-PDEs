function norm = parmOperator_D1_norm_reverse_intval(Q, Q0, nu, M, N,delta, norm_of_1_theta,New_Norms)
% Norm of an theta-dependant operator from : X -> ell^1
norm = intval(0);
for m = 0:M-1
%     norm = norm + (m+1)*operatorBound_X_l1_intval(Q(:, :, m+2),Q0, nu, N)*(delta^m);
    norm = norm + (m+1)*norm_X_to_ell(Q(:, :, m+2), nu, New_Norms)*(delta^m);
end

norm = norm /norm_of_1_theta;

end