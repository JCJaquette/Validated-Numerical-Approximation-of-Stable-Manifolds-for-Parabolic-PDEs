function DF = swiftHohenbergDifferential_cos_intval(a, gamma, beta)

m=length(a);
i3=intval(3);

% We make sure that the inputs for FFT are powers of 2 %
m1=(2^ceil(log(4*m-1)/log(2))-4*m)/2;   % Hence 4*m+2*m1 is a power of 2 %
ta=[intval(zeros(m+m1+1,1));flip(a(2:m),1);a;intval(zeros(m+m1,1))];

%tc=[intval(zeros(m+m1+1,1));flip(c(2:m),1);c;intval(zeros(m+m1,1))];

tu=verifyfft(ifftshift(ta),-1);
%tv=verifyfft(ifftshift(tc),-1);

AC=fftshift(verifyfft(tu.*tu),1);
ac=real((4*m+2*m1)*AC(m1+m+2:m1+4*m-1));

DF_nonlinear=intval(zeros(m));
DF_nonlinear(:,1)=i3*ac(m:2*m-1);
k=(0:m-1)';

for ell=1:m-1
    DF_nonlinear(:,ell+1)=i3*(ac(k-ell+m)+ac(k+ell+m));
end 


N=length(a)-1;
k=intval((0:N)');
k2 = k.^2;
k4 = k.^4;


L_operator = -gamma*k4 -beta*k2 + 1;

DF = diag(L_operator) - DF_nonlinear;

end








