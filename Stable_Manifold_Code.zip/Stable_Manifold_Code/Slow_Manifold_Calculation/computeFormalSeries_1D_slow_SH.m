function [Ps, coefSizes] = computeFormalSeries_1D_slow_SH(...
                a, xi_slow1, lambda_slow1, ...
                gamma, beta, scale_ss1, ...
                nu, N, M)


DFa1 = mid(swiftHohenbergDifferential_cos_intval(...
                a, gamma, beta));

Ps = zeros(N+1, M+1);
Ps(:, 1) = a;
Ps(:, 2) = scale_ss1*xi_slow1;

Id = eye(N+1);

k=(0:N)';
k2 = k.^2;

coefSizes = zeros(1, M+1);
coefSizes(1) = sup(ellOneNorm_intval(Ps(:, 1), nu, N));
coefSizes(2) = sup(ellOneNorm_intval(Ps(:, 2), nu, N));

for n = 2:M
    disp(['n = ' num2str(n)])
    
    theMax_thisOrder = 0;  
    A_homMat = DFa1 - n*lambda_slow1*Id; 
    Sn = zeros(N+1, 1);
    
    deltaHat = ones(n+1, n+1);
    deltaHat(1, 1) = 0;
    deltaHat(n+1, 1) = 0;
    deltaHat(n+1, n+1) = 0;
    
    for j = 0:n
        for i = 0:j
           thisTerm = ...
                cubic_FFT(...
                             Ps(:, n-j+1), ...
                             Ps(:, j-i+1), ...
                             Ps(:, i+1));
                        
           Sn = Sn + ...
                deltaHat(j+1, i+1)*thisTerm;
        end
    end
     
    thisCoef = A_homMat\Sn;
    Ps(:, n+1) = thisCoef;
    thisMax = mid(ellOneNorm_intval(thisCoef, nu, N));  
    coefSizes(n+1) = thisMax;
end



return