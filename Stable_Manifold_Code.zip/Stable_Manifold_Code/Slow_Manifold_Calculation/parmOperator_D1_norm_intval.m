function norm = parmOperator_D1_norm_intval(Q, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)

norm = intval(0);
for m = 0:M-1
    norm = norm + (m+1)*operatorBound_l1_X_intval(Q(:, :, m+2), Q0, nu, N)*(delta^m);
end

norm = norm /norm_of_1_theta;

end