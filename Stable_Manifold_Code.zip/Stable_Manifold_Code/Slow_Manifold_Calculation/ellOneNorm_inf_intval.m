function norm_N = ellOneNorm_inf_intval(a, nu, N)

Nbig = size(a, 1)-1;
a_inf = [zeros(N+1, 1); a(N+2:end)];
norm_N = ellOneNorm_intval(a_inf, nu, Nbig);

end



