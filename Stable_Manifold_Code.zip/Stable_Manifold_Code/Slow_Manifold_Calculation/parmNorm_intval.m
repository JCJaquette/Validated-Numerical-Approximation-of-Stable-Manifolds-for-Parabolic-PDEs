function norm = parmNorm_intval(P, Q0, nu, M, N, delta, norm_of_1_theta)

norm = intval(0);
for m = 0:M
    norm = norm + ellOneNorm_intval(P(:, m+1), nu, N)*(delta^m);
end

end