function [Bundle_tailBound_D0 ,Bundle_tailBound_D1, Bundle_tailBound_D2 ] = validateBound_inverseBundle(...
    Q_bundle, Q_bundle_inverse, Q0, nu, delta,New_Norms, N, M, norm_of_1_theta, Bundle_bound_D1, Bundle_bound_D2) 



 A0_inv_norm = ...
     operatorBound_l1_X_intval(Q_bundle_inverse(:, :, 1), Q0, nu, N);
  
 
 A0_inv = Q_bundle_inverse(:, :, 1);
 
 C = intval(0);
 
 
 for m = fliplr(1:M)
%      disp([num2str(m) '/' num2str(M)])
     A_now = Q_bundle(:, :, m+1);
     C = C + norm_X_to_X( A0_inv*A_now, New_Norms)*delta^m;
 end
 
 C

 
 if ~(C<1)
     msg = 'We cannot validate the inverted bundles B(\theta); C > 1.';
     error(msg);
 end
  
 
 
 %Then AM(z)^{-1} bound is:
 
 AM_inv_bound       = A0_inv_norm/(1 - C);
 AM_inv_bound_D1    = AM_inv_bound^2 * Bundle_bound_D1;
 AM_inv_bound_D2    = 2*AM_inv_bound^3 * Bundle_bound_D1^2 + AM_inv_bound^2 * Bundle_bound_D2;
 
 %Calculate the defect:
 
%  EM_bound = intval(0);
 EM_bound_total = intval(zeros(2*M+1,1));
for m = M+1:2*M
%     disp([num2str(m) '/' num2str(2*M)])
    thisOperator = intval(zeros(N+1, N+1));
    for k = 0:m
        if ((m - k) <= M) && (k <= M)
            Op1 = Q_bundle_inverse(:, :, k+1);  
            Op2 = Q_bundle(:, :, m-k+1);
            thisOperator = thisOperator + Op2*Op1;
        end
    end
    thisNorm = ellNuOne_MatrixNorm_intval(thisOperator, nu, N);
    EM_bound_total(m+1) = thisNorm;
%    EM_bound = EM_bound + thisNorm*delta^m;
end

delta_powers      = delta.^(0:2*M);
delta_powers_D1   = delta.^(0:2*M-1) .* (1:2*M);    
delta_powers_D2   = delta.^(0:2*M-2) .* (1:2*M-1)  .* (2:2*M);    

EM_bound    = dot(EM_bound_total(1:2*M+1),delta_powers)       /(norm_of_1_theta^0);
EM_bound_D1 = dot(EM_bound_total(2:2*M+1),delta_powers_D1)    /(norm_of_1_theta^1);
EM_bound_D2 = dot(EM_bound_total(3:2*M+1),delta_powers_D2)    /(norm_of_1_theta^2);


%figure
%hold on 
%plot(0:(length(E_slow_norms)-1)         , log(E_slow_norms)/log(10), 'b*')
%plot(0:(length(Bundel_defect_norms)-1)  , log(Bundel_defect_norms)/log(10), 'g*')
%plot(0:(length(EM_bound_total)-1)  , log(EM_bound_total)/log(10), 'r*')

Bundle_tailBound_D0 = AM_inv_bound    * EM_bound;
Bundle_tailBound_D1 = AM_inv_bound_D1 * Bundle_tailBound_D0     +  AM_inv_bound    * EM_bound_D1;
Bundle_tailBound_D2 = AM_inv_bound_D2 * Bundle_tailBound_D0     +2*AM_inv_bound_D1 * EM_bound_D1    + AM_inv_bound * EM_bound_D2;

end
