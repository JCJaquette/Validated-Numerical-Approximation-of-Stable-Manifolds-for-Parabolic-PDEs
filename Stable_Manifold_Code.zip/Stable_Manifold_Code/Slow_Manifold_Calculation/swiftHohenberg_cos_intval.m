function F = swiftHohenberg_cos_intval(a, gamma, beta)

N=length(a)-1;
k=intval((0:N)');
k2 = k.^2;
k4 = k.^4;

L_operator = -gamma*k4 - beta*k2 + 1;
aaa = int_cubic_sumFFT(a,a,a);
F = L_operator.*a - aaa;

