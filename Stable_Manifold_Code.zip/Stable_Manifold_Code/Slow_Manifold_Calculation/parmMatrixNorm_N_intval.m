function norm = parmMatrixNorm_N_intval(Q, Q0,nu, M, N, delta, norm_of_1_theta)
%  For a theta dependant operator Q: X_f \to \ell_\nu^1, computes 
% 
%  || \pi_N Q_f(\theta) \pi_N ||_{ X_f , \ell_\nu^1 }
% 
%  as a sup over all \theta \in [-1,1]



Mbig = size(Q, 3)-1;
norm = intval(0);
for m = 0:Mbig
    norm = norm + ellNuOne_MatrixNorm_N_intval(Q(:, :, m+1), nu, N)*(delta^m);
end

end