function E_slow = ...
    slowManifold_fullDefect(Ps, L_operator, lambda_slow1, M, N)

E_slow = intval(zeros(3*N+1, 3*M+1));
P_cubed = cosinetaylorconvolution(Ps, Ps, Ps);
DP_lambda = intval(zeros(3*N+1, 3*M+1));
LP = intval(zeros(3*N+1, 3*M+1));

for m = 0:M
    
    thisColumn1 = L_operator.*Ps(:, m+1);
    thisColumn2 = m*lambda_slow1*Ps(:, m+1);
    
    LP(1:N+1, m+1) = thisColumn1;
    DP_lambda(1:N+1, m+1) = thisColumn2;
    
end

FP = LP - P_cubed;
E_slow = FP - DP_lambda;

end