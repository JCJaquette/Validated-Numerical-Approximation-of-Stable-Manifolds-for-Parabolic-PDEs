function norm = ellOneNorm_intval(a, nu, N)

%normEntries = intval(zeros(1, N+1));
%normEntries(1) = abs(a(1));

normVector = ones(1, N+1)*nu;
exponentVect = linspace(0, N, N+1);
normVector = normVector.^exponentVect;
normVector = normVector*2;
normVector(1) = 1;

%for n = 1:N
%    normEntries(n+1) = 2*abs(a(n+1))*nu^n;
%end

% normEntries = abs(a).*normVector';
% norm = sum(normEntries);

norm = dot(abs(a),normVector); % this is faster


end