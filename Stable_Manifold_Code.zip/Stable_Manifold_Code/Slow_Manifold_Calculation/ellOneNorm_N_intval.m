function norm_N = ellOneNorm_N_intval(a, nu, N)


aN = a(1:N+1);
norm_N = ellOneNorm_intval(aN, nu, N);

end














