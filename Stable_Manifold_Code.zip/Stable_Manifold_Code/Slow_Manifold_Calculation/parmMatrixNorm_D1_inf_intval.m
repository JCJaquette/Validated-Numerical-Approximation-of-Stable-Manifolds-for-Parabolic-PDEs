function norm = parmMatrixNorm_D1_inf_intval(Q,Q0, nu, M, N, delta, norm_of_1_theta)
% Q0 - defines the X-norm

% We take the projection \pi_\infty
Q(1:N+1,:,:) = 0*Q(1:N+1,:,:);

% We compute the weights which give us the X-norm
New_Norms = intval(zeros(1,N+1));
for i = 1:N+1
    New_Norms(i)=ellOneNorm_intval(Q0(:,i),nu,N);
end

num_columns = N+1; % Q_f is a  N+1 x N+1 matrix
num_rows    = length(Q(:, 1, 1));

Mbig = size(Q, 3)-1;
norm = intval(0);
for m = 0:Mbig-1
%     norm = norm + (m+1)*ellNuOne_MatrixNorm_inf_intval(Q(:, :, m+2), nu, N);
    norm = norm + (m+1)*norm_X_to_ell_infty( Q(:, :, m+2) ,nu, New_Norms,num_rows,num_columns)*(delta^m);
end

norm = norm /norm_of_1_theta;

end