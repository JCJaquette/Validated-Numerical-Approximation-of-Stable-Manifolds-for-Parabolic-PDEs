function a = equilibriumNewton_SH(a_now, gamma, beta, nu, N)

norm_anow = ellOneNorm_intval(a_now, nu, N);


for j = 1:6
   j 
   Fa_now = swiftHohenberg_cos(...
                a_now, gamma, beta);
            
   DFa_now = mid(swiftHohenbergDifferential_cos_intval(...
                a_now, gamma, beta));
   
   a_now = a_now - DFa_now\Fa_now;

   DFa_test = mid(swiftHohenbergDifferential_cos_intval(...
                a_now, gamma, beta));
   
   A = inv(DFa_test);
   
   Fa_now = mid(swiftHohenberg_cos_intval(...
       a_now, gamma, beta));

   thisDefect = ellOneNorm_intval(A*Fa_now, nu, N)
   
end


a = a_now;


return