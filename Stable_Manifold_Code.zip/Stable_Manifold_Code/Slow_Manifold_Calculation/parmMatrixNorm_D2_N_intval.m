function norm = parmMatrixNorm_D2_N_intval(Q,Q0, nu, M, N, delta, norm_of_1_theta)
% Q0 - defines the X-norm
Mbig = size(Q, 3)-1;
norm = intval(0);
for m = 0:Mbig-2
    norm = norm + ...
        (m+2)*(m+1)*ellNuOne_MatrixNorm_N_intval(Q(:, :, m+3), nu, N)*(delta^m);
end

norm = norm/norm_of_1_theta^2;

end