function [E_partial_infty_pi_N , E_partial_infty_pi_inf]= ...
    slowManifold_E_partial_infty_pi_N(Ps, nu, M, N, delta, norm_of_1_theta)

partial_theta_Ps = derivative_Parm(Ps, M, N);

P1_P = cosinetaylorconvolution(partial_theta_Ps, Ps);
P1_P_norm = parmNorm_intval(P1_P, eye(2*N+1), nu, 2*M, 2*N,delta, norm_of_1_theta);

E_partial_infty_pi_inf = 6*P1_P_norm ;
E_partial_infty_pi_N = intval('0');

for m = 0:2*M
    
    this_AlphaBeta = dualBounds_quadratic(P1_P(:, m+1), nu, N);
    E_partial_infty_pi_N = E_partial_infty_pi_N + ...
                  ellOneNorm_intval(this_AlphaBeta, nu, N)*(delta^m);
    
end

E_partial_infty_pi_N = 6*E_partial_infty_pi_N;

E_partial_infty_pi_N    = E_partial_infty_pi_N      / norm_of_1_theta;
E_partial_infty_pi_inf  = E_partial_infty_pi_inf    / norm_of_1_theta;

end