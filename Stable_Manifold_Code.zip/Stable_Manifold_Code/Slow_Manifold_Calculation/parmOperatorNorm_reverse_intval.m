function norm = parmOperatorNorm_reverse_intval(Q, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)

norm = intval(0);
for m = 0:M
%     norm = norm + operatorBound_X_l1_intval(Q(:, :, m+1),Q0, nu, N);
    norm = norm + norm_X_to_ell(Q(:, :, m+1), nu, New_Norms)*(delta^m);
end

end