function F = swiftHohenberg_cos(a, gamma, beta)

N=length(a)-1;
k=(0:N)';
k2 = k.^2;
k4 = k.^4;

L_operator = -gamma*k4 - beta*k2 + 1;
aaa = cubic_FFT(a,a,a);
F = L_operator.*a - aaa;

