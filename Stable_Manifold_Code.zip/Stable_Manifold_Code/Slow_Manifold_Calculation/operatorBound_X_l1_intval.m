function thisMatrixNorm = operatorBound_X_l1_intval(A, Q, nu, N)
%  Note: JJ 2/09/20. I think it would speed things up a bit if we compute
%  the norms of the 
    thisMatrixNorm = intval(0);
    
    for n = 0:N
       An_norm = ellOneNorm_intval(A(1:N+1, n+1), nu, N);
       Qn_norm = ellOneNorm_intval(Q(1:N+1, n+1), nu, N);
       thisMatrixNorm = hull(thisMatrixNorm, An_norm/Qn_norm);
        
    end
    
    thisMatrixNorm = intval(sup(thisMatrixNorm));
   
end