function thisMatrixNorm = operatorBound_l1_X_intval(B, Q, nu, N)

    normVector = ones(1, N+1)*nu;
    exponentVect = linspace(0, N, N+1);
    normVector = normVector.^exponentVect;
    normVector = normVector*2;
    normVector(1) = 1;
    
    % We compute the weights which give us the X-norm
    New_Norms = intval(zeros(1,N+1));
    for i = 1:N+1
        New_Norms(i)=ellOneNorm_intval(Q(:,i),nu,N);
    end

    thisMatrixNorm = intval(0);
    for n = 0:N
%         this_Bn_norm = X_norm_intval(B(1:N+1, n+1), Q, nu, N);
        this_Bn_norm = norm_X( B(1:N+1, n+1) , New_Norms);
        thisMatrixNorm = ...
            hull(thisMatrixNorm, this_Bn_norm/normVector(n+1));
    end
    
    thisMatrixNorm = intval(sup(thisMatrixNorm));
    
end