% Make sure to comment out radii in the main program. 

clear
a_bundles_a1_proof

radii_min = 1e-10;
radii_max = 2.2e-2;

Max_steps = 30;
delta_r = (log(radii_max) - log(radii_min) ) / Max_steps;

radii_list = (0:Max_steps).*delta_r +log(radii_min);
radii_list = exp(radii_list);

radii_list_infty = [];

% error_list = zeros(1,Max_steps+1);
% cone_list = zeros(1,Max_steps+1);
% contraction_list = zeros(1,Max_steps+1);

error_list=[];
cone_list=[];
cone_list_finite=[];
cone_list_tail=[];
contraction_list=[];

P_u_ss =[];
P_u_s_infty =[];
P_u_infty_infty =[];

tic
for it_radii = 1:Max_steps +1
%     radii = [radii_list(it_radii);   radii_list(it_radii)/2];    
    radii = [radii_list(it_radii); 0];    
    main;
    
    if total_success
%         if sup(P_u_s_s(1,1,1)) >10
%             radii_list = radii_list(1:it_radii-1);
%             break;
%         end
        
        disp('We are verified!!!!')    
        cone_list(it_radii) = max(sup(P_u_s));
        cone_list_finite(it_radii) = sup(P_u_s(1));
        cone_list_tail(it_radii) = sup(P_u_s(2));
        error_list(it_radii) = sup(abs_error);
        contraction_list(it_radii) = sup(Jnorm);
        radii_list_infty(it_radii) = sup(radii(2));
        

        
        P_u_ss(it_radii)            = sup(P_u_s_s(1,1,1));
        P_u_s_infty(it_radii)       = sup(P_u_s_s(1,1,2));
        P_u_infty_infty(it_radii)   = sup(P_u_s_s(1,2,2));
        
    else 
        radii_list = radii_list(1:it_radii-1);
        break;
    end
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%             Plots the data 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Parameters .....

line_width = 1.6;
figure_height   = 700;
figure_width    = 350;
font_size       = 11;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plotting
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure('position', [800, 150, figure_width, figure_height]) 
set(gca,'FontSize', font_size)
hold on

% % % % % % 
% % % % % % % plot(radii_list,error_list)
% % % % % % % plot(radii_list,cone_list)
% % % % % % C2_error = P_u_ss+P_u_s_infty+P_u_infty_infty;
% % % % % % C2_error_norm =  P_u_ss;
% % % % % % for i = 1:length(P_u_ss)
% % % % % %     P2_local = [P_u_ss(i),P_u_s_infty(i);P_u_s_infty(i),P_u_infty_infty(i)];
% % % % % %     C2_error_norm(i) = norm(P2_local );
% % % % % % end



The_Color_Order = get(gca,'colororder');

color_contract  = The_Color_Order(1,:);
color_C0_bound  = The_Color_Order(2,:);
color_slow      = The_Color_Order(3,:);
color_fast      = The_Color_Order(4,:);
color_infty     = The_Color_Order(5,:);



plot(radii_list,contraction_list,   '--','Color',color_contract  ,'LineWidth',line_width )
plot(radii_list,error_list,         '-.','Color',color_C0_bound  ,'LineWidth',line_width )
plot(radii_list,cone_list_finite,   '-','Color',color_slow      ,'LineWidth',line_width)
plot(radii_list,cone_list_tail,     '-','Color',color_infty     ,'LineWidth',line_width )     
plot(radii_list,radii_list_infty,   ':','Color',color_infty     ,'LineWidth',line_width )
% plot(radii_list,C2_error )
% plot(radii_list,C2_error_norm)
hold off

figure
plot(log(radii_list(11:end)),log(error_list(11:end)))

xlabel('\rho_f')
% ylabel('absolute error')
set(gca,'xscale','log')
set(gca,'yscale','log')
% legend({'C_0 bound','C_1 bound','Contraction Constant'},'Location','southeast')
% legend({'C_0 bound','C_1 bound (slow)','C_1 bound (tail)','Contraction Constant'},'Location','southeast')
% legend({'Contraction Constant','C^1 bound (slow)','C^1 bound (tail)','C^2 bound'},'Location','northwest')

legend({'Contraction Constant','C^0 bound','C^1 bound (slow)','C^1 bound (tail)','\rho_{\infty}'},'Location','northwest')

set(gca,'XLim',[radii_min,.1])
set(gca,'YLim',[10^-18,1])


set(gcf,'position', [1000, 150, figure_width*1.5, figure_height])
pause(0.1)
xticks('manual')
set(gcf,'position', [1000, 50, figure_width, figure_height])


% % % % %%%%%%%%%%%%%%%%%%%%%%%%%
% % % % figure
% % % % hold on
% % % % 
% % % % plot(radii_list,P_u_ss,'LineWidth',line_width )
% % % % plot(radii_list,P_u_s_infty,'LineWidth',line_width )
% % % % plot(radii_list,P_u_infty_infty,'LineWidth',line_width )
% % % % 
% % % % 
% % % % hold off
% % % % title('C^2 Error Scaling')
% % % % xlabel('\rho_{f}')
% % % % % ylabel('absolute error')
% % % % % set(gca,'xscale','log')
% % % % % set(gca,'yscale','log')
% % % % 
% % % % legend({'P_u^{11}','P_u^{12}','P_u^{22}'},'Location','southeast')
% % % % % set(gca,'XLim',[radii_min,.1])
% % % % set(gca,'XLim',[radii_min,.025])
% % % % 

% % % % % 
% % % % % figure
% % % % % hold on
% % % % % 
% % % % % C2_error = P_u_ss+P_u_s_infty+P_u_infty_infty;
% % % % % C2_error_norm =  P_u_ss;
% % % % % for i = 1:length(P_u_ss)
% % % % %     P2_local = [P_u_ss(i),P_u_s_infty(i);P_u_s_infty(i),P_u_infty_infty(i)];
% % % % %     C2_error_norm(i) = norm(P2_local );
% % % % % end
% % % % % 
% % % % % 
% % % % % line_width = 1.6;
% % % % % 
% % % % % plot(radii_list,contraction_list,'LineWidth',line_width )
% % % % % plot(radii_list,error_list,'LineWidth',line_width )
% % % % % plot(radii_list,cone_list_finite,'LineWidth',line_width )
% % % % % plot(radii_list,cone_list_tail,'LineWidth',line_width )
% % % % % 
% % % % % hold off
% % % % % 
% % % % % xlabel('\rho_{\infty}')
% % % % % % ylabel('absolute error')
% % % % % set(gca,'xscale','log')
% % % % % set(gca,'yscale','log')
% % % % % 
% % % % % 
% % % % % legend({'Contraction Constant','C_0 bound','C^1 bound (slow)','C^1 bound (tail)'},'Location','northwest')
% % % % % 
% % % % % set(gca,'XLim',[1e-10,.1])
% % % % % set(gca,'YLim',[10^-18,1])



toc