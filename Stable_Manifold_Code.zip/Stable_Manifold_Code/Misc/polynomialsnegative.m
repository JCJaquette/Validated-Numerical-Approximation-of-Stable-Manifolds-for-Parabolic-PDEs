function rmin=polynomialsnegative(Y,Z,W)
% this accompanies SHproofproofandeigenvalues
% determines "near minimal" verification radii

if length(Y)==1 % equilibrium problem
    n=length(W)+1;
    C=[sup(Y),sup(Z)-1,sup(W)];
    p0=C(1);
    p0(p0==0)=1;
    polfloat=@(r) C*r.^(0:n)'/p0;
    polintval=@(r) intval(C)*r.^(0:n)';
    r0=-C(1)/C(2);
    r1=fzero(@(r) polfloat(r),r0);
    rmin=guarantee(polintval,r1);
elseif length(Y)==2 % eigenvalue problem
    C0=sup(Y);
    C1=sup(Z)-eye(2);
    C2=sup(W);
    p0=C0;
    p0(p0==0)=1;
    polfloat=@(r) (C0+C1*r+C2*r(1)*r(2))./p0;
    polintval=@(r) intval(C0)+intval(C1)*r+intval(C2)*r(1)*r(2);
    r0=-C1\C0;
    options=optimoptions('fsolve','FunctionTolerance',1e-8,'StepTolerance',1e-8,'Display','none');
    r1=fsolve(@(r) polfloat(r),r0,options);
    rmin=guarantee(polintval,r1);
end
end

function rmin=guarantee(polintval,r)

if ~all(r>=0)
    rmin=NaN;
elseif all(polintval(intval(r))<0) 
    rmin=r;
else
    r=max(r,min(max(r),eps)); %make sure no zero components
    success=false;
    j=-52;
    while ~success && j<52
        rmin=r*(1+2^j);
        if all(polintval(intval(rmin))<0) 
            success=true;
        end
        j=j+1;
    end
    if ~success
        rmin=NaN(size(r));
    end
end

end

