function [convolution] = convo(a1,a2,len)
% returns the convolution of a1 and a2 of length len+1
% in the symmetric setting
% the default for len is length(a1)+length(a2)-2

N = length(a1)-1;
M = length(a2)-1;
if ~exist('len','var')
    len = N+M;
end
convolution = convmatrix(a1,len,M)*a2;

return