function out = norm_X( vector , New_Norms)
%norm_X Computes the ||.||_X norm of a N+1 vector
%       See Section 6.1, equation (50)
%       "New_Norms" is a vector of the weights |q_n|_ell^1_nu
% 
% Last Modified:  02-07-2020

    out = dot(abs(vector),New_Norms);
    
end
