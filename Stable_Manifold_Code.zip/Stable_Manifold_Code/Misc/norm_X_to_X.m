function norm_bound =  norm_X_to_X( M , New_Norms)
%norm_X_to_X - Computes X -> X norm of an operator ASSUMING 0 in tail
%     Assume M^N is a (N+1) x (N+1) matrix and M is a ZERO map in the tail
%     cf. Section 6 between (50)-(51).
% 
%     New_Norms is a N+1 vector with elements || q_k ||_ell^1_nu  
%     where q_k is the k^th column of the matrix Q
% 
% Last Modified:  02-07-2020
    N = length(New_Norms)-1;
%   Takes MAX over column vectors:
%       || M_k^N ||_X  /  || q_k ||_ell^1_nu

    col_norm_list = intval(zeros(1,N+1));
    for k = 1:N+1
        col_norm_list(k) = norm_X( M(:,k),New_Norms);
    end    
    col_norm_list = col_norm_list./New_Norms;
    norm_bound = max(col_norm_list);
    norm_bound = intval(sup(norm_bound));        
end