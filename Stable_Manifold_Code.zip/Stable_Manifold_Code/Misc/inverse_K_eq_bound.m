function [ r0,success ] = inverse_K_eq_bound( epsilon, Ps, Q_bundle, Q0, nu, New_Norms, M)
%inverse_K_eq_bound -- This function bounds K^{-1}(\tilde{a}) - the true
%equilibrium. We may write: 
% 
%  \tilde{h}_0 = Q_0^{-1}(\tilde{a} - \bar{a}
%       &
%   K^{-1}(\tilde{a}) = \tilde{h}_0 + \tilde{h}_1
% 
%   The output of this function is a bound ||\tilde{h}_1|| < r_0.
% 
%   If the theorem cannot be proved, then r0 = NaN
% Last Modified:  Apr 11, 2020

% Epsilon_tilde 
    epsilon_tilde = norm_ell_to_X( inv(Q0) , nu, New_Norms) * epsilon;

%     We bound the coefficients of Q_0^{-1}P(\theta) &  Q_0^{-1}Q(\theta)  
    Q0_inv_P = intval(zeros(1,M+1));
    Q0_inv_Q = intval(zeros(1,M+1));

    for m = 1:M+1
        Q0_inv_P(m) = norm_X( Q0\Ps(:,m) , New_Norms);
        Q0_inv_Q(m) = norm_X_to_X( Q0\Q_bundle(:,:,m) , New_Norms);
    end
    
    % We calculate Y_0 bound 
    Y0 = Y_bound(Q0_inv_P,Q0_inv_Q, epsilon_tilde,M);
    
%   Obtain optimal value for r0.
    r0 =intval(0);
    for i = 1:4
        r0 = Y0 + r0 * G_all(Q0_inv_P,Q0_inv_Q, epsilon_tilde, r0 ,M);
        r0 = intval(sup(r0));
    end
%     Inflate r0
    r0 = (1+1e-11)*r0;
    r0 = intval(sup(r0));
    
%     Test if radii-polynomial inequality is satisfied
    if Y0 + r0 * G_all(Q0_inv_P,Q0_inv_Q, epsilon_tilde, r0 ,M) < r0
        success = 1;
    else
        success = 0;
        r0 = NaN;
    end


end

function g1_out = G1(Q0_inv_P, epsilon_tilde, r0 ,M)
    g1_out = intval(0);
    eps_plus_r = epsilon_tilde + r0;
    for m = fliplr(2:M)
        g1_out = g1_out + Q0_inv_P(m+1) * m * (eps_plus_r)^(m-1); 
    end
end

function g2_out = G2(Q0_inv_Q, epsilon_tilde, r0 ,M)
    g2_out = intval(0);
    eps_plus_r = epsilon_tilde + r0;
    for m = fliplr(1:M)
        g2_out = g2_out + Q0_inv_Q(m+1) * m * (eps_plus_r)^m; 
    end
end

function g3_out = G3(Q0_inv_Q, epsilon_tilde, r0 ,M)
    g3_out = intval(0);
    eps_plus_r = epsilon_tilde + r0;
    for m = fliplr(1:M)
        g3_out = g3_out + Q0_inv_Q(m+1) * (eps_plus_r)^m; 
    end
end

function g_out = G_all(Q0_inv_P,Q0_inv_Q, epsilon_tilde, r0 ,M)
    g1_out = G1(Q0_inv_P, epsilon_tilde, r0 ,M);
    g2_out = G2(Q0_inv_Q, epsilon_tilde, r0 ,M);
    g3_out = G3(Q0_inv_Q, epsilon_tilde, r0 ,M);
    g_out = g1_out + g2_out + g3_out;
end


function Y0 = Y_bound(Q0_inv_P,Q0_inv_Q, epsilon_tilde,M)
    sum1 = intval(0);
    for m = fliplr(2:M)
        sum1 = sum1 + Q0_inv_P(m+1) * (epsilon_tilde)^m; 
    end
    
    sum2 = intval(0);
    for m = fliplr(1:M)
        sum2 = sum2 + Q0_inv_Q(m+1) * (epsilon_tilde)^(m+1); 
    end

    Y0 = sum1 + sum2;
end
