function norm_bound =  norm_ell_to_X( B , nu, New_Norms)
%norm_ell_to_X - Computes ell^1 -> X norm of (N+1)x(N+1) matrix 
%                cf. Section 6 between (50)-(51).
%                Assume B^N is a (N+1) x (N+1) matrix and IDENTITY in tail
%                
% Last Modified:  02-07-2020
    N = length(New_Norms)-1;
    
% omega_k  -- defined in section 6.1 between equations (45)&(46)
    nu_power = intval(2)*nu.^(0:N);
    nu_power(1)=intval(1);

%   Takes MAX over column vectors:
%       || B_k^N ||_X  /  omega_k
    col_norm_list = intval(zeros(1,N+1));
    for k = 1:N+1
        col_norm_list(k) = norm_X( B(:,k),New_Norms);
    end    
    col_norm_list = col_norm_list ./ nu_power;
    norm_bound = max(col_norm_list);
%     Assumes identity in the tail
    norm_bound = max([norm_bound, intval(1)]);
    
    norm_bound = intval(sup(norm_bound));
        
end