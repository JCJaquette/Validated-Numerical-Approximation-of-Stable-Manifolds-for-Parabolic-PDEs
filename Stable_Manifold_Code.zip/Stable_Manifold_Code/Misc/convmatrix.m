function [matrix] = convmatrix(a,dim1,dim2)
% returns the dim1+1 x dim2+1 matrix that 
% represents convolution with the vector a
% in the symmetric setting
% the default for dim2 is length(a)
% the default for dim1 is dim2+length(a)

N = length(a)-1;
if ~exist('dim2','var')
    dim2 = N;
end
if ~exist('dim1','var')
    dim1 = dim2+N;
end
diffdim = dim2-N;
if diffdim >= 0
  syma = [zeros(diffdim,1);a(end:-1:2);a;zeros(diffdim,1)]';
  toep = toeplitz([syma(1);zeros(dim1,1)],syma);
else
  syma = [a(end+diffdim:-1:2);a(1:end+diffdim)]';
  toep = toeplitz([a(end+diffdim:end);zeros(dim1+diffdim,1)],syma);
end
matrix = toep(:,dim2+1:2*dim2+1);
matrix(:,2:end) = matrix(:,2:end)+toep(:,dim2:-1:1);

return

