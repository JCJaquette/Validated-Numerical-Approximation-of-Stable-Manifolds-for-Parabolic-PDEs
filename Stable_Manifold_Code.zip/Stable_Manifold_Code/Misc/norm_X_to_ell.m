function norm_bound =  norm_X_to_ell( Omega ,nu, New_Norms)
%norm_X_to_ell - Computes X -> ell^1 norm of an operator ASSUMING 0 in tail
%                Assume Omega^N is a (N+1) x (N+1) matrix and Omega is a ZERO map in the tail 
%                cf. Section 6 between (50)-(51).
% 
% Last Modified:  02-07-2020

    N =  length(New_Norms)-1;  
%   Takes MAX over column vectors:
%       || Omega_k^N ||_ell^1_nu  /  || q_k ||_ell^1_nu
    col_norm_list = intval(zeros(1,N+1));
    for k = 1:N+1
        col_norm_list(k) = ellOneNorm_intval(Omega(:,k),nu,N);
    end    
    col_norm_list = col_norm_list./New_Norms;
    norm_bound = max(col_norm_list);    
    norm_bound = intval(sup(norm_bound));
end