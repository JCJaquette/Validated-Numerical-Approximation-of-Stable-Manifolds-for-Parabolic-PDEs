function [success,r_proof,index,bounds] = SHproofMorseindex(a_in,beta2,beta1,N,nu)
% Stationary cosine series solution of the SH equation
% u_t = -beta_1 u_xxxx + beta_2 u_xx + u - u^3
% the cosine data should be in a_in:
% u = a0 + 2 sum a_n cos(nx)
% we use N modes to do the proof (padding or cutting if required)
% the norm is l^1_nu
%
% r_proof is the radius used in the proof
% index contains the Morse index (verified)
% bounds contains [Y0,Z0,Z1,Z2,Z3]

a_in = [a_in;zeros(N+1-length(a_in),1)];    %%% use a of length N+1
a_in = a_in(1:N+1); 

% interval arithmetic
a=intval(a_in);
beta=intval(beta2);
gamma=intval(beta1);
nu = intval(nu);

% increase N if it was really too small to make sense
Nmin = sqrt((-beta+sqrt(beta^2+4*gamma))/(2*gamma)); 
if ~(N >= sup(Nmin)) 
	N = ceil(sup(Nmin));
    a = [a;zeros(N+1-length(a),1)];
	display(['truncation dimension N was too small; increased N to ',int2str(N)])
end

Adag = DF_sh(a,beta,gamma);
A_a = real(inv(mid(Adag)));
A_a = intval((A_a+A_a')/2);

klong = intval(0:5*N)';
lambdalong = gamma*klong.^4+beta*klong.^2-1;
lambdaNp1 = lambdalong(N+2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Computation of the Y bound %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

residue = F_sh(a,beta,gamma);

tailtermY = convo(convo(a,a),a); 
tailtermY(1:N+1) = 0;
tailtermY(N+2:3*N+1) = tailtermY(N+2:3*N+1)./lambdalong(N+2:3*N+1);

Y0 = norml1nu(A_a*residue,nu)+norml1nu(tailtermY,nu);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Computation of the Z^0 bound %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Gamma = eye(N+1)-A_a*Adag;
Z0 = matrixnorml1nu(Gamma,nu);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Computation of the Z^1 bound %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tailtermZ1 = 3*norml1nu(convo(a,a),nu)/lambdaNp1;
chi = 1./weights(nu,3*N)';
A2=convmatrix(convo(a,a),5*N,3*N);
A2(1:N+1,1:N+1)=0;
Z1=tailtermZ1;
for i=1:3*N
    d_i=[A_a*A2(1:N+1,i);A2(N+2:5*N+1,i)./lambdalong(N+2:5*N+1)];
    Z1=max(Z1,norml1nu(d_i,nu)*chi(i));
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Computation of the coefficients of Z^2 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

norma = norml1nu(a,nu);
normAop=max(matrixnorml1nu(A_a,nu),1/lambdaNp1);
Z2=normAop*6*norma;
Z3=normAop*3; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%    Radii polynomial      %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    

bounds=sup([Y0,Z0,Z1,Z2,Z3]);
%disp(['bounds Y0, Z0, Z1, Z2, Z3 = ',num2str(bounds)]);

r_proof=polynomialsnegative(Y0,Z0+Z1,[Z2,Z3]);
success=~isnan(r_proof);    

if success
    disp(['The proof was successful with radius  ',num2str(r_proof)]);
    index=morseindex(-A_a);
    disp(['The number of unstable eigenvalues is  ',int2str(index)]);
else
    disp('The proof failed');
    index=NaN;
end

return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                         %%%
%%%   Auxiliary functions   %%%
%%%                         %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
function [F] = F_sh(a,beta,gamma)
% the Galerkin projection of the Swift-Hohenberg equation

N = length(a)-1;
k = (0:N)';

linear = -gamma*k.^4-beta*k.^2+1;
nonlinear = convo(convo(a,a),a,N);
F = linear.*a-nonlinear;
F(1)=F(1)/2;

return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [J] = DF_sh(a,beta,gamma)
% partial derivative of F_sh (with respect to a)

N = length(a)-1;
k = (0:N)';


linear = -gamma*k.^4-beta*k.^2+1;
nonlinear = convmatrix(convo(a,a),N,N);
J = diag(linear)-3*nonlinear;
J(1,:)=J(1,:)/2;

return 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [l1nu] = norml1nu(a,nu)
% l^1_nu norm of a

N = length(a)-1;
w = weights(nu,N);
l1nu = w*abs(a);

return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% function [l1nu] = norml1nutensor(a,nu)
% % l^1_nu norm in the first dimension of a
% 
% sz = size(a);
% a = reshape(a,sz(1),[]);
% N = sz(1)-1;
% w = weights(nu,N);
% l1nu = w*abs(a);
% l1nu = reshape(l1nu,sz(2:end));
% 
% return
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% function [l1nustar] = norml1nustar(a,nu)
% % dual l^1_nu norm 
%  
% N = length(a)-1;
% v = 1./weights(nu,N);
% l1nustar = max(abs(a).*v);
%  
% return
% %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [matrixnorm] = matrixnorml1nu(A,nu)
% norm of matrix as operator from l^1_nu to l^1_nu

N = length(A)-1;
w = weights(nu,N);
v = 1./w;
matrixnorm = max((w*abs(A)).*v);

return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [w] = weights(nu,N)
% the weights used in l^1_nu

w = 2*nu.^(0:N);
w(1) = 1;

return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [convolution] = convo(a1,a2,len)
% returns the convolution of a1 and a2 of length len+1
% in the symmetric setting
% the default for len is length(a1)+length(a2)-2

N = length(a1)-1;
M = length(a2)-1;
if ~exist('len','var')
    len = N+M;
end
convolution = convmatrix(a1,len,M)*a2;

return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [matrix] = convmatrix(a,dim1,dim2)
% returns the dim1+1 x dim2+1 matrix that 
% represents convolution with the vector a
% in the symmetric setting
% the default for dim2 is length(a)
% the default for dim1 is dim2+length(a)

N = length(a)-1;
if ~exist('dim2','var')
    dim2 = N;
end
if ~exist('dim1','var')
    dim1 = dim2+N;
end
diffdim = dim2-N;
if diffdim >= 0
  syma = [zeros(diffdim,1);a(end:-1:2);a;zeros(diffdim,1)]';
  toep = toeplitz([syma(1);zeros(dim1,1)],syma);
else
  syma = [a(end+diffdim:-1:2);a(1:end+diffdim)]';
  toep = toeplitz([a(end+diffdim:end);zeros(dim1+diffdim,1)],syma);
end
matrix = toep(:,dim2+1:2*dim2+1);
matrix(:,2:end) = matrix(:,2:end)+toep(:,dim2:-1:1);

return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
