function norm_bound =  norm_X_to_ell_infty( Omega ,nu, New_Norms,num_rows,num_columns)
%norm_X_to_ell - Computes X -> ell^1 norm of an operator ASSUMING 0 in tail
%                Assume Omega^N is a (num_rows) x (num_columns) matrix and Omega is a ZERO map in the tail 
%                cf. Section 6 between (50)-(51).
% 
%  This version of the function allows for a variable sized matrix.
% 
% Last Modified:  02-26-2020

    if (num_columns ~=   length(New_Norms) ) ||  (num_rows    ~= length(Omega(:,1)))
        disp('Dimension Mismatch: norm_X_to_ell_infty ')
        norm_bound = NaN;
        return
    end
    N = num_rows-1;
%   Takes MAX over column vectors:
%       || Omega_k^N ||_ell^1_nu  /  || q_k ||_ell^1_nu
    col_norm_list = intval(zeros(1,num_columns));
    for k = 1:num_columns
        col_norm_list(k) = ellOneNorm_intval(Omega(:,k),nu,N);
    end    
    col_norm_list = col_norm_list./New_Norms;
    norm_bound = max(col_norm_list);    
    norm_bound = intval(sup(norm_bound));
end