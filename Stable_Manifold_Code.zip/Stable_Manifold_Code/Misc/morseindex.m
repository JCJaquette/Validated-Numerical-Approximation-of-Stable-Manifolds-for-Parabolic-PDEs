function [index,minnegeig] = morseindex(A,M)
% computes the number of negative eigenvalues of A
% using Sylvester's law of inertia and Gershgorin circles.
% Returns NaN if it fails to reach a conclusion.
% The algorithm assumes A is selfadjoint.
%
% If N=size(A,1) is large, it may be computationally expensive
% to approximately diagonalize A. 
% When M is provided, it will attempt to compute the index
% by hoping that the tail rows/columns > M are already diagonally dominant
% [it will first permute A so that the smallest M diagonal elements 
% (relative to their off-diagonal row elements) are in the first M rows/columns]
% and approximately diagonalize only A(1:M,1:M)

N=size(A,1);

if nargin==1 || isempty(M)
    M=N;
else
    M=min(M,N);
end

if exist('intval','file') && isintval(A(1))
    A0=mid(A);
else
    A0=A;
end

if M<N
    % rearrange to have the least dominant diagonal elements in the top left
    E0=A0;
    D0=diag(E0);
    E0(eye(size(E0))==1)=0;
    E0=abs(E0);
    r0=abs(D0)./sum(E0,2);
    [~,rearrange]=sort(r0);   
    A0=A0(rearrange,rearrange);
    A=A(rearrange,rearrange);
end

[V,eigenvalues]=eig(A0(1:M,1:M),'vector');
% rescaling to arrive at -1 and +1 on the diagonal
V=V./sqrt(abs(eigenvalues))';
minnegeig=max(eigenvalues(eigenvalues<0));

if M<N   
   % spome more rescaling to improve commensurability
   V0 = sparse(1:N,1:N,1./sqrt(abs(diag(A0))),N,N,M^2+N-M);
   V0(1:M,1:M) = V;
else
   V0=V;
end

% note that if V0 is not invertible, we always end up with index=NaN
% the product is interval arithmetic if A consists of intervals
E=V0'*A*V0;
% by Sylvester's law of intertia E has the same Morse index as A
D=real(diag(E));
E(eye(size(E))==1)=0;
r=abs(D)-sum(abs(E),2);
if all(r>0) 
    % the Gershgorin circles were effective 
    index=length(find(D<0));
else
    index=NaN;
end

end

