%% main_NL.m  
% 
% Given \rho, this program tries to find optimal constants for proving Theorem 5.11 
% Uses the nonlinear approximation described in Section 7. 
% 
% The script "a_bundles_a1_proof" needs to be run in advance.
% 
% Last Modified:  Mar 27, 2020
addpath('Misc')
addpath('LP_Code')

tic
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %    

%% Program Parameters



% This is this inital radius vector \rho - it may get updated
% If the theorem cannot be proved with the given \rho, larger values of \rho will be attempted. 

r_theta = delta*ellOneNorm_intval(Ps(:,2), nu, N);

radii = [r_theta ;  1e-6; 1e-10]; 


% Display Options
UPDATE_RADII            = 1;
DISPLAY_LINEAR_DEFECT   = 1;
PLOT_G                  = 0;

% Computational Parameter   s:

% After optimizing our constants, we inflate the size of P and \bar{P}.
const_inflate = 1+ 1e-3;

% The number of times bootstrapping is repeated
    general_rep = 5; 
    repetitions_bootstrap   = general_rep; 
    rep_P_update            = general_rep;
    rep_P2_update           = general_rep;
    repetitions_F           = general_rep;
    repetitions_K           = general_rep;
    
    Computational_Parameters = { repetitions_bootstrap,repetitions_F,repetitions_K};
    
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %    
    
%% Gather Data from Change of Coordinates

% Automatically set more parameters

slow_dimension  = 1;
eigen_sorted    = eigen_sorted_1;
order           = order_1;

a               = intval(a1);
gamma           = intval(gamma);    % In the paper as \beta_1
beta            = intval(beta);     % In the paper as \beta_2

[equilibria_success,inexact_eq_error,morse_index,~] = SHproofMorseindex(a,beta,gamma,N,nu);
if equilibria_success == 0 
    disp('FAILED TO VALIDATE EQUILIBRIA / MORSE INDEX!')
    return
end
    
% We sort eigenvectors of Q from largest eigenvalue to smallest eigenvalue
Q = Q1(:,order_1(fliplr(1:N+1)));
Q = intval(Q);

    
% We define \lambda as in Section 7 equation (65) 
lambda_infty = -gamma*(N+1)^4-beta*(N+1)^2+1;
    lambda_s = [ eigen_sorted(end-morse_index),eigen_sorted(end-morse_index-slow_dimension ) , lambda_infty];  % m_s = 3
    lambda_u = [ eigen_sorted(end-(morse_index-1)) ];
    

    
%  Make sure that N is sufficiently large 
%  so that the Lambda_\infty has negative, and decreasing diagonal elements.
if ~(lambda_infty < 0) || ~(( 2*gamma*(N+1)^2 +beta) >0)
    disp('Error: N is too small. ')
    return
end

    m_u = length(lambda_u); % m_u = 1;
    m_s = length(lambda_s); % m_s = 3;
    
    if length(radii) ~= m_s
        disp('    Error: m_s dimension mismatch')
        return;
    end
    
%% WE GATHER DATA FROM BUNDLES WORK    
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     
    
    P   =   P_bound;
    DP  =  DP_bound;
    DDP = D2P_bound;

    
    E_theta_0 = E0_slow(1:N+1);
    

% E_* is a 3x2 matrix  
%       -- first column corresponds to pi_N 
%       -- second column corresponds to pi_\infty 
%   -- Rows correspond to [ value ; derivative ; 2 derivative]
    
    E__slow = [   E_slow_pi_N_norm,              E_slow_pi_inf_norm                  
                d_theta_E_slow_pi_N_norm ,      d_theta_E_slow_pi_inf_norm  
                d2_theta_E_slow_pi_N_norm ,     d2_theta_E_slow_pi_inf_norm ];

    E__unst = [  E_unstable_pi_N_norm ,          E_unstable_pi_inf_norm   
                d_theta_E_unstable_pi_N_norm,   d_theta_E_unstable_pi_inf_norm                 
                d2_theta_E_unstable_pi_N_norm,  d2_theta_E_unstable_pi_inf_norm ];
    
    E__fast = [   E_fast_pi_N_norm  ,            E_fast_pi_inf_norm   
                d_theta_E_fast_pi_N_norm,       d_theta_E_fast_pi_inf_norm  
                d2_theta_E_fast_pi_N_norm,      d2_theta_E_fast_pi_inf_norm ];

    E__infty = [ E_infty_pi_N ,                  E_infty_pi_inf
                E_partial_infty_pi_N,           E_partial_infty_pi_inf
                E_partial2_infty_pi_N,          E_partial2_infty_pi_inf];
    
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     
    
%% Initial Computations
% P, \bar{P} are assigned (arbitrary) initial values.
% Then we compute constants from Section 2 using radii vector, P, \bar{P}
%       Constants: \tilde{D}, D, \hat{C}, \tilde{C}, C, H, \hat{H}, gamma
% This is done using the nonlinear approximation described in Section 7.

% We define tensors P and \bar{P}
% These initial values will be updated later
    P_u_s   = 1e-10*intval(ones(m_u, m_s));
    P_u_s_s = 1e-1*intval(zeros(m_u, m_s, m_s));    

%%% Estimate 4  - Bound on \tilde{N}^i_j(0) 
[ C_info_Z1 ] = data_SH_nonlinear_Z1( DK_0_info,E_theta_0, ...
                    a1,Q,eigen_sorted,gamma,beta,N ,nu,morse_index);
%%% Estimate 3  - Bound on \tilde{N}^ij_k 
%                 This must be recomputed whenever the radii changes
[C_info , epsilon_u, epsilon_s] ...
    = data_SH_nonlinear(C_info_Z1, P_u_s,radii ,inexact_eq_error,...
                        Q_info,P,DP,DDP,B_info,...
                        E__slow, E__fast, E__unst,E__infty,...
                        Q,N ,nu,morse_index);

%   We slightly reduce the size of r_\theta so that $\theta + \eps_s < delta$. 
    radii(1) = radii(1) - 2*sup(epsilon_s(1));
                    
                
% cf. Proposition 2.4
[ C_s_s , C_s_u, C_u_s, C_u_u , C_hat_s_s , C_hat_s_u , C_hat_u_s ,C_hat_u_u ] ...
    = create_C( P_u_s , C_info , radii);

    D_s_s = C_info{1};
    D_u_s = C_info{2};
    D_u_u = C_info{3}; 
    D_s_u = C_info{4};
   
    if DISPLAY_LINEAR_DEFECT ==1
        disp('D = ')
        disp([[D_u_u,D_u_s];[D_s_u, D_s_s] ])
        disp('C^hat = ')
        disp([[C_hat_u_u,C_hat_u_s];[C_hat_s_u, C_hat_s_s] ])
    end
        
% %  Estimate 5 ( Section 6.2.5) 
    [ lambda_0 , C_s ,test_Semi_Group] = create_lambda0( lambda_s, D_s_s ,eigen_sorted );
    
    % H tensors             - cf. Definition 2.6
    [ H_s_s, H_u_s ] = create_H( C_s_s, C_s_u, C_u_u, C_u_s, P_u_s);
    [ H_hat_s_s ,  H_hat] = create_H_hat( C_hat_s_s, C_hat_s_u, D_s_u, P_u_s);
    % gamma decay rates     - cf. Definition 3.3
    [ gamma_s ] = create_gamma( lambda_s,H_s_s ,lambda_0 , C_s, H_hat );
    
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %    
    
%% Optimizing Constants: C^{0,1} Endomorphism
    disp('Optimizing Constants')
    fprintf('  ')
    % cf. Remark 4.3
    % We iteratively: Compute G, then update P, and recompute the constants defined above
    
    for rep_P = 1:rep_P_update
        fprintf('.')
        % We compute G
        [ G_s_s__k ] = create_G( H_s_s , gamma_s,repetitions_bootstrap,C_s);
        G_s_s__k = sup(G_s_s__k);
        % Define P := \tilde{P} from Proposition 4.4        
        [ P_out ] = bound_P_alt( G_s_s__k,C_info,P_u_s ,radii,lambda_u ,gamma_s );
        P_u_s     = sup(P_out );
        
        % We see if solutions stay inside the ball B_s(\rho)
        % if necessary, we enlarge the radii.
        if UPDATE_RADII
            [~, radii] = check_R( radii, gamma_s, G_s_s__k );
            radii = mid(radii);
        end
        
        % We update constants: D, \hat{C}, \tilde{C}, C, H, \hat{H}, gamma
        [C_info , ~, ~] = data_SH_nonlinear(C_info_Z1, P_u_s,radii ,inexact_eq_error,...
                            Q_info,P,DP,DDP,B_info,...
                            E__slow, E__fast, E__unst,E__infty,...
                            Q,N ,nu,morse_index);
        [ C_s_s , C_s_u, C_u_s, C_u_u , C_hat_s_s , C_hat_s_u , C_hat_u_s ,C_hat_u_u ] ...
                        = create_C( P_u_s , C_info , radii);
        [ H_s_s, H_u_s ] ...
                        = create_H( C_s_s, C_s_u, C_u_u, C_u_s, P_u_s);
        [ H_hat_s_s ,  H_hat] ...
                        = create_H_hat( C_hat_s_s, C_hat_s_u, D_s_u, P_u_s);
        [ gamma_s ] ...
                        = create_gamma( lambda_s,H_s_s ,lambda_0 , C_s, H_hat );
        if gamma_s(1)>0
            % Solutions to the projected differential equation do not decay to zero
            break
        end              

    end
    
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %    

%% Optimizing Constants: C^{1,1} Endomorphism
    fprintf('\n  ')
    % cf. Section 4.2  
    % We iteratively: define \bar{P} := \tilde{P} from Theorem 4.11 
    % This requires \bar{P}-dependent tensors: S & K
    % We compute K without using interval arithmetic.
    for rep_P2 = 1:rep_P2_update
        fprintf('.')
        % Update P_u_s_s
        [ S_s_s_s , S_u_s_s] = create_S( P_u_s , P_u_s_s , C_s_s , C_s_u, C_u_s, C_u_u , C_info);
        [ K_tensor ]    = create_K( H_s_s , gamma_s , S_s_s_s, G_s_s__k,repetitions_K ,C_s,0); %% non-rigorous calculations
        % Define       \bar{P} := \tilde{P} from Theorem 4.11 
        [ P_u_s_s_out ] = bound_P2( S_u_s_s, K_tensor, G_s_s__k, H_u_s, gamma_s,lambda_u );
            P_u_s_s     = mid(P_u_s_s_out);
    end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %        

%%   Checking a posteriori conditions
disp([newline 'Checking a posteriori conditions'])
% We complete a final, rigorous calculation 

% We inflate and check our a posteriori conditions
radii   = intval(radii);
a       = intval(a);
nu      = intval(nu);
lambda_s= intval(lambda_s);
lambda_u= intval(lambda_u);
inexact_eq_error= intval(inexact_eq_error);

% We increase the size of P and \bar{P}
% This makes it easier in Proposition 4.4 for P < \tilde{P}, etc
P_u_s   = intval(P_u_s*const_inflate);
P_u_s_s = intval(P_u_s_s*const_inflate);

% We recompute all of the constants in Section 2 with the final values of P, \bar{P}
[C_info , epsilon_u, epsilon_s] ...
    = data_SH_nonlinear(C_info_Z1, P_u_s,radii ,inexact_eq_error,...
                        Q_info,P,DP,DDP,B_info,...
                        E__slow, E__fast, E__unst,E__infty,...
                        Q,N ,nu,morse_index);
% Checks all of the conditions of Theorem 5.11   
[ TEST_STABLE , TEST_RADIUS , TEST_ENDO_1 , TEST_ENDO_2  , Jnorm ] ...
    = ValidateManifold(radii,P_u_s,P_u_s_s,lambda_s,lambda_u,eigen_sorted,C_info,Computational_Parameters,PLOT_G);
% Displays results of Theorem 5.11
[ total_success, abs_error ] = DisplayResults(equilibria_success,...
    TEST_STABLE,TEST_RADIUS,TEST_ENDO_1,TEST_ENDO_2,Jnorm,radii,P_u_s,P_u_s_s,epsilon_u,epsilon_s);

toc