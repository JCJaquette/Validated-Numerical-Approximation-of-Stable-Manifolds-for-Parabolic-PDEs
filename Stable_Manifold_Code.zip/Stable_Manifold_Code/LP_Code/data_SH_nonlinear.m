function [C_info , epsilon_u, epsilon_s] = data_SH_nonlinear(C_info_Z1, P_u_s, radii ,error,...
    Q_info,P,DP,DDP,B_info,...
    E_slow, E_fast, E_unst,E_infty,... 
    Q_mat,N ,nu,morse_index)
%data_SH_NL - We compute Estimates 3 & 4 from Section 7.3 & Section 7.4
% C_info_Z1 -- The constants \tilde{D} 
% P_u_s     -- The cone in which we look for stable manifolds
% radii     -- Radius of the Ball (\rho)
% error     -- The distance | \bar{a} - \tilde{a} |_{\ell_\nu^1} from the approximate equilibrium to the true equilibrium 
% Q_info    -- Bounds on Q(\theta) and its derivatives
% P,DP,DDP  -- Bounds on P(\theta) and its derivatives
% E_*       -- Bounds on defect E_*, derivatives, and \pi_N & \pi_\infty
% Q_mat     -- The (ordered) finite-dim eigenvectors
% N         -- The Galkerin Trunctation 
% nu        -- The weight for our space \ell_\nu^1
% morse_index   -- The number of unstable eigenvalues

% % % 
%
% This outputs C_info - - 
%   containing the tensors D_j^i and C_j^{ik} 
%   satisfying Proposition 2.4 

% Last Modified:  02-06-2020
    
%     if m_s ~= 3 || m_u ~= 1 
%         disp('Improper Splitting of stable/unstable eigenspace into subspaces')
%         disp('The function "data_SH_nonlinear" has hardcoded m_s == 3 and m_u == 1')
%     end
%     m_s=3;
%     m_u=1;

[ C_info_Z2 , epsilon_u, epsilon_s ] = data_SH_nonlinear_Z2( P_u_s, radii ,Q_mat,N ,nu,morse_index,error,...
    Q_info,P,DP,DDP,B_info,...
    E_slow, E_fast, E_unst,E_infty);

    [ D_info ] = create_D(C_info_Z1,C_info_Z2 , epsilon_u, epsilon_s);

    % The output C_info:
    %   contains the tensors D_j^i and C_j^{ik} satisfying Proposition 2.4 
    
    C_info = [D_info ; C_info_Z2];

    for k = 1:length(C_info)
        C_info{k} = intval(sup(C_info{k}));
    end
end
