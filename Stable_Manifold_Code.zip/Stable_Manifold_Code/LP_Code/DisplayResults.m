function [total_success abs_error ] = DisplayResults(equilibria_success, TEST_STABLE , TEST_RADIUS , TEST_ENDO_1 , TEST_ENDO_2 ,  Jnorm,radii,P_u_s,P_u_s_s,epsilon_u,epsilon_s)
%DisplayResults     -   Outputs the results from checking the hypotheses of Theorem 5.11  
%   abs_error - the C^0 error terms on the distance from the stable manifold
% 
% Last Modified:  02-09-2019
endl = char(10); %% This makes the output compatible with Octave

m_s = length(P_u_s(1,:));
m_u = length(P_u_s(:,1));

% Is there a computer-assisted proof of the equilibrium? 
if equilibria_success ==1
    disp(['  Validate Eq: Success'])
else
    disp('  Validate Eq: Failure');
end
% We check that the stable part is stable; Proposition 3.13 & Theorem B.1
if TEST_STABLE
    disp('  Stable Test: Success');
else
    disp('  Stable Test: Fail');
end
% We check the projected system stays inside the ball B_s(\rho)
% Hypothesis of Proposition 3.13; Remark 3.14
if TEST_RADIUS
    disp('  Radii  Test: Success');
else
    disp('  Radii  Test: Fail');
end
% We check endomorphism for     \Psi: \cB^{0,1} -> \cB^{0,1}
% cf. Proposition 4.4
if TEST_ENDO_1
    disp('  Endo   Test: Success');
else
    disp('  Endo   Test: Fail');
end
% We check endomorphism for     \Psi: \cB^{1,1} -> \cB^{1,1}
% cf. Theorem 4.11
if TEST_ENDO_2
    disp('  Endo2  Test: Success');
else
    disp('  Endo2  Test: Fail');
end
% We check if \Psi is a contraction mapping
if sup(Jnorm)<1
    disp('  Contraction: Success');
else
    disp('  Contraction: Fail');
end
disp(['  Contraction constant:  ' num2str(sup(Jnorm)) endl ])
  
% Computes C^0 errorbounds 
abs_error = P_u_s * ( radii + epsilon_s) + epsilon_u;
abs_error = intval(sup(abs_error)); 

% epsilon_s
% disp(['  ' char(949) '_s error  :   ' num2str(sup(epsilon_s' )) newline]) 

% Displays the radius vector - \rho 
disp(['  radii      :   ' num2str(transpose(mid(radii))) ])

% Outputs C^0 error bound and C^1 error bound.
if m_u == 1 
  disp(['  C0  error  :   ' num2str(sup(abs_error ))])
  disp(['  C1  error  :   ' num2str(sup(P_u_s))])  
else
  disp('  C0  error  :   ')
  disp(num2str(sup(abs_error)))
  disp('  C1  error  :   ')
  disp(num2str(sup(P_u_s)))
end
% Outputs \bar{P}
disp('  C11 error  :   ')
for i_prime = 1:m_u
    if ~(m_u ==1)
        disp(['  P^{ij}_' num2str(i_prime) ' :   ' endl])
    end
    second_Derivative = reshape(P_u_s_s(i_prime,:,:),[m_s,m_s]);
    disp(mid(second_Derivative));
end   

% Outputs whether all of the hypotheses are satisfied
total_success = equilibria_success && TEST_STABLE && TEST_RADIUS && TEST_ENDO_1 && TEST_ENDO_2 && (sup(Jnorm)<1);
if total_success  == 0 
    disp([newline '  FAILED TO VALIDATE!!'])
end

end
