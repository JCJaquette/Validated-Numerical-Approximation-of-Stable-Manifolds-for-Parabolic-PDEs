function [ T_j_n__k  ] = T_basic( G_s_s__k , j ,H_s_s,gamma_s)
%T_basic - Theorem 3.7 
% 
% We input a tensor << G_s_s__k  >> where 
% 
%               G_{j,k}^n  = G(j,n,k)

% We input a tensor << T_J_n__k  >> where J is fixed and
% 
%               T_J(G)_{J,k}^n  = T(1,n,k)
% 
% Last Modified:  02-01-2020


    m_s = length(G_s_s__k(:,1,1));
    N_lambda = length(gamma_s);
    
    T_j_n__k = intval(zeros(1,m_s,N_lambda));
    
%     We only multiply H_j^i G_i,k^n when i!=j
    H_s_s(j,j)=0;
    
    for k = 1:N_lambda
        if k ~= (j+1)
            constant = ( gamma_s(k) -  gamma_s(j+1) );
            for n = 1:m_s
                
                A =  H_s_s(j,:)*G_s_s__k(:,n,k)  / constant ;
                
                T_j_n__k(1,n,k) = A;
                T_j_n__k(1,n,j+1) = T_j_n__k(1,n,j+1) - A;
            end
        end
    end
    
    T_j_n__k(1,j,j+1) =  1 + T_j_n__k(1,j,j+1);
    
    
end

