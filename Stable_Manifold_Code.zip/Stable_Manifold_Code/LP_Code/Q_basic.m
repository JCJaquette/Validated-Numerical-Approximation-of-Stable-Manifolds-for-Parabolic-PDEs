function [ G_s_s__k ] = Q_basic( G_s_s__k , m )
%Q_basic - Section 3, equation (32) & Proposition A.4; cf. Lemma 3.10
%   We allow m to range from 1 -- m_s.
% 
%   Inputs/outputs a tensor << G_s_s__k  >> where 
% 
%               G_{j,k}^n  = G(j,n,k)
% 
% Last Modified:  02-01-2020

    m_s = length(G_s_s__k(:,1,1));
    
    % We define M=m+1, because we cannot start counting from 0. 
    M = m+1; 
    
%   Go through G_{j,k}^n for all j & n. 
    for n = 1:m_s
        for j = 1:m_s
            %   Whenever k=M, add G_{j,k}^n to the component with k=M-1 or k=M+1
            %   depending on the sign, and then set to zero.
            if sup(G_s_s__k(j,n,M)) > 0 
                % We add it to the index below.
                G_s_s__k(j,n,M-1) = G_s_s__k(j,n,M-1) + G_s_s__k(j,n,M);
                G_s_s__k(j,n,M)=0;
            elseif G_s_s__k(j,n,M) < 0 
                if m < m_s
                    % We add it to the index above
                    G_s_s__k(j,n,M+1) = G_s_s__k(j,n,M+1) + G_s_s__k(j,n,M);
                else
                    % There is no higher index; we do nothing
                end
                G_s_s__k(j,n,M)=0;
            else
                % G_s_s__k(j,n,M) == 0 
            end
        end
    end
    

end

