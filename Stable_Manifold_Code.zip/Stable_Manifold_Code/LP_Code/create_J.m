function [ J_tensor ,J_mat, Jnorm ] = create_J( G_s_s__k,F_tensor,C_u_u,H_u_s,lambda_u ,mu_s)
%create_J - Creates the tensor J from Definition 5.8
% Input
%    mu_s is given by vector gamma_s , with (gamma_0)/2 appended at the front
%    F_{m i, k }^{n i'} = F[m,n,k,i,i']
%  Output 
%    J_tensor   - J_{j'i}^{i'n} = J(j',i',i,n)
%    J_mat      - Jmat_{m_s(j'-1)+n)}^{m_s(i'-1)+i} = J(j',i',i,n)
%    Jnorm      - the 1-norm of the matrix J_mat
% 
% Last Modified:  12-22-2019

% J_{j'i}^{i'n} = J(j',i',i,n)
    
    m_u = length(lambda_u);    
    N_mu = length(mu_s);
    m_s = N_mu-2;
    
    % We calculate J 
    J_tensor = intval(zeros(m_u,m_u,m_s,m_s));
    
    % J_{j'i}^{i'n} = 
    %   sum_{-1 <= k <= m_s}
    %       (\lambda_j' - \gamma_k)^{-1}
    %       *(C_j'^i' G_i,k^n + H_j'^m F_{mi,k}^ni' )
    
    % J_{j'i}^{i'n}
    % We create for-loops for j',i',i,n
    for j_prime = 1:m_u
        for i_prime = 1:m_u
            for i = 1:m_s 
                for n = 1:m_s
                    %
                    % We sum over k
                    sum = intval(0);
                    for k = 1:N_mu
                        % (\lambda_j' - \gamma_k)^{-1}
                        constant = ( lambda_u(j_prime) - mu_s(k) );
                        % (C_j'^i' G_i,k^n + H_j'^m F_{mi,k}^ni' )
                        if k == 1
                            summand = intval(0);
                        else
                            % C_j'^i' G_{i,k}^n
                            summand = C_u_u(j_prime,i_prime)*G_s_s__k(i,n,k-1);
                        end
                        % H_j'^m F_{mi,k}^ni' 
                        summand = summand + H_u_s(j_prime,:)*F_tensor(:,n,k,i,i_prime);                        
                        sum = sum +  summand/constant;
                    end
                    J_tensor(j_prime,i_prime,i,n)= sum;
                    %
                    %
                end% n
            end% i
        end% i'
    end% j'        
    
    % We create a matrix as referenced in Remark 5.10
    
    % J_{j'i}^{i'n} = J(j',i',i,n)
    % \tilde{J}_{m_s(j'-1)+n)} ^{m_s(i'-1)+i} = J(j',i',i,n)    
    J_mat = intval(zeros(m_s*m_u,m_s*m_u));
    for jprime = 1:m_u 
        for iprime = 1:m_u
            for i = 1:m_s
                for n = 1:m_s
                    % \tilde{J}_{m_s(j'-1)+n)} ^{m_s(i'-1)+i} = J(j',i',i,n)
                    %
                    J_mat(m_s*(jprime-1)+n, m_s*(iprime-1)+i) = J_tensor(jprime,iprime,i,n);
                end
            end
        end
    end    
    % We compute the 1-norm of the matrix J_mat -- the maximum absolute column sum 
    Jnorm= norm(J_mat,1);    
end

