function [ D_info ] = create_D(C_info_Z1,C_info_Z2 , epsilon_u, epsilon_s)
%create_D This function creates the tensor D referenced in Proposition 2.4.
% 
% C_info_Z1  =  \tilde{D}_i^j 
% C_info_Z2  =          C_i^jk
% 
% We have the vectors
%   epsilon_u = \pi_i' | \epsilon|
%   epsilon_s = \pi_i  | \epsilon|
% 
% D_i^j = \tilde{D}_i^j + C_i^jk * epsilon
% 
% Last Modified:  02-07-2020

    D_tilde_s_s = C_info_Z1{1};
    D_tilde_u_s = C_info_Z1{2};
    D_tilde_u_u = C_info_Z1{3};
    D_tilde_s_u = C_info_Z1{4};

    C_s_s_s  = C_info_Z2{1};
    C_s_u_s  = C_info_Z2{2};
    C_s_s_u  = C_info_Z2{3};
    C_s_u_u  = C_info_Z2{4};

    C_u_s_s  = C_info_Z2{5};
    C_u_u_s  = C_info_Z2{6};
    C_u_s_u  = C_info_Z2{7};
    C_u_u_u  = C_info_Z2{8};
    
    m_s = length(D_tilde_s_u(:,1));
    m_u = length(D_tilde_s_u(1,:));
    
    D_s_s = intval(zeros(m_s,m_s));
    D_u_s = intval(zeros(m_u,m_s));
    D_u_u = intval(zeros(m_u,m_u));
    D_s_u = intval(zeros(m_s,m_u));

    % cf. Proposition 2.4
    for i = 1:m_s
        % D_i_j = D_hat_i^j + C_i^{j k} * eps_k + C_i^{j k'} * eps_k'
        for j = 1:m_s
            D_s_s(i,j) = D_tilde_s_s(i,j) ...
                + reshape(C_s_s_s(i,j,:),[1 m_s])*epsilon_s ...
                + reshape(C_s_s_u(i,j,:),[1 m_u])*epsilon_u ;
        end
        % D_i_j' = D_hat_i^j' + C_i^{j' k} * eps_k + C_i^{j' k'} * eps_k'
        for j_prime = 1:m_u
            D_s_u(i,j_prime) = D_tilde_s_u(i,j_prime) ...
                + reshape(C_s_u_s(i,j_prime,:),[1 m_s])*epsilon_s ...
                + reshape(C_s_u_u(i,j_prime,:),[1 m_u])*epsilon_u ;
        end
    end
    for i_prime = 1:m_u
        % D_i'_j = D_hat_i'^j + C_i'^{j k} * eps_k + C_i'^{j k'} * eps_k'
        for j = 1:m_s
            D_u_s(i_prime,j) = D_tilde_u_s(i_prime,j) ...
                + reshape(C_u_s_s(i_prime,j,:),[1 m_s])*epsilon_s ...
                + reshape(C_u_s_u(i_prime,j,:),[1 m_u])*epsilon_u ;
        end
        % D_i'_j' = D_hat_i'^j' + C_i'^{j' k} * eps_k + C_i'^{j' k'} * eps_k'
        for j_prime = 1:m_u
            D_u_u(i_prime,j_prime) = D_tilde_u_u(i_prime,j_prime) ...
                + reshape(C_u_u_s(i_prime,j_prime,:),[1 m_s])*epsilon_s ...
                + reshape(C_u_u_u(i_prime,j_prime,:),[1 m_u])*epsilon_u ;
        end
    end

   D_info = {
    D_s_s 
    D_u_s  
    D_u_u 
    D_s_u  
    };

end

