function [ P_out ] = bound_P( G_s_s__k, H_u_s, gamma_s, lambda_u )
%bound_P - Computes \tilde{P} from Theorem 4.2 (not used in practice)
% Input
%   G_{j,k}^n  = G(j,n,k)
%   H_j^i = H(j,i)
% Output
%   P_u^s = P(u,s)
% Last Modified:  12-21-2019

    m_s = length(G_s_s__k(:,1,1));
    m_u = length(lambda_u);
    N_lambda = length(gamma_s);
    
    P_out = intval(zeros(m_u, m_s));
    
    % Defines P_i'^n = sum_k  ( \lambda_i' - \gamma_k)^{-1} H_i'^i G_{i,k}^n 
    for i_prime = 1:m_u
       for n = 1:m_s
           for k = 1:N_lambda
               summand =  ( H_u_s(i_prime,:)*G_s_s__k(:,n,k) ) / ( lambda_u(i_prime)-gamma_s(k) ) ;
               P_out(i_prime,n)= P_out(i_prime,n) +  summand;
           end
       end
    end

end

