function [ K_tensor ] = create_K( H_s_s , gamma_s , S_s_s_s, G_s_s__k,repetitions_K ,C_s, RIGOROUS)
%create_K - Proposition 4.7 & Remark 4.8
%  Constructs: 
%       K_{j,k1,k2}^{i,m} = K(j,i,m,k1,k2)
% 
% Last Modified:  02-01-2020


m_s = length(H_s_s(1,:));
N_gamma = length(gamma_s);

% We define a matrix mu_s containing the rates described in Remark 4.8     
%   it is of size N_gamma x (N_gamma + 1)  
%   mu_s is gamma(k1) in the first column
%   mu_s is gamma(k1)+gamma(k2-1) elsewhere
mu_s = create_mu_deriv2( gamma_s );


% To speed up the program, this function allows a non-rigorous call,
%       used when finding optimal constants with which to attempt a CAP.
if RIGOROUS
    A_tensor = intval(zeros(m_s,m_s,m_s,N_gamma,N_gamma+1));
    zero_val = intval(0);
else 
    A_tensor = zeros(m_s,m_s,m_s,N_gamma,N_gamma+1);
    zero_val = 0;
    G_s_s__k = mid(G_s_s__k);
    H_s_s =mid(H_s_s );
    gamma_s = mid(gamma_s);
    S_s_s_s = mid(S_s_s_s );
    C_s = mid(C_s );
    mu_s = mid(mu_s);
end

% STEP 0:::  We create the tensor A  as described in Appendix A:
% 
%        A_{j,,k1,k2}^{i,m2}  = S_j^{nm} G_{m,k1}^{m2} G_{n,k2}^i
%                             = A(j,i,m2,k1,k2) 

for k1 = 1:N_gamma
    for k2 = 1:N_gamma
        for j = 1:m_s
            for i = 1:m_s
                for m2 = 1:m_s
                    
                    sum = zero_val;
                    for m = 1:m_s
                        summand = S_s_s_s(j,:,m);
                        summand = (summand*G_s_s__k(m,m2,k1))*G_s_s__k(:,i,k2); % Sum  n  with ':'
                        sum = sum + summand;
                    end
                    A_tensor(j,i,m2,k1,k2+1) = sum;
                end
            end
        end
    end
end


% STEP 1:::      We create the initial K_tensor
%                See Remark 4.8. 
%                We do not sum K*_{k1,k2} and K*_{k2,k1}, instead we store
%                them separately. 
if RIGOROUS
    K_tensor = intval(zeros(m_s,m_s,m_s,N_gamma,N_gamma+1));
else 
    K_tensor = zeros(m_s,m_s,m_s,N_gamma,N_gamma+1);
end

for j2 = 1:m_s
    for i = 1:m_s
        for m2 = 1:m_s
            
            for k1 = 1:N_gamma
                for k2 = 2:N_gamma+1
%                     We know A(j,i,m2,k1,k2)=0 for all k2==1;
                    const = ( gamma_s(k1)+gamma_s(k2-1)-gamma_s(1));
                    % Note A_{j,,k1,k2}^{i,m2}  = A(j,i,m2,k1,k2)
                    sum1=zero_val;
                    for j = 1:m_s
                        sum1 = sum1 + A_tensor(j,i,m2,k1,k2);
%                       Maybe this could be vectorized? 
                    end
                    addition = C_s*sum1/const;
                    
                    for j =1:m_s
                        K_tensor(j,i,m2,k1,k2) = addition;
                        K_tensor(j,i,m2,1,1)   = K_tensor(j,i,m2,1,1) -addition;
                    end
                end
            end
        end
    end
end
    
%     STEP 2 ::::  

    for rep = 1:repetitions_K
        for j = 1:m_s
            % Note A_{j,,k1,k2}^{i,m2}  = A(j,i,m2,k1,k2)
            QK_j = Q_2derivative( K_tensor , j );
            K_tensor(j,:,:,:,:)  = T_2derivative( QK_j , A_tensor, j ,H_s_s,gamma_s,mu_s,RIGOROUS);
        end
%         K_tensor = intval(sup(K_tensor));
    end

end

