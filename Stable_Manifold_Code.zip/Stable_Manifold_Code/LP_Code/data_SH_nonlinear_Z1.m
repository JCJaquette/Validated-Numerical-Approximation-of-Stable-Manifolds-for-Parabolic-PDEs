function [ C_info_Z1 ] = data_SH_nonlinear_Z1( DK_0_info,E_theta_0,...
    a1,Q_mat,eigen_values,gamma,beta,N,nu,morse_index)
%data_SH - We compute Estimates 4 from Section 7.4
% DK_0_info -- Bounds on the deriviative of DK(0)
% E_theta_0 -- components of \pi_N E_theta(0)
% a1        -- The approximate equilibrium \bar{a}
% Q_mat     -- The (ordered) finite-dim eigenvectors
% eigen_values  -- the (ordered) eigenvalues
% gamma,beta-- Parameters of the Swift-Hohenberg Equation
% N         -- The Galkerin Trunctation 
% nu        -- The weight for our space \ell_\nu^1
% morse_index   -- The number of unstable eigenvalues
% 
% Last Modified:  02-24-2020

% % % WE ASSUME m_s = 3 ; m_u = 1;
    m_s=3;
    m_u=1;
    
    n_theta = 1;
    
    Q = Q_mat;
    
    u=1;
    theta=2;
    f=3;
    infty=4;
    
%% We compute the weights which give us the X-norm
New_Norms = intval(zeros(1,N+1));
for i = 1:N+1
    New_Norms(i)=ellOneNorm_intval(Q(:,i),nu,N);
end

%% Define projection maps onto subspaces X_u, X_theta, X_f 
% pi_1' = pi_u 
pi_u = intval(zeros(N+1,N+1));
for i = 1:morse_index
    pi_u(i,i)= intval(1);
end
% pi_1 = pi_\theta  (Slow stable subspace)
pi_th = intval(zeros(N+1,N+1));
for i = morse_index+1:morse_index+n_theta
    pi_th(i,i)= intval(1);
end    
% pi_2 = pi_f  (Fast stable subspace)
pi_f = intval(zeros(N+1,N+1));
for i = morse_index+n_theta+1:N+1
    pi_f(i,i)= intval(1);
end    


pi_u_Q_inv      = norm_ell_to_X( pi_u/Q_mat , nu, New_Norms);
pi_th_Q_inv     = norm_ell_to_X( pi_th/Q_mat , nu, New_Norms);
pi_f_Q_inv      = norm_ell_to_X( pi_f/Q_mat , nu, New_Norms);

pi_s_Q_inv      = [pi_th_Q_inv, pi_f_Q_inv ,intval(1)];


%% Bounding   (\partial_i DK(0)^{-1} ) * E(0,0)
% We gather info to define:: dDK(0)
d_theta_A0_0_bound = DK_0_info(1);
d_theta_Qu_0_bound = DK_0_info(2);
d_theta_Qf_0_bound = DK_0_info(3);

% DQ = [ Q_u, Q_theta , Q_f, Q_infty ]
%        1      2       3       4
dDK         = intval(zeros(m_s+m_u,1));
dDK(theta)  = d_theta_A0_0_bound; 
dDK(f)      = d_theta_Qf_0_bound; 
dDK(u)      = d_theta_Qu_0_bound; 
dDK(infty)  = 0;

% Norm of Derivative
dDK_E0 = intval(zeros(m_s+m_u,m_s+m_u));
for i=1:3
    dDK_E0(1:3,i) = dDK(i);
end
% Norm of :: || dDK(0) ||    *   || Q_0^{-1} E_\theta (0) ||
dDK_E0 = dDK_E0*norm_X(Q_mat\E_theta_0,New_Norms);
% Norm of :: || \pi_j Q_0^{-1} ||  *   || dDK(0) ||    *   || Q_0^{-1} E_\theta (0) ||
dDK_E0 = diag([pi_u_Q_inv    pi_s_Q_inv]) * dDK_E0 ;


% % % % % % % % % % % /
    
%% The output C_info_Z1:
%   contains the tensors \tilde{D}_j^i  satisfying Proposition 2.4 

    %%%%%%%%%%%%%%%%%%%%%%%
    %        DN(0) =  DK^-1 * DE(0) +  d DK^-1 * E(0) 
    %%%%%%%%%%%%%%%%%%%%%%%
    
    D_hat = Z1_LHS(a1,Q_mat,eigen_values,gamma,beta,N,nu,New_Norms,pi_u,pi_th,pi_f);
    
    DN_0 =  D_hat + dDK_E0;


    D_hat_s_s = DN_0(2:end,2:end);       
    D_hat_u_s = DN_0(1,2:end);    
    D_hat_s_u = DN_0(2:end,1);    
    D_hat_u_u = DN_0(1,1);   

   C_info_Z1 = {
    D_hat_s_s 
    D_hat_u_s  
    D_hat_u_u 
    D_hat_s_u  
    };

end



function D_hat = Z1_LHS(a1,Q,eigen_values,gamma,beta,N,nu,...
            New_Norms,pi_u,pi_th,pi_f)
    %% Compute the Derivative
    % We pad \bar{a} with zeros so it becomes of length 3N+1. 
    a1_3N        = intval(0:(3*N))';
    a1_3N        = 0.*a1_3N;
    a1_3N(1:N+1) = a1;
    % We compute the derivative of \bar{a}. This contains all the non-zero
    % terms we need to deal with. 
    DFa1_3N = swiftHohenbergDifferential_cos_intval(...
                    intval(a1_3N), intval(gamma), intval(beta));

    % % % % % % % % % % % % % % % 
    %% Estimate 4: Case 1: j == \infty,  i == \infty  ---  D_infty^infty 

    % Positive Indicies
    a1_squared      = convo(a1,a1);
    norm_a_bar_sqr  = ellOneNorm_intval(a1_squared,nu,2*N);
    D_infty_infty   = 3*norm_a_bar_sqr;


    %% Estimate 4: Case 2: i != \infty,  j != \infty  ---  D_u^u  ,  D_u^f  ,  D_f^u  ,  D_f^f

    DFa1_fat    = DFa1_3N(1:N+1,1:N+1);
    Lambda      = intval(diag(flipud(eigen_values)));  % Because of the way this was sorted, we need to reverse the order.
    A_dagger    = intval(mid(DFa1_fat));

    % Define: L_N_fat   = Q^-1 (DF(a) - A^dagger) Q
    L_N_fat     = Q\(DFa1_fat - A_dagger)*Q;
    % Define: L_N_thin  = Q^-1 A^dagger Q - Lambda
    L_N_thin    = Q\A_dagger*Q - Lambda;

    % Define the appropriate projections

    LN_u_u      = pi_u  * (L_N_fat+L_N_thin) * pi_u ;
    LN_u_th     = pi_u  * (L_N_fat+L_N_thin) * pi_th ;
    LN_u_f      = pi_u  * (L_N_fat+L_N_thin) * pi_f ;
    
    LN_th_u     = pi_th * (L_N_fat+L_N_thin) * pi_u ;
    LN_th_th    = pi_th * (L_N_fat+L_N_thin) * pi_th ;
    LN_th_f     = pi_th * (L_N_fat+L_N_thin) * pi_f ;
    
    LN_f_u      = pi_f  * (L_N_fat+L_N_thin) * pi_u ;
    LN_f_th     = pi_f  * (L_N_fat+L_N_thin) * pi_th ;
    LN_f_f      = pi_f  * (L_N_fat+L_N_thin) * pi_f ;


    % Take the L(X,X) operator norm
    D_u_u       = norm_X_to_X( LN_u_u , New_Norms);
    D_u_th      = norm_X_to_X( LN_u_th , New_Norms);
    D_u_f       = norm_X_to_X( LN_u_f , New_Norms);
    
    D_th_u      = norm_X_to_X( LN_th_u , New_Norms);
    D_th_th     = norm_X_to_X( LN_th_th , New_Norms);
    D_th_f      = norm_X_to_X( LN_th_f , New_Norms);
    
    D_f_u       = norm_X_to_X( LN_f_u , New_Norms);
    D_f_th      = norm_X_to_X( LN_f_th , New_Norms);
    D_f_f       = norm_X_to_X( LN_f_f , New_Norms);


    %% Estimate 4:  Case 3: j != \infty,  i == \infty  ---  D_u^infty , D_th^infty ,  D_f^infty 
    % Compute the columns of:
    %                           \pi_j  Q^{-1} [ DF( a1) - A^{\dagger} ]

    % We compute DF( a1) - A^{\dagger} 
    DFa1_3N_diff                = DFa1_3N;
    DFa1_3N_diff(1:N+1,1:N+1)   = DFa1_3N_diff(1:N+1,1:N+1)-A_dagger;
    % Compute \pi_N ( DF( a1) - A^{\dagger} ) 
    DFa1_3N_diff                = DFa1_3N_diff(1:N+1,:);
    % Compute Q^{-1} \pi_N ( DF( a1) - A^{\dagger} ) 
    Q_DFa1_diff     = Q \ DFa1_3N_diff;
    % Compute \pi_j Q^{-1} ( DF( a1) - A^{\dagger} ) 
    pi_u_Q_DFa1_diff    = pi_u  * Q_DFa1_diff ;
    pi_th_Q_DFa1_diff   = pi_th * Q_DFa1_diff ;
    pi_f_Q_DFa1_diff    = pi_f  * Q_DFa1_diff ;

    % Computes ||.||_X norm of columns of the (N+1)x(3N+1) matrix \pi_j Q^{-1} ( DF( a1) - A^{\dagger} ) 
    D_u_infty_list  = intval(0.*(0:3*N));
    D_th_infty_list = intval(0.*(0:3*N));
    D_f_infty_list  = intval(0.*(0:3*N));
    for k =1:(3*N+1)                        %Only needs to check k>N+1
        D_u_infty_list(k)  = norm_X( pi_u_Q_DFa1_diff(:,k) ,New_Norms);
        D_th_infty_list(k) = norm_X( pi_th_Q_DFa1_diff(:,k) ,New_Norms);
        D_f_infty_list(k)  = norm_X( pi_f_Q_DFa1_diff(:,k) ,New_Norms);
    end
    % Divides ||.||_X norm of k-columns by \omega_k
    nu_power    = intval(2)*intval(nu).^(0:(3*N));
    nu_power(1) = intval(1);

    D_u_infty_list  = D_u_infty_list./nu_power;
    D_th_infty_list = D_th_infty_list./nu_power;
    D_f_infty_list  = D_f_infty_list./nu_power;

    % Final bound is given by maximum
    D_u_infty   = max(D_u_infty_list);
    D_th_infty  = max(D_th_infty_list);
    D_f_infty   = max(D_f_infty_list);

    %% Estimate 4: Case 4: j == \infty,  i != \infty  ---  D_infty^u  ,  D_infty^f 
    % Computes the norm of columns of: 
    %       <<< ( \pi_infty DFa1 ) * ( Q *pi_i ) >>>
    % since this only has terms in k > N+1, then X norm == ell_\nu^1 norm.

    % 1-N+1 columns of :: \pi_\infty * DFa1 
    pi_infty_DFa1_3N_left                   = DFa1_3N(:,1:N+1);
    pi_infty_DFa1_3N_left(1:N+1,1:N+1)      = 0;
    % Computes (\pi_\infty * DFa1 )* (Q * \pi_i)
    pi_infty_DFa1_3N_left_Q_pi_u            = pi_infty_DFa1_3N_left * (Q*pi_u);
    pi_infty_DFa1_3N_left_Q_pi_th           = pi_infty_DFa1_3N_left * (Q*pi_th);
    pi_infty_DFa1_3N_left_Q_pi_f            = pi_infty_DFa1_3N_left * (Q*pi_f);

    % Computes the ell_\nu^1 norm of the columns of the matrix. 
    D_infty_u_list  = intval(0.*(0:N));
    D_infty_th_list = intval(0.*(0:N));
    D_infty_f_list  = intval(0.*(0:N));
    for k =1:(N+1)
        D_infty_u_list(k)  = ellOneNorm_intval( pi_infty_DFa1_3N_left_Q_pi_u(:,k),nu,3*N);
        D_infty_th_list(k) = ellOneNorm_intval( pi_infty_DFa1_3N_left_Q_pi_th(:,k),nu,3*N);
        D_infty_f_list(k)  = ellOneNorm_intval( pi_infty_DFa1_3N_left_Q_pi_f(:,k),nu,3*N);
    end
    % Divides by ||q_k||_{\ell_\nu^1} and takes maximum
    D_infty_u  = max(D_infty_u_list./New_Norms);
    D_infty_th = max(D_infty_th_list./New_Norms);
    D_infty_f  = max(D_infty_f_list./New_Norms);

    %% Defines the output

    D_hat = [...
                D_u_u       D_u_th      D_u_f       D_u_infty
                D_th_u      D_th_th     D_th_f      D_th_infty
                D_f_u       D_f_th      D_f_f       D_f_infty
                D_infty_u   D_infty_th  D_infty_f   D_infty_infty];


end
