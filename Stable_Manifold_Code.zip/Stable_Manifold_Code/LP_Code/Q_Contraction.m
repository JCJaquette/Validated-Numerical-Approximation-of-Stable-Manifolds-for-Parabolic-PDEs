function [ F_tensor ] = Q_Contraction( F_tensor , m )
%Q_Contraction - Section 5, equation (38) & Proposition A.4 
%   Projects F_tensor to avoid exponential terms in \gamma_m
%       m normally is between 1 -- m_s
%       except to create F_initial, when m==0
%
%   F_{j k i }^{n i'} = F[j,n,k,i,i']
%                     = F_tensor(j,n,M,i,i_prime)
% 
% Last Modified:  02-01-2020

    m_s = length(F_tensor(:,1,1,1,1));
    m_u = length(F_tensor(1,1,1,1,:));
    N_mu = length(F_tensor(1,1,:,1,1));

    %   N_mu is size m_s+2    
    %   We define M=m+2, because we cannot start counting from -1. 
    M = m+2;  
    
    for n = 1:m_s
        for j = 1:m_s
            for i = 1:m_s
                for i_prime = 1:m_u
                    % Now we just look at the index k=M 
                    value = F_tensor(j,n,M,i,i_prime);
                    if sup(value)  > 0 
                        % We add it to the index below (slower).
                        F_tensor(j,n,M-1,i,i_prime) = F_tensor(j,n,M-1,i,i_prime) +value ;
                        F_tensor(j,n,M,i,i_prime)=0;
                    elseif value < 0 
                        if M < N_mu
                            % We add it from the one above (faster)
                            F_tensor(j,n,M+1,i,i_prime) = F_tensor(j,n,M+1,i,i_prime) + value ;
                        else
                            % There is no higher index; we do nothing
                        end
                        F_tensor(j,n,M,i,i_prime)=0;
                    else
                        % F_s_s__k(j,n,M) == 0 
                    end
            
                end
            end 
        end
    end
    

end

