function [ C_s_s , C_s_u, C_u_s, C_u_u , C_hat_s_s , C_hat_s_u , C_hat_u_s ,C_hat_u_u ] = create_C( P_u_s , C_info ,radii)
%create_C - Creates the tensor C_j^i &  \hat{C}_j^i from Proposition 2.4 
% 
% Last Modified:  12-13-2019

    % These are the tensors D_j^i (no tilde)
    C_defect_s_s  = C_info{1};
    C_defect_u_s  = C_info{2};
    C_defect_u_u  = C_info{3};
    C_defect_s_u  = C_info{4};

    % Infer m_s & m_u
    m_s = length(C_defect_s_s(1,:));
    m_u = length(C_defect_u_u(1,:));
    
    % These are the bounds C_j^{ik} = \tilde{C}_j^{ik}
    
    % Note C_s_s_s(j,i,k) = C_j^{ik}
    C_s_s_s  = C_info{5};
    C_s_u_s  = C_info{6};
    C_s_s_u  = C_info{7};
    C_s_u_u  = C_info{8};
    
    C_u_s_s  = C_info{9};
    C_u_u_s  = C_info{10};
    C_u_s_u  = C_info{11};
    C_u_u_u  = C_info{12};
    
    %     Initialize (rigorous) tensors C_j^i
    C_s_s = intval(zeros(m_s, m_s) );
    C_u_s = intval(zeros(m_u, m_s) );
    C_u_u = intval(zeros(m_u, m_u) );
    C_s_u = intval(zeros(m_s, m_u) );
    
    %     Initialize (rigorous) tensors \hat{C}_j^i
    C_hat_s_s = intval(zeros(m_s, m_s) );
    C_hat_u_s = intval(zeros(m_u, m_s) );
    C_hat_u_u = intval(zeros(m_u, m_u) );
    C_hat_s_u = intval(zeros(m_s, m_u) );
    
    
    %     \hat{C}_j^i = C_j^{i n} r_n + C_j^{i j'} r_{j'}    
    %          C _j^i = \hat{C}_j^i + D_j^i     
    
    %    Note: r_{j'} = P_{j'}^n  r_n
    
    % C_s_s
    for j = 1:m_s
        for i = 1:m_s
            sum = intval(0);
%           \hat{C}_j^i = ( C_j^{i n} + C_j^{i j'} P_{j'}^n ) r_n 
            for n = 1:m_s
                little_sum = intval(0);
%               we compute: little_sum =  C_j^{i j'} P_{j'}^n
                for jprime = 1:m_u
                    little_sum = little_sum +C_s_s_u(j,i,jprime) * P_u_s(jprime,n);
                end
                sum = sum + (C_s_s_s(j,i,n)+ little_sum) *radii(n);
            end
            C_hat_s_s(j,i) = sum;
            C_s_s(j,i) = C_defect_s_s(j,i) + sum;
        end
    end
    
    % C_s_u
    for j = 1:m_s
        for iprime = 1:m_u
            sum = intval(0);
%           \hat{C}_j^i' = ( C_j^{i' n} + C_j^{i' j'} P_{j'}^n ) r_n  
            for n = 1:m_s
                little_sum = intval(0);
%               we compute: little_sum =  C_j^{i' j'} P_{j'}^n
                for jprime = 1:m_u
                    little_sum = little_sum + C_s_u_u(j,iprime,jprime)*P_u_s(jprime,n);
                end
                sum = sum + (C_s_u_s(j,iprime,n)+ little_sum ) *radii(n);
            end
            C_hat_s_u(j,iprime) = sum;
            C_s_u(j,iprime) = C_defect_s_u(j,iprime) + sum;
        end
    end
    
    % C_u_s
    for jprime = 1:m_u
        for i = 1:m_s
            sum = intval(0);
%           \hat{C}_j'^i = ( C_j'^{i n} + C_j'^{i i'} P_{i'}^n ) r_n              
            for n = 1:m_s
                littlesum = intval(0);
%               we compute: little_sum =  C_j'^{i i'} P_{i'}^n                
                for i_prime = 1:m_u
                    littlesum = littlesum + C_u_s_u(jprime,i,i_prime)*P_u_s(i_prime,n);
                end
                 sum = sum+(C_u_s_s(jprime,i,n)+littlesum ) *radii(n);
            end
            C_hat_u_s(jprime,i) = sum;
            C_u_s(jprime,i) = C_defect_u_s(jprime,i) + sum;
        end
    end
    
    % C_u_u
    for jprime = 1:m_u
        for iprime = 1:m_u
            sum = intval(0);
%           \hat{C}_j'^i' = ( C_j'^{i' n} + C_j'^{i' k'} P_{k'}^n ) r_n             
            for n = 1:m_s
                littlesum = intval(0);
%               we compute: little_sum =  C_j'^{i' k'} P_{k'}^n                
                for k_prime = 1:m_u
                    littlesum = littlesum + C_u_u_u(jprime,iprime,k_prime)*P_u_s(k_prime,n);
                end
                sum = sum+(C_u_u_s(jprime,iprime,n)+littlesum ) *radii(n);
            end
            C_hat_u_u(jprime,iprime) = sum;
            C_u_u(jprime,iprime) = C_defect_u_u(jprime,iprime) + sum;
        end
    end   
    

end

