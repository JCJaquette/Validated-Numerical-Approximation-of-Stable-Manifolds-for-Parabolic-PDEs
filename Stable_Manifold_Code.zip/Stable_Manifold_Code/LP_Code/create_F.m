function [ F_tensor ] = create_F( H_s_s , gamma_s , C_s_u, G_tensor,repetitions_F ,C_s ,mu_s)
%create_F - Proposition 5.4 & Remark 5.5
%   Creates the F tensor:
%       F_{m i,k}^{n i'} = F[m,n,k,i,i']
% 
% This has size:  zeros(m_s,m_s,N_mu,m_s,m_u)
% 
% mu_s = [ gamma_s(1)/2, gamma_s];
% 
% Last Modified:  02-01-2020


m_u = length(C_s_u(1,:));
m_s = length(C_s_u(:,1));
N_mu = length(mu_s);

% We create the A-tensor   cf. Appendix A
% A_{j i, k }^{n i'} = C_j^i' G_{i,k}^n
% A_{j i, k }^{n i'} = A[j,n,k,i,i']

A_tensor = intval(zeros(m_s,m_s,N_mu,m_s,m_u));

    for n = 1:m_s
        for j = 1:m_s
            for i = 1:m_s
                for i_prime = 1:m_u
                    for k = 2:N_mu
                        % A_{j i, k }^{n i'} = A[j,n,k,i,i']
                        A_tensor(j,n,k,i,i_prime) = C_s_u(j,i_prime) * G_tensor(i,n,k-1)    ;
                    end
                end
            end
        end
    end
    
% STEP 1:::      We create the initial F_tensor
%                   F_{m i,k}^{n i'} = F[m,n,k,i,i']
    F_tensor = intval(zeros(m_s,m_s,N_mu,m_s,m_u));
    A_0 = Q_Contraction( A_tensor , 0 );

    for n = 1:m_s
        for i = 1:m_s
            for i_prime = 1:m_u
                for k = 1:N_mu
                    if k ~= 2
                        % We are not in the k=0 case (aka mu_k == gamma_0)
                        % F_{j i, k}^{n i'} = F[j,n,k,i,i']
                        % Calculate the sum
                        const = (mu_s(k)-gamma_s(1));                        
                        summand = C_s *sum(A_0(:,n,k,i,i_prime))  / const;
                        for j = 1:m_s
                            F_tensor(j,n,k,i,i_prime)=summand;
                            % We subtract it from gamma_0 ( M = 2)
                            F_tensor(j,n,2,i,i_prime)= F_tensor(j,n,2,i,i_prime) -summand;
                        end
                    end
                end
            end
        end
    end
    
%     STEP 2 ::::  

    for rep = 1:repetitions_F
        for j = 1:m_s
            QA_j = Q_Contraction( A_tensor , j );
            QF_j = Q_Contraction( F_tensor , j );
            F_tensor(j,:,:,:,:)  = T_Contraction( QF_j , QA_j, j ,H_s_s,gamma_s,mu_s);
        end
    end


end

