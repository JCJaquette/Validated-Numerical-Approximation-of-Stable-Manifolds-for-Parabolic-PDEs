function [ C_info_Z2 , epsilon_u_vector, epsilon_s_vector ] = ...
    data_SH_nonlinear_Z2( P_u_s, radii ,Q_mat,N ,nu,morse_index,error,...
    Q_info,P,DP,DDP,B_info,...
    E_slow, E_fast, E_unst,E_infty)
%data_SH_nonlinear_Z2 - We compute Estimates 3 from Section 7.3 

% Define the subspace splitting
        m_s = 3;
        m_u = 1;
    n_theta = 1; 

% Define the index for the subspaces { u, \theta, f, \infty}        
        u   = 1;
    theta   = 2;
        f   = 3;
    infty   = 4;

% Last Modified:  02-24-2020

%% Projection Estimates 


% We compute the weights which give us the X-norm
New_Norms = intval(zeros(1,N+1));
for i = 1:N+1
    New_Norms(i)=ellOneNorm_intval(Q_mat(:,i),nu,N);
end

% Compute projections into subspaces 

% pi_1' = pi_u 
pi_u = intval(zeros(N+1,N+1));
for i = 1:morse_index
    pi_u(i,i)= intval(1);
end
% pi_1 = pi_theta  (slow stable subspace)
pi_th = intval(zeros(N+1,N+1));
for i = morse_index+1:morse_index+n_theta
    pi_th(i,i)= intval(1);
end
% pi_2 = pi_f  (Finite stable subspace)
pi_f = intval(zeros(N+1,N+1));
for i = morse_index+n_theta+1:N+1
    pi_f(i,i)= intval(1);
end

pi_u_Q_inv      = norm_ell_to_X( pi_u/Q_mat , nu, New_Norms);
pi_th_Q_inv     = norm_ell_to_X( pi_th/Q_mat , nu, New_Norms);
pi_f_Q_inv      = norm_ell_to_X( pi_f/Q_mat , nu, New_Norms);

pi_s_Q_inv      = [pi_th_Q_inv, pi_f_Q_inv ,intval(1)];

% % % % % % % % % % % % % % % 

% We compute the distance from true equilibrium in each subspace.
epsilon_u       = error * pi_u_Q_inv;
epsilon_theta   = error * pi_th_Q_inv;
epsilon_f       = error * pi_f_Q_inv;
epsilon_infty   = error;

epsilon_u_vector = [ epsilon_u ];
epsilon_s_vector = [epsilon_theta;epsilon_f ; epsilon_infty];
    

%% We define our input
    
%   We add the error to the radii.
    radii = radii + epsilon_s_vector;
    r_u     =  P_u_s*radii + epsilon_u;
    r_theta = radii(1);
    r_f     = radii(2);
    r_infty = radii(3);    

   
%%   Section 7.3.1 Bounding the derivatives of DK and its inverse

% % TODO:: Double Check this!
    B       = B_info{1};
    pi_u_B  = B_info{2};
    pi_th_B = B_info{3};
    pi_f_B  = B_info{4};
    
    DB      = B_info{5};
    pi_u_DB  = B_info{6};
    pi_th_DB = B_info{7};
    pi_f_DB  = B_info{8};
    
    DDB     = B_info{9};
    pi_u_DDB  = B_info{10};
    pi_th_DDB = B_info{11};
    pi_f_DDB  = B_info{12};

%   We bound \pi_N B(\theta)
      B_bound       = B;
     DB_bound       = intval(zeros(m_s+m_u,1));
     DB_bound(theta)= DB;
    DDB_bound       = intval(zeros(m_s+m_u,m_s+m_u));
    DDB_bound(theta,theta) = DDB;    
%   A_1 
    [ A1_bound, DA1_bound, DDA1_bound ] = create_A1( Q_info,r_u, r_f ) ;
%   A_1 * B
    [ AB, DAB, DDAB]    = compute_ProductRule( B_bound, DB_bound, DDB_bound, A1_bound, DA1_bound, DDA1_bound);
%   (I + A_1 * B )^{-1}
    [ Inv , dInv , ddInv ] = bound_Inverse(AB, DAB, DDAB);
%   \pi_j  B (I + A_1 * B )^{-1}    
    [ pi_u_DK_inv,  pi_u_dDK_inv,  pi_u_ddDK_inv]    = compute_ProductRule( pi_u_B,  pi_u_DB,  pi_u_DDB,Inv ,  dInv , ddInv );
    [ pi_th_DK_inv, pi_th_dDK_inv, pi_th_ddDK_inv]   = compute_ProductRule( pi_th_B, pi_th_DB, pi_th_DDB,Inv , dInv , ddInv );
    [ pi_f_DK_inv,  pi_f_dDK_inv,  pi_f_ddDK_inv]    = compute_ProductRule( pi_f_B,  pi_f_DB,  pi_f_DDB,Inv ,  dInv , ddInv );
    
%%   Section 7.3.2 Bounding E
    [ E_N, DE_N, DDE_N, E_tail, DE_tail, DDE_tail] = compute_E(  E_slow, E_fast, E_unst,E_infty,r_f, r_infty, r_u); 
   
%%   Section 7.3.3 Bounding R  
    %     We bound the BOLD Q
    [ Q_bound , DQ_bound, DDQ_bound ] =  create_Q( Q_info,r_u, r_f ,r_infty) ;
    
    %     We bound the BOLD P
    P_bound         = P;
    DP_bound        = intval(zeros(m_s+m_u,1));
    DP_bound(theta) = DP;
    DDP_bound       = intval(zeros(m_s+m_u,m_s+m_u));
    DDP_bound(theta,theta) = DDP;  
    
    [ QQ, DQQ, DDQQ]    = compute_ProductRule( Q_bound, DQ_bound, DDQ_bound, Q_bound, DQ_bound, DDQ_bound); %   Q*Q 
    [ QQQ, DQQQ, DDQQQ] = compute_ProductRule( Q_bound, DQ_bound, DDQ_bound, QQ, DQQ, DDQQ);                %   Q*Q*Q
    [ PQQ, DPQQ, DDPQQ] = compute_ProductRule( P_bound, DP_bound, DDP_bound, QQ, DQQ, DDQQ);                %   P*Q*Q

      R = (3 *   PQQ) +  QQQ;
     DR = (3 *  DPQQ) + DQQQ;
    DDR = (3 * DDPQQ) +DDQQQ;

%     DDR
%     DDE_N
%     
      S_finite =  R +   E_N;
     DS_finite = DR +  DE_N;
    DDS_finite =DDR + DDE_N;
    
    
    
%%   Section 7.3.4 Bounding \tilde{N}


    [ ~ , ~ , pi_u_DDN  ] = compute_ProductRule(  pi_u_DK_inv,  pi_u_dDK_inv,  pi_u_ddDK_inv,  S_finite,DS_finite,DDS_finite);
    [ ~ , pi_th_DN , pi_th_DDN ] = compute_ProductRule(  pi_th_DK_inv, pi_th_dDK_inv, pi_th_ddDK_inv, S_finite,DS_finite,DDS_finite);
    [ pi_f_N , pi_f_DN , pi_f_DDN  ] = compute_ProductRule(  pi_f_DK_inv,  pi_f_dDK_inv,  pi_f_ddDK_inv,  S_finite,DS_finite,DDS_finite);
% % %     pi_f_DK_inv,  pi_f_dDK_inv,  pi_f_ddDK_inv
% % %     S_finite,DS_finite,DDS_finite
% % %     pi_f_N , pi_f_DN , pi_f_DDN  

    
%     pi_th_DN 
%     pi_th_DDN*[r_u;radii]
    
%     This is \pi_\infty N
    DDN_tail = DDR + DDE_tail;


    %% Define Estimate 3 output 
    % Note, the projection maps ||\pi_\bi||_{\cL(X,X)} have norm 1
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %         C_i^{jk}
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %     s s s
    C_s_s_s = intval(zeros(m_s, m_s, m_s));
    C_s_s_s(1,:,:) = reshape(pi_th_DDN(2:end,2:end),[1 3 3]);
    C_s_s_s(2,:,:) = reshape(pi_f_DDN(2:end,2:end) ,[1 3 3]);
    C_s_s_s(3,:,:) = reshape(DDN_tail(2:end,2:end) ,[1 3 3]);
    %     s u s
    C_s_u_s = intval(zeros(m_s, m_u, m_s));
    C_s_u_s(1,:,:) = reshape(pi_th_DDN(1,2:end),[1 1 3]);
    C_s_u_s(2,:,:) = reshape(pi_f_DDN(1,2:end) ,[1 1 3]);
    C_s_u_s(3,:,:) = reshape(DDN_tail(1,2:end) ,[1 1 3]);
    
    %     s s u
    C_s_s_u = intval(zeros(m_s, m_s, m_u));
    C_s_s_u(1,:,:) = reshape(pi_th_DDN(1,2:end),[1 3 1]);
    C_s_s_u(2,:,:) = reshape(pi_f_DDN(1,2:end) ,[1 3 1]);
    C_s_s_u(3,:,:) = reshape(DDN_tail(1,2:end) ,[1 3 1]);
    
    %     s u u
    C_s_u_u = intval(zeros(m_s, m_u, m_u));
    C_s_u_u(1,:,:) = reshape(pi_th_DDN(1,1),[1 1 1]);
    C_s_u_u(2,:,:) = reshape(pi_f_DDN(1,1) ,[1 1 1]);
    C_s_u_u(3,:,:) = reshape(DDN_tail(1,1) ,[1 1 1]);
    
    
    %     u s s
    C_u_s_s         = intval(zeros(m_u, m_s, m_s));
    C_u_s_s(1,:,:)  = reshape(pi_u_DDN(2:end,2:end),[1 3 3]);
    
    %     u u s
    C_u_u_s         = intval(zeros(m_u, m_u, m_s));
    C_u_u_s(1,:,:)  = reshape(pi_u_DDN(1,2:end),[1 1 3]);
    
    %     u s u
    C_u_s_u         = intval(zeros(m_u, m_s, m_u));
    C_u_s_u(1,:,:)  = reshape(pi_u_DDN(1,2:end),[1 3 1]);
    %     u u u
    C_u_u_u         = intval(zeros(m_u, m_u, m_u));
    C_u_u_u(1,:,:)  = reshape(pi_u_DDN(1,1),[1 1 1]);

 %% We construct the output

% The output C_info:
%   contains the tensors D_j^i and C_j^{ik} satisfying Proposition 2.4 
    
   C_info_Z2 = {  ...    
    C_s_s_s ; ...
    C_s_u_s ; ...
    C_s_s_u ; ...
    C_s_u_u ; ...
    C_u_s_s ; ...
    C_u_u_s ; ...
    C_u_s_u ; ...
    C_u_u_u };

end

%% Aux Functions
% Throughout, we assume the following format for variables A,DA,DDA
%   A   - Assumed to be a single number
%  DA   - A vector, containing the partial derivatives of A
% DDA   - A matrix, containing the mixed partial derivatives of A.

function [ AB, D_AB, DD_AB ] = compute_ProductRule( A, DA, DDA, B, DB, DDB)
% This function computes a bound on the product AB, and its derivatives
% using the product rule. 
       AB   = A*B;
     D_AB   = A*DB + B*DA;
    DD_AB   = DDA*B + DA*DB' + DB*DA' + A*DDB; 
end

function [ A1_bound , DA1_bound, DDA1_bound ]   = create_A1( Q_info,r_u, r_f ) 
% Computes bounds on the function A_1(\theta,\phi), defined in Section 7.3.1

% Define the subspace splitting
        m_s = 3;
        m_u = 1;

% Define the index for the subspaces { u, \theta, f, \infty}        
        u   = 1;
    theta   = 2;
        f   = 3;
    infty   = 4;

% We import the appropriate bounds on Q_u, the unstable bundle
   Q_u  = Q_info{1};
  dQ_u  = Q_info{2};
 ddQ_u  = Q_info{3};
dddQ_u  = Q_info{4};
% We import the appropriate bounds on Q_f, the fast-stable bundle 
   Q_f  = Q_info{5};
  dQ_f  = Q_info{6};
 ddQ_f  = Q_info{7};
dddQ_f  = Q_info{8};

% C^0 bound
    A1_bound         = dQ_f*r_f+dQ_u*r_u;
% C^1 bound    
    DA1_bound        = intval(zeros(m_s+m_u,1));
    DA1_bound(theta) = ddQ_f*r_f+ddQ_u*r_u;
    DA1_bound(u)     = dQ_u;
    DA1_bound(f)     = dQ_f;
% C^2 bound
    DDA1_bound       = intval(zeros(m_s+m_u,m_s+m_u));
    DDA1_bound(theta,theta) = dddQ_f*r_f+dddQ_u*r_u;
    
    DDA1_bound(theta,u)     = ddQ_u;
    DDA1_bound(u,theta)     = ddQ_u;
    
    DDA1_bound(theta,f)     = ddQ_f;
    DDA1_bound(f,theta)     = ddQ_f;

end

function [ Inv , dInv , ddInv ]                 = bound_Inverse(  M , DM , DDM)
% Computes bounds on (I + M)^{-1} and its derivatives, see Section 7.3.1
 
% C^0 Bound
if M <1
    Inv = 1/(1-M);
else
    disp('WARNING!! Neumann series does not converge!!')
    Inv     = NaN;
    dInv    = NaN;
    ddInv   = NaN;
    return
end

% C^1 Bound 
dInv = (Inv^2) * DM;
% C^2 Bound
ddInv   = Inv^2*(DDM + 2*Inv*(DM*DM') ); 
    
end

function [ Q_out , DQ_out, DDQ_out ]            = create_Q( Q_info,r_u, r_f ,r_infty) 
% We bound the BOLD Q and its derivatives -- see Section 7.3.3

% Define the subspace splitting
    m_s=3;
    m_u=1;
% Define the index for the subspaces { u, \theta, f, \infty}          
        u   = 1;
    theta   = 2;
        f   = 3;
    infty   = 4;

% We import the appropriate bounds on Q_u, the unstable bundle    
   Q_u  = Q_info{1};
  dQ_u  = Q_info{2};
 ddQ_u  = Q_info{3};
% We import the appropriate bounds on Q_f, the fast-stable bundle 
   Q_f  = Q_info{5};
  dQ_f  = Q_info{6};
 ddQ_f  = Q_info{7};
 
    % C^0 Bounds 
    Q_out   = Q_u*r_u + Q_f*r_f  + r_infty;
    % C^1 Bounds     
    DQ_out        = intval(zeros(m_s+m_u,1));
    
    DQ_out(theta) = dQ_f * r_f  + dQ_u *r_u;
    DQ_out(f)     = Q_f;
    DQ_out(u)     = Q_u;
    DQ_out(infty) = intval(1);
    
    % C^2 Bounds 
    DDQ_out               = intval(zeros(m_s+m_u,m_s+m_u));
    DDQ_out(theta,theta)  = ddQ_f*r_f + ddQ_u*r_u;
    
    DDQ_out(theta,f)      = dQ_f;
    DDQ_out(f,theta)      = dQ_f;
    
    DDQ_out(theta,u)      = dQ_u;
    DDQ_out(u,theta)      = dQ_u;

end

function [ E_N, DE_N, DDE_N, E_tail, DE_tail, DDE_tail] = compute_E(  E_slow, E_fast, E_unst,E_infty,r_f, r_infty, r_u)
% Computes a bound on (\pi_N E ) and ( \pi_\infty E), and derivatives 
% See -- Section 7.3.2

% E_* is a 3x2 matrix  
%       -- first column corresponds to pi_N 
%       -- second column corresponds to pi_\infty 
%   -- Rows correspond to [ value ; derivative ; 2 derivative]
    

% Define the subspace splitting
        m_s = 3;
        m_u = 1;

% Define the index for the subspaces { u, \theta, f, \infty}        
        u   = 1;
    theta   = 2;
        f   = 3;
    infty   = 4;
% Defines the index for derivative bounds    
      val   = 1;
       d1   = 2;
       d2   = 3;

%%%%%%%%%%%%%%%%%%
%%% E
E_N     = E_slow(val,1) + E_fast(val,1)*r_f +E_unst(val,1)*r_u +E_infty(val,1)*r_infty;
E_tail  = E_slow(val,2) + E_fast(val,2)*r_f +E_unst(val,2)*r_u +E_infty(val,2)*r_infty;

%%%%%%%%%%%%%%%%%%
%%% DE
DE_N    = intval(zeros(m_s+m_u,1));
DE_tail = intval(zeros(m_s+m_u,1));


% theta 
DE_N(theta)     = E_slow(d1,1) + E_fast(d1,1)*r_f + E_unst(d1,1)*r_u + E_infty(d1,1)*r_infty;
DE_tail(theta)  = E_slow(d1,2) + E_fast(d1,2)*r_f + E_unst(d1,2)*r_u + E_infty(d1,2)*r_infty;
% u 
DE_N(u)     = E_unst(val,1);
DE_tail(u)  = E_unst(val,2);
% f 
DE_N(f)     = E_fast(val,1);
DE_tail(f)  = E_fast(val,2);
% infty
DE_N(infty)    = E_infty(val,1);
DE_tail(infty) = E_infty(val,2);

%%%%%%%%%%%%%%%%%%
%%% DDE
DDE_N     = intval(zeros(m_s+m_u,m_s+m_u));
DDE_tail  = intval(zeros(m_s+m_u,m_s+m_u));


% theta theta  (22)
DDE_N(theta,theta)    = E_slow(d2,1) + E_fast(d2,1)*r_f + E_unst(d2,1)*r_u + E_infty(d2,1)*r_infty;
DDE_tail(theta,theta) = E_slow(d2,2) + E_fast(d2,2)*r_f + E_unst(d2,2)*r_u + E_infty(d2,2)*r_infty;

% theta u       (12) & (21)
DDE_N(theta,u)        = E_unst(d1,1);
DDE_tail(theta,u)     = E_unst(d1,2);

DDE_N(u,theta)        = E_unst(d1,1);
DDE_tail(u,theta)     = E_unst(d1,2);


% theta f       (23) & (32)
DDE_N(theta,f)        = E_fast(d1,1);
DDE_tail(theta,f)     = E_fast(d1,2);

DDE_N(f,theta)        = E_fast(d1,1);
DDE_tail(f,theta)     = E_fast(d1,2);

% theta infty   (24) & (42)
DDE_N(theta,infty)    = E_infty(d1,1);
DDE_tail(theta,infty) = E_infty(d1,2);

DDE_N(infty,theta)    = E_infty(d1,1);
DDE_tail(infty,theta) = E_infty(d1,2);


end

