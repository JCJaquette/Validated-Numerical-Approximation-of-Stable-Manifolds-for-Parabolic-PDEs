function [ T_tensor ] = T_2derivative( K_tensor , A_tensor, j ,H_s_s,gamma_s,mu_s,RIGOROUS)
%T_2derivative - Theorem 4.10 & Proposition A.3 
%   Computes T_j( K )
% 
% Last Modified:  02-01-2020

    m_s = length(K_tensor(:,1,1,1,1));
    N_gamma = length(K_tensor(1,1,1,:,1));
    
% K_{j,k1,k2}^{i,m} = K(j,i,m,k1,k2)

    % Exponent Index value for j
    J = j+1;
    
    if RIGOROUS
        T_tensor = intval(zeros(1,m_s,m_s,N_gamma,N_gamma));
    else 
        T_tensor = zeros(1,m_s,m_s,N_gamma,N_gamma);
    end 

    %     We only multiply H_j^i  when i!=j    
    H_s_s(j,j)=0;
    
    
    for k1 = 1:N_gamma
        for k2 = 1:N_gamma+1
            if ~( (k1==J)&&(k2==1) )
                % We are not the resonant exponent
                const = ( mu_s(k1,k2) - gamma_s(J) );

                for i = 1:m_s
                    for m = 1:m_s
                        % Note A_{j,,k1,k2}^{i,m2}  = A(j,i,m2,k1,k2)
                        summand1 = A_tensor(j,i,m,k1,k2); 
                        summand2 = H_s_s(j,:)*K_tensor(:,i,m,k1,k2);
                        value =  (summand1 + summand2)/const;
                        
                        T_tensor(1,i,m,k1,k2) = value;
                        T_tensor(1,i,m,J,1)   = T_tensor(1,i,m,J,1) -value;
                    end
                end
            end
        end
    end

end

