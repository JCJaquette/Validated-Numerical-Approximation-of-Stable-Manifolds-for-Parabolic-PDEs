function [ G_s_s__k ] = create_G( H_s_s , gamma_s, repetitions_bootstrap , C_s )
%create_G - Implements Algorithm 3.11; outputs a tensor G satisfying Condition 3.4
% 
% We output a tensor << G_s_s__k  >> where 
% 
%               G_{j,k}^n  = G(j,n,k)
% 
% Last Modified:  02-01-2020

% We determine the m_s dimension
m_s = length(H_s_s(1,:));


% We initialize G^hat as defined in Remark 3.5
% Note: In our study of the Swift-Hohenberg PDE, we use a norm where p_j=1
G_s_s__k = intval(zeros(m_s,m_s,m_s+1));
G_s_s__k(:,:,1)= C_s * intval(ones(m_s,m_s));


% STEP 2  We bootstrap our bounds
for N_bootstrap = 1:repetitions_bootstrap    
    for j = fliplr(1:m_s) 
        % We iterate through the subspace dimensions j starting at the end
        %   the end-subspace will have a larger gap; unclear if this makes
        %   a noticable difference
        
        % Make Better Bounds
        Q_j = Q_basic( G_s_s__k , j );
        G_s_s__k(j,:,:) =  T_basic( Q_j , j, H_s_s, gamma_s);
    end    
end

% Return Output!
end

