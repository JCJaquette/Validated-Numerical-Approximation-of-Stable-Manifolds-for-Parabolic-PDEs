function [ gamma_s ] = create_gamma( lambda_s,H_s_s ,lambda_0 , C_s, H_hat )
%create_gamma - Creates the tensor \gamma_k from Definition 3.3
%
% lambda_s  -   The vector \lambda_j of length m_s describing the stable
%               exponential-decay-rates; see section 2.1 Equation (6).
% H_s_s     -   The m_s x m_s matrix H_j^i defined in Definition 2.6 
% lambda_0  -   Variable lambda_s from Theorem B.1; 
% C_s       -   Variable C_s from Theorem B.1; 
% H_hat     -   The constant \hat{\mathcal{H}} defined in Definition 2.6 
% 
% Last Modified:  12-16-2019
 
    m_s = length(lambda_s);    
    gamma_0 = lambda_0 + C_s *H_hat;
    
    if m_s == 1 % Not sure if this ever gets used
        gamma_s = gamma_0;
    else 
        gamma_s = lambda_s + transpose(diag(H_s_s));
        gamma_s = [ gamma_0, gamma_s];
    end
    
    if gamma_0 > 0 
        disp('WARNING gamma_0 >0 !!!')
    end       
end

