function [ S_s_out , S_u_out] = create_S( P_u_s , P_u_s_s , C_s_s , C_s_u, C_u_s, C_u_u , C_info)
%create_S - Creates the tensor S from Proposition 4.6
% S_{j}^{n,m} = S(j,n,m)
% 
% Last Modified:  12-22-2019

m_u = length(P_u_s(:,1));
m_s = length(P_u_s(1,:));


    C_s_s_s  = C_info{5};
    C_s_u_s  = C_info{6};
    C_s_s_u  = C_info{7};
    C_s_u_u  = C_info{8};
    
    C_u_s_s  = C_info{9};
    C_u_u_s  = C_info{10};
    C_u_s_u  = C_info{11};
    C_u_u_u  = C_info{12};
    
% Stable Projection
% S_{j}^{n,m} = S(j,n,m)    
S_s_out = intval(zeros(m_s,m_s,m_s));
for j = 1:m_s
    for n = 1:m_s
        for m = 1:m_s
            % C_j^nm + C_j^nm' P_m'^m
            summand_1 = C_s_s_s(j,n,m)+C_s_s_u(j,n,:)*P_u_s(:,m); 
            % C_j^n' P_n'^nm
            summand_2 = C_s_u(j,:)*P_u_s_s(:,n,m);
            % (C_j^n'm +C_j^n'm' P_m'^m ) P_n'^n 
            summand_3 = intval(0);
            for n_prime = 1:m_u
                summand_3a = (C_s_u_s(j,n_prime,m) + C_s_u_u(j,n_prime,:)*P_u_s(:,m)) *P_u_s(n_prime,n);
                summand_3 = summand_3  +summand_3a  ;
            end
            S_s_out(j,n,m)      = summand_1 + summand_2  + summand_3 ;
        end
    end
end

% Unstable Projection
% S_{j'}^{n,m} = S(j,n,m)
S_u_out = intval(zeros(m_u,m_s,m_s));
for jprime = 1:m_u
    for n = 1:m_s
        for m = 1:m_s
            % C_j'^nm + C_j'^nm' P_m'^m
            summand_1 = C_u_s_s(jprime,n,m)+C_u_s_u(jprime,n,:)*P_u_s(:,m);            
            % C_j'^n' P_n'^nm
            summand_2 = C_u_u(jprime,:)*P_u_s_s(:,n,m);
            % (C_j'^n'm +C_j'^n'm' P_m'^m ) P_n'^n 
            summand_3 = intval(0);
            for n_prime = 1:m_u
                summand_3a = (C_u_u_s(jprime,n_prime,m) +  C_u_u_u(jprime,n_prime,:)*P_u_s(:,m)) *P_u_s(n_prime,n);
                summand_3 = summand_3  +summand_3a  ;
            end
            S_u_out(jprime,n,m) = summand_1 + summand_2  + summand_3 ;
        end
    end
end

end

