function [ H_s_s, H_u_s ] = create_H( C_s_s, C_s_u, C_u_u, C_u_s, P_u_s)
%create_H -  Creates the tensor H from Definition 2.6 
% H_j^i = H(j,i)
% 
% Last Modified:  12-13-2019

H_s_s = C_s_s + C_s_u * P_u_s;
H_u_s = C_u_s + C_u_u * P_u_s;

end

