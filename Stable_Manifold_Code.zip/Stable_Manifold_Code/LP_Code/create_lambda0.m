function [ lambda_0 , C_s , success] = create_lambda0( lambda_s, D_s_s  ,eigenValues)
%create_lambda0 - Theorem B.1
%   We compute semigroup bounds. Used in Section 6.2.5, 7.5 
% 
%  Gives bound | e^{ (\Lambda_s+L_s^s ) t} |   \leq    C_s e^{ \lambda_0 t}
% 
%  success == whether the hypothesis of Theorem B.1 was satsified 
%   
% Last Modified:  02-24-2020
 

    m_s = length(lambda_s);    
    Lambda_1 = eigenValues(eigenValues<0);
    
    
    % mu_1
    mu_1 = max(lambda_s);
    % mu_infty
    mu_infty = lambda_s(end);
    
%   delta_*  
    D_N_sum = intval(zeros(m_s-1,1));
    for i=1:m_s-1
        D_N_sum(i) = sum(D_s_s(1:m_s-1,i));
    end

    delta_a   = max(D_N_sum);
    delta_b   = sum(D_s_s(1:m_s-1,end    ));
    delta_c   = max(D_s_s(end    ,1:m_s-1));
    delta_d   = D_s_s(end,end);
    
    denominator = abs(mu_infty) - (delta_d + abs(Lambda_1));
    epsilon     = sum( denominator.^-1);
    
        
% % % %     We compute our tests

    if 1 > (delta_d+ max(abs(Lambda_1)))/abs(mu_infty)
        test_1 =1;
    else
        test_1 =0;
    end
    
    infty_decay = mu_infty + delta_d + epsilon*delta_b * delta_c *(1 + epsilon^2 * delta_b*delta_c);
    if mu_1 > infty_decay 
        test_2 =1;
    else
        test_2 = 0;
    end
    success = test_1 && test_2;
   
%   We define the output
    C_s = (1 + epsilon*delta_b)^2*(1+epsilon*delta_c)^2;

    Delta = epsilon* delta_b * delta_c * max([ 1+ epsilon*delta_c* ( 1+ epsilon * delta_b),epsilon * delta_b * ( 2 + epsilon^2 * delta_b * delta_c)]);    
    lambda_0 = mu_1 + C_s*delta_a + Delta;

    
    if lambda_0 > 0 
        disp('WARNING lambda_0 > 0 !!!')
    end 
    
    
    
end

