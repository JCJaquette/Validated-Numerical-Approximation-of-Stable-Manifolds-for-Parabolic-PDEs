function [ bool , radii_suggest] = check_R( radii, gamma_s, G_s_s__k )
%check_R - Implements the steps described in Remark 3.14
%         to give a computer assisted proof of Proposition 3.13. 
%         Namely, that:
%           rho_j >= sum_k e^{gamma_k t} G_j,k^n rho_n
% 
% Step 1 - Checks inequality on interval [T_2, +\infty) 
% Step 2 - Checks inequality on interval [T_1, T_2] 
% Step 3 - Checks inequality on interval [0, T_1] 
% 
% Last Modified:  03-30-2020

    
%  We define implicit variables
    m_s = length(G_s_s__k(:,1,1));
    N_lambda = length(gamma_s);

% Computational Parameters for implementing Remark 3.14
    T_1 = intval(0.02);     %% For checking the derivative in Step 3
    T_2 = intval(2);        %% Variable T_2 used in Parts 1&2    
    
    subdivisions_small  = 2000; % Subdivisions of [0  , T_1]
    subdivisions_medium = 2000;  % Subdivisions of [T_1, T_2]   
    
%   If there is failure in a particular component, we suggest a new radius
%   equal to the maximum in that component, multiplied by the value below
    increase_radius_multiplier = 1.00;
    
%   If VERBOSE is true, 
%       then we will output which part of Remark 3.14 failed, if any.
%   If PRODUCE_GRAPHS is true,
%       then we make graphs of the equation in Proposition 3.13 for each radius.
    VERBOSE         = 0;
    PRODUCE_GRAPHS  = 0;
 
% Output
    bool = ones(1,m_s);    % For each component, whether the inequality is true
    radii_suggest = radii; % Suggested radii; supremum on [0,T_2] of sum_k e^{gamma_k T_2} G_j,k^n rho_n  
    
    if ~all(gamma_s<0)
        % gamma_0 > 0 (This is quite bad)
        bool = 0*bool;
        return
    end

%%   The Code below plots the graph 
    
    if PRODUCE_GRAPHS
        % We create the time 
        t = linspace(0,T_2,subdivisions_small);
        t=mid(t);
        % We go through each stable dimension j
        for j = 1:m_s        
            y_j = 0*t;
            for n = 1:m_s
                y_j_n = 0*t;
                % We sum over the decaying exponential
                for k = 1:N_lambda
                    y_j_n= y_j_n + G_s_s__k(j,n,k)  * exp( gamma_s(k) * t);
                end
                % We sum over the radius
                y_j = y_j + y_j_n * radii(n);
            end
            figure
            plot(t,y_j)
            xlabel('t') 
            ylabel(['x_' num2str(j) '(t)']) 
        end
    end

%% Step 1: Validate Tail
%   � rho_j > sum_k e^{gamma_k T_2} abs|G_j,k^n| rho_n ?
    for j = 1:m_s
%       Computes: sum_k e^{gamma_k T_2} abs|G_j,k^n| rho_n
        yMax_j = intval(0);
        for n = 1:m_s
            yMax_j_n = intval(0);
            for k = 1:N_lambda
                yMax_j_n= yMax_j_n + abs(G_s_s__k(j,n,k))  * exp( gamma_s(k) * T_2);
            end            
            yMax_j = yMax_j + yMax_j_n * radii(n);
        end 
%       Checks the inequality
        if ~(radii(j)> yMax_j )
            bool(j)=0;
            if VERBOSE
                disp(['Tail fail in component ' num2str(j) ])
            end
        end        
    end   

    
%% Step 2: Validate Interior
%   We create a vector of -subdivisions_medium- intervals covering [T_1,T_2] 
    mesh_medium_pts = linspace(T_1,T_2,subdivisions_medium);
    mesh_medium = infsup(inf(mesh_medium_pts(1:end-1)),sup(mesh_medium_pts(2:end)));

    
%   � rho_j > sum_k e^{gamma_k t} G_j,k^n rho_n ? for all t in [T_1,T_2]
    for j = 1:m_s
        % Computes sum_k e^{gamma_k t} G_j,k^n rho_n 
        %   on a mesh spanning [T_1,T_2]
        y_j = 0*mesh_medium;
        for n = 1:m_s
            y_j_n = 0*mesh_medium;
            for k = 1:N_lambda
                y_j_n= y_j_n + G_s_s__k(j,n,k)  * exp( gamma_s(k) * mesh_medium);
            end            
            y_j = y_j + y_j_n * radii(n);
        end
%       Checks inequality on [T_1,T_2]
        if any( ~(radii(j) >y_j))
            bool(j)=0;
            if VERBOSE
                disp(['Interior fail in component ' num2str(j) ])
            end
            radii_suggest(j)=sup(max(y_j));
        end
        
        
    end

%% Step 3: Validate Derivative
%   We create a vector of -subdivisions_small- many intervals covering [0,T_1] 
    mesh_small_pts = linspace(intval(0),T_1,subdivisions_small);
    mesh_small = infsup(inf(mesh_small_pts(1:end-1)),sup(mesh_small_pts(2:end)));

%   � rho_j > sum_k gamma_k e^{gamma_k t} G_j,k^n rho_n ? \forall t \in (0,T_1]
    for j = 1:m_s
        yPrime_j = 0*mesh_small; %% Calculating the derivative on [0,T_1]
        y_j      = 0*mesh_small; %% Calculating the maximum    on [0,T_1]
        for n = 1:m_s
            yPrime_j_n  = 0*mesh_small;
            y_j_n       = 0*mesh_small;
            for k = 1:N_lambda
                yPrime_j_n  = yPrime_j_n + gamma_s(k) * G_s_s__k(j,n,k)  * exp( gamma_s(k) * mesh_small);
                y_j_n       = y_j_n + G_s_s__k(j,n,k)  * exp( gamma_s(k) * mesh_small);
            end            
            yPrime_j = yPrime_j + yPrime_j_n * radii(n);
            y_j      = y_j + y_j_n * radii(n);
        end
%       Checks inequality on [0,T_1]
        if any( ~(0 > yPrime_j)) || bool(j)==0
            bool(j)=0;
            if VERBOSE
                disp(['Derivative fail in component ' num2str(j) ])
            end
            radii_suggest(j) = max(radii_suggest(j),sup(max(y_j)))*increase_radius_multiplier;
        end 
    end    

end

