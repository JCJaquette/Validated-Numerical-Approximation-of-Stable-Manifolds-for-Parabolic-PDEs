function [ H_hat_s_s ,  H_hat] = create_H_hat( C_hat_s_s, C_hat_s_u, C_defect_s_u, P_u_s)
%create_H_hat -  Creates \hat{H} and \hat{\cH} from Definition 2.6 
% 
% Last Modified:  12-13-2019

  m_s = length(C_hat_s_s(1,:));
  
% \hat{H}_j^i  = \hat{C}_j^i + ( \hat{C}_j^{n'} + \hat{D}_j^{n'} ) P_{n'}^i
  H_hat_s_s = C_hat_s_s + (C_hat_s_u + C_defect_s_u )* P_u_s;

%   \hat{\cH} is computed using the formula in Proposition 2.7
%       Namely,  if   h^i = sum ( H_hat(j,i) ) , the sum of column i 
%       Then   \hat{\cH} <= max \{ h^i \}
  H_hat = max( transpose(H_hat_s_s)*ones(m_s,1) );


end

