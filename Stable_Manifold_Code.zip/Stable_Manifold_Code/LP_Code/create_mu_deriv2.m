function [ mu_s ] = create_mu_deriv2( gamma_s )
%create_mu_deriv2 - We create a matrix mu_s containing the rates described in Remark 4.8     
%   it is of size N_gamma x (N_gamma + 1)  
%   mu_s is gamma(k1) in the first column
%   mu_s is gamma(k1)+gamma(k2-1) elsewhere
% 
%   This matrix contains
%       \gamma_{k_1} + \gamma_{k_2}  AND    \gamma_{k_2} + \gamma_{k_1}  
%   as two distinct entries.
% 
% Used in 
% -- bound_P2 
% -- Q_2derivative 
% -- create_K
% 
% Last Modified:  12-21-2019

    N_gamma = length(gamma_s);
    
    mu_s = intval(zeros(N_gamma,N_gamma+1));
    mu_s(:,1) = gamma_s;
    Helper_Matrix = intval(ones(N_gamma,N_gamma))*diag(gamma_s);
    mu_s(:,2:end) = Helper_Matrix+Helper_Matrix'; % This is symmetric    
    
end

