function [ output_args ] = plot_G( G_s_s__k , gamma_s, j )
%plot_G - Condition 3.4 (not used in the computer assisted proof)
%   -- Plots each Sum_k G_{i,k}^n e^{\gamma_k t}
% 
% Last Modified:  04-30-2019

    m_s = length(G_s_s__k(:,1,1));
    N_lambda = length(gamma_s);
    
    
    % We create time 
    t_max = 2;
    t = 0:.01:t_max;
    
    G_s_s__k = mid(G_s_s__k);
    gamma_s  = mid(gamma_s);
    
    figure
    hold on
    legend('')
    for n = 1:m_s
        y_j_n = 0*t;
        
        for k = 1:N_lambda
            y_j_n= y_j_n + G_s_s__k(j,n,k)  * exp( gamma_s(k) * t);
        end
        
        plot(t,y_j_n,'DisplayName',['|\xi_' num2str(n) '|'])
    end
    hold off
    xlabel('t') 
    ylabel(['x_' num2str(j) '(t)']) 

    
end

