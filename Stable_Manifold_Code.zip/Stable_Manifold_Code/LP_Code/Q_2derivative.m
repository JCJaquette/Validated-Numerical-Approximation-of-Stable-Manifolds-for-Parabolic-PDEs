function [ K_tensor ] = Q_2derivative( K_tensor , m1 )
%Q_2derivative - Theorem 4.10 & Proposition A.4
%   Computes Q_m1( K )
% 
% Last Modified:  02-01-2020


% K_{j,k1,k2}^{i,m} = K(j,i,m,k1,k2)
    m_s = length(K_tensor(:,1,1,1,1));
    N_gamma = length(K_tensor(1,1,1,:,1));
    
    % We define M=m+1, because we cannot start counting from 0. 
    M = m1+1;  
    
    for j = 1:m_s
        for i = 1:m_s
            for m2 = 1:m_s
                for k1 = 1:N_gamma
%                     k2=1;
                    value = K_tensor(j,i,m2,M,1);
                    
                    if sup(value) >0
%%%                     We add to a slower decay rate
%                       This is not entirely sharp, but finding the optimal exponent to switch to doesn't seem to provide any improvement. 
                        K_tensor(j,i,m2,M-1,1) = K_tensor(j,i,m2,M-1,1) +value; 
                        K_tensor(j,i,m2,M,1)=0;
                    elseif value <0
% %                     add to faster decay
                        K_tensor(j,i,m2,M,2) = K_tensor(j,i,m2,M,2) +value;
                        K_tensor(j,i,m2,M,1)=0;
                    else
                        % value == 0 
                    end
                    
                end
            end
        end
    end
    
end

