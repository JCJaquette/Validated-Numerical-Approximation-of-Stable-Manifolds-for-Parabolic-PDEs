function [ TEST_STABLE , TEST_RADIUS , TEST_ENDO_1 , TEST_ENDO_2  , Jnorm ] = ...
    ValidateManifold(radii,P_u_s,P_u_s_s,lambda_s,lambda_u,eigen_sorted,C_info,Computational_Parameters,PLOT_G)
%ValidateManifold  -  Checks the hypotheses in Theorem 5.11  
% 
% TEST_STABLE   -   Hypotheses Theorem B.1 and part of Proposition 3.13 
% TEST_RADIUS   -   Hypothesis of Proposition 3.13
% TEST_ENDO_1   -   Hypothesis of Proposition 4.4
% TEST_ENDO_2   -   Hypothesis of Theorem 4.11
% Jnorm         -   Contraction Constant; matrix norm (p=1) on the matrix representation of J
% 
% Last Modified:  02-09-2019

D_s_s = C_info{1};
D_u_s = C_info{2};
D_u_u = C_info{3}; 
D_s_u = C_info{4};

repetitions_bootstrap   = Computational_Parameters{1};
repetitions_F           = Computational_Parameters{2};
repetitions_K           = Computational_Parameters{3};

% We compute all of the relevant constants
[ lambda_0 , C_s , test_Semi_Group] ...
        = create_lambda0( lambda_s, D_s_s ,eigen_sorted );
[ C_s_s , C_s_u, C_u_s, C_u_u , C_hat_s_s , C_hat_s_u , C_hat_u_s ,C_hat_u_u ] ...
        = create_C( P_u_s , C_info , radii);
[ H_s_s, H_u_s ] ...
        = create_H( C_s_s, C_s_u, C_u_u, C_u_s, P_u_s);
[ H_hat_s_s ,  H_hat] ...
        = create_H_hat( C_hat_s_s, C_hat_s_u, D_s_u, P_u_s);
[ gamma_s ] ...
        = create_gamma( lambda_s,H_s_s ,lambda_0 , C_s, H_hat );
[ S_s_s_s , S_u_s_s] ...
        = create_S( P_u_s , P_u_s_s , C_s_s , C_s_u, C_u_s, C_u_u , C_info);   
[ G_s_s__k ] ... 
        = create_G( H_s_s , gamma_s,repetitions_bootstrap,C_s);
[ K_tensor ] ...
        = create_K( H_s_s , gamma_s , S_s_s_s, G_s_s__k,repetitions_K ,C_s,1); %% rigorous calculations

    
% We check that the stable part is stable
% Hypotheses of Proposition 3.13 & Theorem B.1
TEST_STABLE = all(gamma_s <0 ) && test_Semi_Group;    

% We check the projected system stays inside the ball B_s(\rho)
% Hypothesis of Proposition 3.13; Remark 3.14
[bool_radius, ~] = check_R( radii, gamma_s, G_s_s__k );
TEST_RADIUS = all(bool_radius );

% We check endomorphism for     \Psi: \cB^{0,1} -> \cB^{0,1}
% cf. Proposition 4.4
[ P_out ] = bound_P_alt( G_s_s__k,C_info,P_u_s ,radii,lambda_u ,gamma_s );
TEST_ENDO_1 = all(P_out < P_u_s);

% We check endomorphism for     \Psi: \cB^{1,1} -> \cB^{1,1}
% cf. Theorem 4.11
[ P2_out ] = bound_P2( S_u_s_s, K_tensor, G_s_s__k, H_u_s, gamma_s,lambda_u );
TEST_ENDO_2 = all(P2_out < P_u_s_s,'all');

% Computes Tensor F from Section 5
mu_s = [ gamma_s(1)/2, gamma_s];
F_tensor = create_F( H_s_s , gamma_s , C_s_u, G_s_s__k,repetitions_F,C_s,mu_s);
%  tensor J from Definition 5.8; matrix representation; matrix norm (p=1)
[ ~ ,Jmat, Jnorm ] = create_J( G_s_s__k,F_tensor,C_u_u,H_u_s,lambda_u ,mu_s );

if PLOT_G
    for j = 1:length(G_s_s__k(:,1,1))
            plot_G( G_s_s__k , gamma_s, j)
    end
end

end

