function [C_info, epsilon_u, epsilon_s  ] = data_SH(C_info_Z1, m_s, m_u,P_u_s,radii ,a1,Q,N ,nu, morse_index,error)
%data_SH We compute Estimates 3 & 4 from section 6.2.3 & 6.2.4
% C_info_Z1 -- The constants \tilde{D} 
% m_s, m_u, -- Splitting of the stable/unstable eigenspace into subspaces
% P_u_s     -- The cone in which we look for stable manifolds
% radii     -- Radius of the Ball (\rho)
% a1        -- The approximate equilibrium \bar{a}
% Q1        -- The (ordered) finite-dim eigenvectors
% N         -- The Galkerin Trunctation 
% nu        -- The weight for our space \ell_\nu^1
% morse_index   -- The number of unstable eigenvalues
% error     -- The distance | \bar{a} - \tilde{a} |_{\ell_\nu^1} from the approximate equilibrium to the true equilibrium 
% % % 
%
% This outputs C_info - - 
%   containing the tensors D_j^i and C_j^{ik} 
%   satisfying Proposition 2.4 
% Last Modified:  02-05-2020
    
if m_s ~= 2 || m_u ~= 1 
    disp('Improper Splitting of stable/unstable eigenspace into subspaces')
    disp('The function "data_SH" has hardcoded m_s == 2 and m_u == 1')
end


[C_info_Z2 , epsilon_u, epsilon_s ] = data_SH_Z2( m_s, m_u,P_u_s,radii ,a1,Q,N ,nu, morse_index,error);

[ D_info ] = create_D(C_info_Z1,C_info_Z2 , epsilon_u, epsilon_s);

% The output C_info:
%   contains the tensors D_j^i and C_j^{ik} satisfying Proposition 2.4 
    
C_info = [D_info ; C_info_Z2];

    for k = 1:length(C_info)
        C_info{k} = intval(sup(C_info{k}));
    end

end
