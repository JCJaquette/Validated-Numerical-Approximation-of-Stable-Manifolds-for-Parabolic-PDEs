function [C_info_Z2, epsilon_u_vector, epsilon_s_vector]=data_SH_Z2(m_s,m_u,P_u_s,radii,a1,Q,N,nu,morse_index,error)
%data_SH We compute Estimates 3 from section 6.2.3 
% m_s, m_u, -- Splitting of the stable/unstable eigenspace into subspaces
% P_u_s     -- The 
% radii     -- Radius of the Ball (\rho)
% a1        -- The approximate equilibrium \bar{a}
% Q1        -- The (unordered) finite-dim eigenvectors
% N         -- The Galkerin Trunctation 
% nu        -- The weight for our space \ell_\nu^1
% morse_index   -- The number of unstable eigenvalues
% error     -- The distance | \bar{a} - \tilde{a} |_{\ell_\nu^1} from 
%               the approximate equilibrium to the true equilibrium 
% 
% This outputs C_info  containing the tensors C_j^{ik} 
%  satisfies Proposition 2.4 on a ball B(r_s+\eps_s,r_u+\eps_u)
% 
% Last Modified:  02-07-2020
% 
   
if m_s ~= 2 || m_u ~= 1 
    disp('Improper Splitting of stable/unstable eigenspace into subspaces')
    disp('The function "data_SH" has hardcoded m_s == 2 and m_u == 1')
end
 
 %% Bound on || \pi_k Q^{-1} || in  L( l^1,X)  norm
 
% We compute the weights which define the X-norm
% New_Norms(k) is the ell^1_nu norm of the k^th column of Q.

New_Norms = intval(zeros(1,N+1));
for i = 1:N+1
    New_Norms(i)=ellOneNorm_intval(Q(:,i),nu,N);
end

% Define projection maps into subspaces 

% pi_1' = pi_u 
pi_u = intval(zeros(N+1,N+1));
for i = 1:morse_index
    pi_u(i,i)= intval(1);
end
% pi_1 = pi_f  (Finite stable subspace)
pi_f = intval(zeros(N+1,N+1));
for i = morse_index+1:N+1
    pi_f(i,i)= intval(1);
end

% Bound on || \pi_k Q^{-1} || in  L( l^1,X)  norm
pi_u_Q_inv = norm_ell_to_X( pi_u/Q , nu, New_Norms);
pi_f_Q_inv = norm_ell_to_X( pi_f/Q , nu, New_Norms);

pi_s_Q_inv = [pi_f_Q_inv ,intval(1)];

% % % % % % % % % % % % % % % 

%% Bounds for \epsilon_i from Section 6.1 before equation (50).

% We compute the distance from true equilibrium in each subspace.
epsilon_u       = error * pi_u_Q_inv;
epsilon_f       = error * pi_f_Q_inv;
epsilon_infty   = error;

epsilon_u_vector = [ epsilon_u ];
epsilon_s_vector = [epsilon_f ; epsilon_infty];


%% Bound C_j^{ik} over a ball B(r_s+\eps_s,r_u+\eps_u) 
%                   ... cf. Section 6.2.3, equation (56)

norm_a_bar = ellOneNorm_intval(a1,nu,N);
error_sum = epsilon_u + epsilon_f + epsilon_infty;
r_u = P_u_s*(radii + epsilon_s_vector);

% Equation (56)
scale_nonlinear = 6 * ( norm_a_bar + r_u + sum(radii)  + error_sum);
    
%   All the estimates are the same, except for the || \pi_k Q^{-1} || term    
    C_u_s_s = pi_u_Q_inv * scale_nonlinear* ones(m_u, m_s, m_s);
    C_u_u_s = pi_u_Q_inv * scale_nonlinear* ones(m_u, m_u, m_s);
    C_u_s_u = pi_u_Q_inv * scale_nonlinear* ones(m_u, m_s, m_u);
    C_u_u_u = pi_u_Q_inv * scale_nonlinear* ones(m_u, m_u, m_u);
    
    C_s_s_s = scale_nonlinear* ones(m_s, m_s, m_s);
    C_s_u_s = scale_nonlinear* ones(m_s, m_u, m_s);
    C_s_s_u = scale_nonlinear* ones(m_s, m_s, m_u);
    C_s_u_u = scale_nonlinear* ones(m_s, m_u, m_u);
    
    for i = 1:m_s
        C_s_s_s(i,:,:) = pi_s_Q_inv(i)*C_s_s_s(i,:,:);
        C_s_u_s(i,:,:) = pi_s_Q_inv(i)*C_s_u_s(i,:,:);
        C_s_s_u(i,:,:) = pi_s_Q_inv(i)*C_s_s_u(i,:,:);
        C_s_u_u(i,:,:) = pi_s_Q_inv(i)*C_s_u_u(i,:,:);
    end


%% We construct the output

% The output C_info:
%   contains the tensors C_j^{ik} satisfying Proposition 2.4 
    
   C_info_Z2 = {  ...    
    C_s_s_s ; ...
    C_s_u_s ; ...
    C_s_s_u ; ...
    C_s_u_u ; ...
    C_u_s_s ; ...
    C_u_u_s ; ...
    C_u_s_u ; ...
    C_u_u_u };
   

end
