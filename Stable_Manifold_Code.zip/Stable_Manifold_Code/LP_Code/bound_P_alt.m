function P_out = bound_P_alt( G_s_s__k,C_info,P_u_s ,radii,lambda_u ,gamma_s )
%bound_P_alt - Computes \tilde{P} from Proposition 4.4
% Input
%   G_{j,k}^n  = G(j,n,k)
%   H_j^i = H(j,i)
% Output
%   P_u^s = P(u,s)
% Last Modified:  12-21-2019

C_defect_u_s    = C_info{2};    % D_u^s 
C_defect_u_u    = C_info{3};    % D_u^s 
C_u_s_s         = C_info{9};    % C_i'^ij
C_u_u_s         = C_info{10};   % C_i'^j'j

m_u = length(C_defect_u_s(:,1));
m_s = length(C_defect_u_s(1,:));
N_gamma = length(gamma_s);

P_out = intval(zeros(m_u,m_s));

% Defines P_i'^n = sum1 + sum2 

for iprime = 1:m_u
  for n = 1:m_s
    sum1 =intval(0);  
  % sum1 = (D_i'^i + D_i'^j' P_j'^i) sum_k   G_{i,k}^n * ( \lambda_i' - \gamma_k)^-1     
    for k = 1:N_gamma 
      const = (lambda_u(iprime)-gamma_s(k));
      summand =intval(0);
      for i = 1:m_s
          summand = summand  +  (C_defect_u_s(iprime,i) + C_defect_u_u(iprime,:)*P_u_s(:,i ))*G_s_s__k(i,n,k)  ;
      end      
      sum1 = sum1 + summand/const;
    end
    
    sum2 =intval(0);
%   sum2 = (C_i'^ij + C_i'^j'j P_j'^i)          
%           * sum_{k1,k2}  (lambda_i'-gamma_k1 - gamma_k2)^-1 G_{j,k1}^m G_{i,k2}^n
    for k1 = 1:N_gamma
      for k2 = 1:N_gamma
        const = (lambda_u(iprime)-gamma_s(k1)-gamma_s(k2));        
        littlesum1=intval(0);        
        for j = 1:m_s
            contract_jprime = C_u_s_s(iprime,:,j)+C_u_u_s(iprime,:,j)*P_u_s; % **_i'^ij
            contract_i = contract_jprime *G_s_s__k(:,n,k2); % **_{i',k1}^jn
            contract_m = G_s_s__k(j,:,k1)*radii(:);         % **_{j,k2}
            littlesum1 = littlesum1 +contract_i*contract_m; % **_{i',k1 k2}^n
        end% j 
        sum2 = sum2 + littlesum1/const;        
      end% k2
    end % k1
    
    P_out(iprime,n) = sum1 + sum2;
  end% n
end % i prime

end
