function [ T_tensor  ] = T_Contraction( F_tensor , A_tensor, j ,H_s_s,gamma_s,mu_s)
%T_Contraction - Theorem 5.7 & Proposition A.3	
%   Computes T_j( F )
% 
% Last Modified:  02-01-2020

% F_{j i, k}^{n i'} = F[j,n,k,i,i']
% F_tensor(j,n,M,i,i_prime)

    m_s = length(F_tensor(:,1,1,1,1));
    m_u = length(F_tensor(1,1,1,1,:));
    N_mu = length(F_tensor(1,1,:,1,1));
       
    T_tensor = intval(zeros(1,m_s,N_mu,m_s,m_u));
    
    %     We only multiply H_j^i * F_{j i,k }^{n i'} when i!=j
    H_s_s(j,j)=0;
    
    for k = 1:N_mu
        if k ~= (j+2)
%           gamma_j =    mu_s(j+2)   
%           gamma_j = gamma_s(j+1)   
            constant = ( mu_s(k) -  gamma_s(j+1) );
            for n = 1:m_s
                for i = 1:m_s
                    for i_prime = 1:m_u
                        little_sum = H_s_s(j,:)*F_tensor(:,n,k,i,i_prime);                        
                        summand = (A_tensor(j,n,k,i,i_prime)+  little_sum)/constant;

                        T_tensor(1,n,k,i,i_prime) = summand;
                        T_tensor(1,n,j+2,i,i_prime) = T_tensor(1,n,j+2,i,i_prime) - summand;                        
                    end
                end               
            end
        end
    end
    
end

