function [ P2_out ] = bound_P2( S_u_s_s, K_tensor, G_s_s__k, H_u_s, gamma_s,lambda_u )
%bound_P2 - Computes \tilde{P} from Theorem 4.11
% Input
%       K_{j,k1,k2}^{i,m} = K(j,i,m,k1,k2)
%       G_{j,k}^n  = G(j,n,k)
%       S_{j}^{n,m} = S(j,n,m)
% Output
%       P2_out is \tilde{P}: 
%       P_j'^{ip} = P(j',i,p)
% 
% Last Modified:  12-21-2019

    m_s = length(G_s_s__k(:,1,1));
    m_u = length(lambda_u);
    N_gamma = length(gamma_s);
    
    mu_s = create_mu_deriv2( gamma_s );   
    P2_out = intval(zeros(m_u, m_s,m_s));
        
    for jprime = 1:m_u
        for i = 1:m_s
            for p =1:m_s                
                SUM_1 = intval(0); 
                SUM_2 = intval(0);
                for k1= 1:N_gamma
                    
                    for k2 = 1:N_gamma
                        % Sum S
                        const_1 = ( lambda_u(jprime) - gamma_s(k1) - gamma_s(k2));
                        little_sum = intval(0);
                        for m = 1:m_s
                            summand_1 = S_u_s_s(jprime,:,m)*G_s_s__k(m,p,k1)*G_s_s__k(:,i,k2);
                            little_sum =little_sum +summand_1 ;
                        end
                        SUM_1 = SUM_1 + little_sum/const_1;
                    end
                                        
                    for k2 = 1:N_gamma+1
                        % Sum K
                        const_2 = ( lambda_u(jprime) - mu_s(k1,k2));
                        summand2 = H_u_s(jprime,:)*K_tensor(:,i,p,k1,k2);
                        SUM_2 = SUM_2 +  summand2/const_2;
                    end
                end
                P2_out(jprime,i,p) = SUM_1 + SUM_2;
            end
        end
    end
    
end

