% a_bundles_a1_proof.m  
% 
% This file computes the following:
%   - An Equilibrium solution to the Swift-Hohenberg equation
%   - A slow-stable invariant manifold of the equilibrium
%   - An invariant frame bundle along the manifold
%   - The inverse of the invariant frame bundle along the manifold.
%
%  Then it calculates the various a-posteriori error estimates detailed in 
%  Section 7 of the paper. 
% 
% Last Modified:  Mar 30, 2020

format long
addpath('Misc')
addpath('Slow_Manifold_Calculation')

N = 30;     %Number of Fourier coefficients (spatial projection)
M = 20;     %Number of Taylor coefficients in the slow manifold approximation:
nu = 1.001  %Weight of the ell-one norm (spatial modes)               
 
%Model Parameters:
gamma = 0.05        % In the paper as \beta_1
beta  = -0.35       % In the paper as \beta_2

FIGURES         = 0;
FIGURES_DEFECT  = 0;

%Scaling of the slow stable eigenvector -- controls the Taylor decay rate
scale_ss1 = .02;    % scale_ss1 = .02
% Computes $\theta \in [ - \delta , \delta ]$
delta = intval(3.18 / 6.4477);         %%% Gives r_theta = 3.18

% "seed_type" determines which initial point is taken for the Newton method
% to find the equilibrium. Values 1,2,3,4 will converge to known
% equilibria. (Seed 2 was used in the paper.) Otherwise a random seed is
% used.
seed_type = 2;  

%==========================================================================
%==========================================================================
%==========================================================================
%==========================================================================
% ------------   NUMERICAL CALCULATIONS ---------------------------------
%==========================================================================
%==========================================================================
%==========================================================================
%==========================================================================


%--------------------------------------------------------------------------
%   Calculate an equilibrium solution:
%--------------------------------------------------------------------------

%Find a1:  
a_now = zeros(N+1, 1);   %Inivialize the container

%Some initial guess data:
if beta >-.1
    %%% These initial conditions will get us the proper
    % equilibrium for beta > -0.075
    a_now(1:3) =        [ 0.6014;    -0.3406;     -0.1612];
else
    %%% These initial conditions will get us the proper
    % equilibrium for beta ~-0.35
    if seed_type == 1
    % Symmetric
        a_now(1:6)=     [ 0;   0.6828;  0;  -0.1016;    0;  0.0047]; 
    elseif seed_type == 2 
    % Asymetric 
        a_now(1:3)=   [ 0.8297;     0.1778;     -0.16738]; 
    elseif seed_type ==3
        a_now(1:5) =    [ 0.6880;   -0.000000;     0.30037;     0.;     -0.0228];
    elseif seed_type == 4
        a_now(1:6) =        [-0.2938;    0.3825;       0.50145;     -0.0038; 0.00089;   -0.012003];
    else
        a_now(1:5) = rand(5,1);
    end
end

% Newton scheme applied to initial guess:
a1 = equilibriumNewton_SH(a_now, gamma, beta, nu, N);

%--------------- Plot the equilibria ----------------------------

numPoints = 1000;
theThetas = linspace(0, pi, numPoints);
a1_function = fourierToFunctionValues(a1, theThetas, numPoints, N);

if FIGURES
    figure
    hold on
    plot(theThetas, a1_function, 'b')
    set(gca,'XLim',[0 pi])
    legend({'a1','a2'},'Location','northeast')
end
%--------------- Stability Analysis ----------------------------


%Differential a1:
DFa1 = mid(swiftHohenbergDifferential_cos_intval(...
                a1, gamma, beta));
      
[Q1, Sigma1] = eig(DFa1);            
eigenValues1 = diag(Sigma1);

numUnstableIndices1 = size(find(real(eigenValues1) > 0), 1)

[eigen_sorted_1, order_1] = sort(eigenValues1);
if numUnstableIndices1 == 1    
    [eigen_sorted_1, order_1] = sort(eigenValues1);

    %The slow-stable eigendata of a1:
    lambda_slow1 = eigenValues1(order_1(end-1))
    
    % Double check that these are the correct eigenvectors
    xi_slow1 = Q1(:, order_1(end-1));

    % We define the slow eigenvector to equal \partial_\theta P(0)    
    Q1(:, order_1(end-1)) = xi_slow1 *scale_ss1;
    
    % We divide the k-th derivative by "norm_of_1_theta"^k
    norm_of_1_theta =  ellOneNorm_intval(intval(Q1(:, order_1(end-1))), nu, N); 
    
else
    disp('Warning! a1 does not have Morse index 1')
    return
end


%==========================================================================
%     ----  Compute the 1d slow stable manifold of a1:  ----------------
%==========================================================================

tic % Start time for computing the Slow-Stable Manifold & Normal Bundles

%The following procedure computes the Taylor coefficients
%of the 1D slow manifold by recursively solving the homological equaitons
[Ps, coefSizes] = computeFormalSeries_1D_slow_SH(...
                a1, xi_slow1, lambda_slow1, ...
                gamma, beta, ...
                scale_ss1, nu, N, M);


%Plot illustrates the decay rates of the slow manifold Taylor coefficients            
% figure 
% hold on
coefAxis = 0:M;
% % plot(coefAxis, log(coefSizes)/log(10), 'b*')
% % title('Slow Stable Manifold')

manifoldTime = toc



%-------------------------------------------------------------------------
%============ Compute the slow stable frame bundles ======================
%-------------------------------------------------------------------------


%The following procedure computes the Taylor coefficients of the invariant
%frame bundle by recursively solving the homological equations
Q_bundle = computeFormalSeries_1D_slowBundle_SH(...
                   a1, gamma, beta, lambda_slow1, ...
                   Ps, Sigma1, Q1, ...
                   nu, M, N);             


               
Q0 = Q_bundle(:, :, 1);  %-- Zeroth coefficient of the frame bundle
Q0_inv = inv(Q0);        %-- Inverse of the zeroth coefficient

Q1 = Q0;

% % %Norm in the ``X to ell_1'' operator norm:
% % Q0_norm = operatorBound_X_l1_intval(Q0, Q0, nu, N)
% % %Norm in the ``ell_1 to X'' operator norm:
% % Q0_inv_norm = operatorBound_l1_X_intval(Q0_inv, Q0, nu, N) 


if FIGURES
    %Compute and plot the decay rates of the bundle Taylor decay:
    Q_norms = zeros(1, M+1);
    for m = 0:M
        Q_norms(m+1) = ...
            sup(operatorBound_X_l1_intval(Q_bundle(:, :, m+1), Q0, nu, N)); 
    end
end

r_theta = delta*ellOneNorm_intval(Ps(:,2), nu, N)
% return

manifold_and_Bundle_time = toc 
tic % Start time for a-posteriori bounds

Q0 = intval(Q0);

%-------------------------------------------------------------------------
%============ Compute the inverse of the frame bundle ====================
%-------------------------------------------------------------------------


% This procedure computes the Taylor expansion of the inverse of the frame
% bundle by recursion. This corresponds in the paper to the operator B(\theta)
Q_bundle_inverse = ...
    computeFormalSeries_1D_slowBundleInverse_SH(...
                   Q0_inv, Q_bundle, M, N);

% % (JJ) This has been moved later to where the inverse bounds are
% %  calculated
% %                
%  tau = intval('0.9')  %We have validated bounds for the inverse bundle
%                       %only on a ball of this size.  The validated bound
%                       %is provided by the function:
%       
% Bundle_tailBound = validateBound_inverseBundle(...
%                           Q_bundle, Q_bundle_inverse, Q0, nu, delta, N, M); 
%                
%  
% Bundle_tailBound


if FIGURES
    %Compute and plot the Taylor decay of the inverse bundles:              
    Q_inv_norms = zeros(1, M+1);
    Q_inv_norms_mid = zeros(1, M+1);
    for m = 0:M
        local_inv_bound = operatorBound_l1_X_intval(Q_bundle_inverse(:, :, m+1), Q0, nu, N);
        Q_inv_norms(m+1) = sup(local_inv_bound );
        local_inv_bound_mid  = operatorBound_l1_X_intval(mid(Q_bundle_inverse(:, :, m+1)), Q0, nu, N);
        Q_inv_norms_mid(m+1) = mid(local_inv_bound_mid );
    end


    figure
    hold on 
    plot(coefAxis, log(coefSizes)/log(10), 'b*')
    plot(coefAxis, log(Q_norms)/log(10), 'g*')
    plot(coefAxis, log(Q_inv_norms)/log(10), 'r*')
    plot(coefAxis, log(Q_inv_norms_mid)/log(10), 'm*')
    legend({'slow manifold','bundles','inverted bundles','inverted bundles (midpoint)'},...
        'Location','northeast')
end


% We project B(\theta) onto the subspaces X_u, X_\theta, X_f
Q_bundle_inverse_pi_u  =Q_bundle_inverse;
Q_bundle_inverse_pi_th =Q_bundle_inverse;
Q_bundle_inverse_pi_f  =Q_bundle_inverse;

% % % TODO ::: IS THIS CORRECT???

for i = 1:length(Q_bundle_inverse(1,:,1))   
    if ~(i == order_1(end))
        Q_bundle_inverse_pi_u(i,:,:) = 0*Q_bundle_inverse(i,:,:);
    end
    
    if ~(i == order_1(end-1))
        Q_bundle_inverse_pi_th(i,:,:) = 0*Q_bundle_inverse(i,:,:);
    end   
    
    if (i == order_1(end-1)) || (i == order_1(end))
        Q_bundle_inverse_pi_f(i,:,:) = 0*Q_bundle_inverse(i,:,:);
    end

end

% We compute the weights which give us the X-norm
New_Norms = intval(zeros(1,N+1));
for i = 1:N+1
    New_Norms(i) = ellOneNorm_intval(Q0(:,i),nu,N);
end


%==========================================================================
%==========================================================================
%============ Parameterization Defect =====================================
%==========================================================================
%==========================================================================

k=(0:N)';
k2 = k.^2;
k4 = k.^4;
L_operator = -gamma*k4 - beta*k2 + 1;

%E should have 3*N+1 fourier components and 3*M+1 Taylor...
E_slow = slowManifold_fullDefect(Ps, L_operator, lambda_slow1, M, N);

%E_slow(0) components:
E0_slow = E_slow(:, 1);     



                                
%============ Bundle Defect =====================================

[E_Bundle_bounds, E_Bundles] = slowManifold_bundleDefect(...
        Ps, lambda_slow1, Sigma1, Q_bundle, gamma, beta, M, N);

%Remember:
slow_index = order_1(end-1);
unstable_index = order_1(end);

Sigma1(slow_index, slow_index)
Sigma1(unstable_index, unstable_index)

E_unstable = reshape(E_Bundles(:, unstable_index, :), [3*N+1, 3*M+1]);
E_fast = E_Bundles;
E_fast(:, slow_index, :) = zeros(3*N+1, 3*M+1);
E_fast(:, unstable_index, :) = zeros(3*N+1, 3*M+1);





if FIGURES_DEFECT
    %Compute and plot the decay rates of the bundle Taylor decay:
    E_slow_norms = zeros(1, length(E_slow(1,:)));
    for m = 1:length(E_slow_norms)
        E_slow_norms(m) = ...
            sup(ellOneNorm_intval(E_slow(:, m),  nu, -1+length(E_slow(:,1)))); 
    end
    
    Bundel_defect_norms = zeros(1, length(E_Bundles(1,1,:)));
    
    for m = 1:length(Bundel_defect_norms)
        Bundel_defect_norms(m) = ...
            sup(norm_X_to_ell(E_Bundles(1:N+1,1:N+1, m), nu, New_Norms));
    end

    Bundel_defect_norms = zeros(1, length(E_Bundles(1,1,:)));
    
    for m = 1:length(Bundel_defect_norms)
        Bundel_defect_norms(m) = ...
            sup(norm_X_to_ell(E_Bundles(1:N+1,1:N+1, m), nu, New_Norms));
    end

    figure
    hold on 
    plot(0:(length(E_slow_norms)-1)         , log(E_slow_norms)/log(10), 'b*')
    plot(0:(length(Bundel_defect_norms)-1)  , log(Bundel_defect_norms)/log(10), 'g*')
end

% return

%==========================================================================
%==========================================================================
%==========================================================================
% ---------------- BEGIN THE A-POSTERIORI ANALYSIS -----------------------
%==========================================================================
%==========================================================================
%==========================================================================




disp('BEGIN THE A-POSTERIORI ANALYSIS')




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Section 7.3.2 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% We bound the norm of E_slow = E_\theta
% 
%                     ||  E_slow(\theta) ||_{ \ell_\nu^1 }
% 
% for \theta \in [-1,1]

%E_slow(theta) bounds:
E_slow_pi_N_norm    = parmNorm_N_intval(E_slow, nu, M, N, delta, norm_of_1_theta)
E_slow_pi_inf_norm  = parmNorm_inf_intval(E_slow, nu, M, N, delta, norm_of_1_theta)
                
d_theta_E_slow_pi_N_norm    = parmNorm_D1_N_intval(E_slow, nu, M, N, delta, norm_of_1_theta)
d_theta_E_slow_pi_inf_norm  = parmNorm_D1_inf_intval(E_slow, nu, M, N, delta, norm_of_1_theta)
                
d2_theta_E_slow_pi_N_norm   = parmNorm_D2_N_intval(E_slow, nu, M, N, delta, norm_of_1_theta)
d2_theta_E_slow_pi_inf_norm = parmNorm_D2_inf_intval(E_slow, nu, M, N, delta, norm_of_1_theta)


                           
% We bound the norm of  ## E_unst ## 
% 
%                       E_unst(\theta) :  X_u  -->  \ell_\nu^1
% 
% for \theta \in [-1,1].
% We need to divide by New_Norms(unstable_index) because this is an operator norm

%E_unstable(theta) bounds:
E_unstable_pi_N_norm            = ...
    parmNorm_N_intval(E_unstable, nu, M, N, delta, norm_of_1_theta)        / New_Norms(unstable_index);
E_unstable_pi_inf_norm          = ...
    parmNorm_inf_intval(E_unstable, nu, M, N, delta, norm_of_1_theta)      / New_Norms(unstable_index);

d_theta_E_unstable_pi_N_norm    = ...
    parmNorm_D1_N_intval(E_unstable, nu, M, N, delta, norm_of_1_theta)     / New_Norms(unstable_index);
d_theta_E_unstable_pi_inf_norm  = ...
    parmNorm_D1_inf_intval(E_unstable, nu, M, N, delta, norm_of_1_theta)   / New_Norms(unstable_index);
                
d2_theta_E_unstable_pi_N_norm   = ...
    parmNorm_D2_N_intval(E_unstable, nu, M, N, delta, norm_of_1_theta)     / New_Norms(unstable_index);
d2_theta_E_unstable_pi_inf_norm = ...
    parmNorm_D2_inf_intval(E_unstable, nu, M, N, delta, norm_of_1_theta)   / New_Norms(unstable_index);



% We bound the norm of  ## E_fast ##   
% 
%                       E_fast(\theta) :  X_f  -->  \ell_\nu^1
% 
% for \theta \in [-1,1]

%E_fast(theta) bounds:

% The norm of \pi_N Q_fast is the norm of a (N+1)x(N+1) matrix in the norm::  X --> ell_nu^1 
E_fast_pi_N_norm            = parmOperatorNorm_reverse_intval(...
                                E_fast(1:N+1,1:N+1,:), Q0, nu, 3*M, N, delta, norm_of_1_theta,New_Norms)
d_theta_E_fast_pi_N_norm    = parmOperator_D1_norm_reverse_intval(...
                                E_fast(1:N+1,1:N+1,:), Q0, nu, 3*M, N, delta, norm_of_1_theta,New_Norms)
d2_theta_E_fast_pi_N_norm   = parmOperator_D2_norm_reverse_intval(...
                                E_fast(1:N+1,1:N+1,:), Q0, nu, 3*M, N, delta, norm_of_1_theta,New_Norms)
                            
% The norm of \pi_\infty Q_fast is the norm of a (3N+1)x(3N+1) matrix in the norm::  X --> ell_nu^1                             
E_fast_pi_inf_norm          = parmMatrixNorm_inf_intval(...
                                E_fast,Q0, nu, M, N, delta, norm_of_1_theta)
d_theta_E_fast_pi_inf_norm  = parmMatrixNorm_D1_inf_intval(...
                                E_fast,Q0, nu, M, N, delta, norm_of_1_theta)
d2_theta_E_fast_pi_inf_norm = parmMatrixNorm_D2_inf_intval(...
                                E_fast,Q0, nu, M, N, delta, norm_of_1_theta)
                            



%%%%%%%%%%%%%%%%%%%%%%%%%%
% Computation of the E_infty_bounds: 
%%%%%%%%%%%%%%%%%%%%%%%%%%

[E_infty_pi_N ,E_infty_pi_inf] = slowManifold_E_infty_pi_N(Ps, nu, M, N, delta, norm_of_1_theta)


%%%%%%%%%%%%%%%%%%%%%%%%%%
% Computation of the partial_theta E_partial_infty_bounds: 
%%%%%%%%%%%%%%%%%%%%%%%%%%

[E_partial_infty_pi_N , E_partial_infty_pi_inf] = ...
    slowManifold_E_partial_infty_pi_N(Ps, nu, M, N, delta, norm_of_1_theta)

%%%%%%%%%%%%%%%%%%%%%%%%%%
% Computation of the partial2_theta E_infty_bounds: 
%%%%%%%%%%%%%%%%%%%%%%%%%%

[E_partial2_infty_pi_N , E_partial2_infty_pi_inf]= ...
    slowManifold_E_partial2_infty_pi_N(Ps, nu, M, N, delta, norm_of_1_theta)



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Section 7.3.3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Bound on P

Id = intval(eye(N+1));

  P_bound = sup(parmNorm_intval(   Ps, Id, nu, M, N, delta, norm_of_1_theta))
 DP_bound = sup(parmNorm_D1_intval(Ps, Id, nu, M, N, delta, norm_of_1_theta))
D2P_bound = sup(parmNorm_D2_intval(Ps, Id, nu, M, N, delta, norm_of_1_theta))

%%%%%%%%%%%%%%%%%%%%%%%%%%
% Bound on Q
%%%%%%%%%%%%%%%%%%%%%%%%%%

Q_jono = Q_bundle;
Q_jono_fast = Q_bundle;
Q_jono_unst = Q_bundle;

% Creates Q_u(\theta) + Q_f(\theta)
for m = 0:M
    Q_jono(:, order_1(end-1), m+1) = zeros(N+1, 1);
end

for i = 1:length(Q_bundle_inverse(1,:,1))   
    % Creates Q_u(\theta)
    if ~(i == order_1(end))
        Q_jono_unst(:,i,:) = 0*Q_bundle(:,i,:);
    end 
    % Creates Q_f(\theta)
    if (i == order_1(end-1)) || (i == order_1(end))
        Q_jono_fast(:,i,:) = 0*Q_bundle(:,i,:);
    end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Section 7.3.3 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Q_u_D0_bound = parmOperatorNorm_reverse_intval(...
                Q_jono_unst, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)
Q_u_D1_bound = parmOperator_D1_norm_reverse_intval(...
                Q_jono_unst, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)
Q_u_D2_bound = parmOperator_D2_norm_reverse_intval(...
                Q_jono_unst, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)
Q_u_D3_bound = parmOperator_D3_norm_reverse_intval(...
                Q_jono_unst, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)
            
            
Q_f_D0_bound = parmOperatorNorm_reverse_intval(...
                Q_jono_fast, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)
Q_f_D1_bound = parmOperator_D1_norm_reverse_intval(...
                Q_jono_fast, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)
Q_f_D2_bound = parmOperator_D2_norm_reverse_intval(...
                Q_jono_fast, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)
Q_f_D3_bound = parmOperator_D3_norm_reverse_intval(...
                Q_jono_fast, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)
            
            
Q_jono_norm_bound = parmOperatorNorm_reverse_intval(...
                Q_jono, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)
Q_jono_D1_norm_bound = parmOperator_D1_norm_reverse_intval(...
                Q_jono, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)
Q_jono_D2_norm_bound = parmOperator_D2_norm_reverse_intval(...
                Q_jono, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)
Q_jono_D3_norm_bound = parmOperator_D3_norm_reverse_intval(...
                Q_jono, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)

Q_info =    { ...
                Q_u_D0_bound
                Q_u_D1_bound
                Q_u_D2_bound
                Q_u_D3_bound 
                ... 
                Q_f_D0_bound 
                Q_f_D1_bound 
                Q_f_D2_bound 
                Q_f_D3_bound 
                ...             
                Q_jono_norm_bound 
                Q_jono_D1_norm_bound 
                Q_jono_D2_norm_bound 
                Q_jono_D3_norm_bound  
            };

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Section 7.3.1 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% TODO: Add the tail error estimate

% We estimate norm of 
%                       B(\theta) :  \ell_\nu^1 -->  X 

%  In addition, we're going to need bounds on \pi_j B(\theta) 
B_norm          =   parmOperatorNorm_intval(Q_bundle_inverse,       Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)
B_norm_pi_u     =   parmOperatorNorm_intval(Q_bundle_inverse_pi_u,  Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)
B_norm_pi_th    =   parmOperatorNorm_intval(Q_bundle_inverse_pi_th, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)
B_norm_pi_f     =   parmOperatorNorm_intval(Q_bundle_inverse_pi_f,  Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)
%%%%%%%%%%%%
DB_norm_pi_u    =   parmOperator_D1_norm_intval(Q_bundle_inverse_pi_u, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)
D2B_norm_pi_u   =   parmOperator_D2_norm_intval(Q_bundle_inverse_pi_u, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)
%%%%%%%%%%%%
DB_norm_pi_f    =   parmOperator_D1_norm_intval(Q_bundle_inverse_pi_f, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)
D2B_norm_pi_f   =   parmOperator_D2_norm_intval(Q_bundle_inverse_pi_f, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)
%%%%%%%%%%%%
DB_norm_pi_th   =   parmOperator_D1_norm_intval(Q_bundle_inverse_pi_th, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)
D2B_norm_pi_th  =   parmOperator_D2_norm_intval(Q_bundle_inverse_pi_th, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)
%%%%%%%%%%%%
DB_norm         =   parmOperator_D1_norm_intval(Q_bundle_inverse, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)
D2B_norm        =   parmOperator_D2_norm_intval(Q_bundle_inverse, Q0, nu, M, N, delta, norm_of_1_theta,New_Norms)


%%%%%%%%%%%%%%%%%%%%%%%%%%
% We compute the (Taylor) tail bounds for the inverse operator B(\theta)

[Bundle_tailBound ,Bundle_tailBound_D1, Bundle_tailBound_D2 ] ...
            = validateBound_inverseBundle( Q_bundle, Q_bundle_inverse, Q0, nu,...
            delta,New_Norms, N, M , norm_of_1_theta, Q_jono_D1_norm_bound,Q_jono_D2_norm_bound); 
               

%%%%%%%%%%%%%%%%%%%%%%%%%%
B_norm          =   B_norm          + Bundle_tailBound;
B_norm_pi_u     =   B_norm_pi_u     + Bundle_tailBound;
B_norm_pi_th    =   B_norm_pi_th    + Bundle_tailBound;
B_norm_pi_f     =   B_norm_pi_f     + Bundle_tailBound;
%%%%%%%%%%%%%%%%%%%%%%%%%%
DB_norm         =   DB_norm         + Bundle_tailBound_D1;
DB_norm_pi_u    =   DB_norm_pi_u    + Bundle_tailBound_D1;
DB_norm_pi_f    =   DB_norm_pi_f    + Bundle_tailBound_D1;
DB_norm_pi_th   =   DB_norm_pi_th   + Bundle_tailBound_D1;
%%%%%%%%%%%%%%%%%%%%%%%%%%
D2B_norm        =   D2B_norm        + Bundle_tailBound_D2;
D2B_norm_pi_u   =   D2B_norm_pi_u   + Bundle_tailBound_D2;
D2B_norm_pi_f   =   D2B_norm_pi_f   + Bundle_tailBound_D2;
D2B_norm_pi_th  =   D2B_norm_pi_th  + Bundle_tailBound_D2;
%%%%%%%%%%%%%%%%%%%%%%%%%%

B_info = { B_norm, B_norm_pi_u , B_norm_pi_th , B_norm_pi_f ,...
    DB_norm ,DB_norm_pi_u,DB_norm_pi_th,DB_norm_pi_f ...
    D2B_norm,D2B_norm_pi_u,D2B_norm_pi_th,D2B_norm_pi_f};

        
        
        
%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Section 7.4 - A bound on dDK(0) 
%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%

% Dividing by |1|_{X_\theta} is necessary to bound the operator in the norm
%   || . ||_{ \mathcal{ X \otimes X_\theta , \ell_\nu^1 }
d_theta_A0_0_bound = operatorBound_X_l1_intval(Q_bundle(:,:,2), Q0, nu, N)      / norm_of_1_theta;
d_theta_Qu_0_bound = operatorBound_X_l1_intval(Q_jono_unst(:,:,2), Q0, nu, N)   / norm_of_1_theta;
d_theta_Qf_0_bound = operatorBound_X_l1_intval(Q_jono_fast(:,:,2), Q0, nu, N)   / norm_of_1_theta;

DK_0_info = [d_theta_A0_0_bound, d_theta_Qu_0_bound, d_theta_Qf_0_bound];
computingBounds_time = toc;


disp(' ')
manifold_and_Bundle_time
computingBounds_time





